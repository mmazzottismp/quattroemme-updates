<?php
/**
 * Controllo degli aggiornamenti del tema.
 *
 * Il tema non sta su wordpress.org, quindi WordPress non sa a chi chiedere se
 * esiste una versione nuova. Glielo diciamo noi: l'intestazione "Update URI"
 * in style.css indica il nostro scaffale, e WordPress a quel punto chiama il
 * filtro update_themes_<nome del server>. Qui rispondiamo leggendo un file di
 * testo pubblicato su GitHub Pages.
 *
 * Il confronto fra le versioni lo fa WordPress da solo: noi diciamo solo qual
 * e' l'ultima versione disponibile e dove scaricarla.
 *
 * @package EmmeTheme
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Indirizzo dello scaffale degli aggiornamenti e nome del server che lo ospita.
 *
 * Il nome del server deve corrispondere a quello dell'indirizzo, perche' da
 * quello WordPress costruisce il nome del filtro.
 */
const EMME_THEME_UPDATE_BASE = 'https://mmazzottismp.github.io/quattroemme-updates/';
const EMME_THEME_UPDATE_HOST = 'mmazzottismp.github.io';

/**
 * Canali ammessi. Qualunque altro valore viene ignorato.
 */
const EMME_THEME_UPDATE_CHANNELS = array( 'stabile', 'pilota' );

/**
 * Canale di aggiornamento di questo sito.
 *
 * Si sceglie per sito scrivendo in wp-config.php, prima della riga
 * "That's all, stop editing":
 *
 *     define( 'EMME_UPDATE_CHANNEL', 'pilota' );
 *
 * Senza quella riga il sito sta sul canale stabile, che e' quello giusto per
 * la grande maggioranza dei clienti.
 */
function emme_theme_update_channel(): string {
	$channel = defined( 'EMME_UPDATE_CHANNEL' ) ? (string) EMME_UPDATE_CHANNEL : 'stabile';

	return in_array( $channel, EMME_THEME_UPDATE_CHANNELS, true ) ? $channel : 'stabile';
}

/**
 * Legge il file di testo del canale, con memoria temporanea di sei ore.
 *
 * La memoria temporanea evita di interrogare GitHub a ogni caricamento della
 * bacheca. Se il server non risponde, ricordiamo anche l'insuccesso per un'ora:
 * cosi' un sito con problemi di rete non rallenta la bacheca a ogni visita.
 *
 * @param bool $force Salta la memoria temporanea e chiede davvero.
 * @return array<string, mixed>|null I dati, oppure null se non disponibili.
 */
function emme_theme_update_manifest( bool $force = false ): ?array {
	$channel       = emme_theme_update_channel();
	$transient_key = 'emme_theme_update_' . $channel;

	if ( ! $force ) {
		$cached = get_site_transient( $transient_key );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		if ( 'non-disponibile' === $cached ) {
			return null;
		}
	}

	$response = wp_remote_get(
		EMME_THEME_UPDATE_BASE . $channel . '/emme-theme.json',
		array(
			'timeout' => 10,
			'headers' => array( 'Accept' => 'application/json' ),
		)
	);

	$body = ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) )
		? null
		: json_decode( wp_remote_retrieve_body( $response ), true );

	if ( ! is_array( $body ) || empty( $body['version'] ) ) {
		set_site_transient( $transient_key, 'non-disponibile', HOUR_IN_SECONDS );

		return null;
	}

	set_site_transient( $transient_key, $body, 6 * HOUR_IN_SECONDS );

	return $body;
}

/**
 * Risponde a WordPress quando chiede se c'e' una versione nuova del tema.
 *
 * @param array<string, mixed>|false $update     Risposta di chi ci ha preceduto.
 * @param array<string, mixed>       $theme_data Intestazioni del tema.
 * @param string                     $stylesheet Nome della cartella del tema.
 * @return array<string, mixed>|false
 */
function emme_theme_update_response( $update, array $theme_data, string $stylesheet ) {
	// Se qualcun altro ha gia' risposto, o se il tema non e' il nostro, non tocchiamo niente.
	if ( false !== $update || get_template() !== $stylesheet ) {
		return $update;
	}

	$manifest = emme_theme_update_manifest();

	if ( null === $manifest || empty( $manifest['package'] ) ) {
		return $update;
	}

	return array(
		'theme'        => $stylesheet,
		'version'      => (string) $manifest['version'],
		'url'          => (string) ( $manifest['url'] ?? '' ),
		'package'      => (string) $manifest['package'],
		'tested'       => (string) ( $manifest['tested'] ?? '' ),
		'requires_php' => (string) ( $manifest['requires_php'] ?? '' ),
	);
}
add_filter( 'update_themes_' . EMME_THEME_UPDATE_HOST, 'emme_theme_update_response', 10, 3 );

/**
 * Dimentica la memoria temporanea dopo un aggiornamento andato a buon fine.
 *
 * Senza questo, per sei ore WordPress continuerebbe a credere che esista una
 * versione piu' nuova di quella appena installata.
 */
function emme_theme_update_clear_cache(): void {
	foreach ( EMME_THEME_UPDATE_CHANNELS as $channel ) {
		delete_site_transient( 'emme_theme_update_' . $channel );
	}
}
add_action( 'upgrader_process_complete', 'emme_theme_update_clear_cache' );
