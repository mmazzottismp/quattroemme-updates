<?php
/**
 * Funzioni del tema quattroemme.
 *
 * Qui dentro va solo quello che theme.json non sa fare: agganciare il foglio
 * di stile, registrare le categorie dei pattern e, piu avanti, il controllo
 * degli aggiornamenti.
 *
 * @package EmmeTheme
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Controllo degli aggiornamenti: vedi inc/Updates.php.
require_once get_template_directory() . '/inc/Updates.php';

/**
 * Versione del tema, letta dall'intestazione di style.css.
 *
 * Serve per marcare i file CSS e JS: quando la versione cambia, i browser
 * dei visitatori ricaricano i file invece di usare quelli vecchi in cache.
 */
function emme_theme_version(): string {
	static $version = null;

	if ( null === $version ) {
		$version = (string) wp_get_theme()->get( 'Version' );
	}

	return $version;
}

/**
 * Aggancia style.css alle pagine del sito.
 *
 * Nei temi a blocchi WordPress non lo fa da solo: va dichiarato qui.
 */
function emme_theme_enqueue_styles(): void {
	wp_enqueue_style(
		'emme-theme',
		get_stylesheet_uri(),
		array(),
		emme_theme_version()
	);
}
add_action( 'wp_enqueue_scripts', 'emme_theme_enqueue_styles' );

/**
 * Registra la categoria sotto cui compaiono i pattern del tema.
 *
 * Un "pattern" e' una sezione gia' composta (un hero, una riga di servizi)
 * che si inserisce dall'editor e poi si modifica liberamente.
 */
function emme_theme_register_pattern_categories(): void {
	register_block_pattern_category(
		'emme-sezioni',
		array(
			'label'       => __( 'quattroemme: sezioni', 'emme-theme' ),
			'description' => __( 'Sezioni pronte da inserire nelle pagine.', 'emme-theme' ),
		)
	);
}
add_action( 'init', 'emme_theme_register_pattern_categories' );
