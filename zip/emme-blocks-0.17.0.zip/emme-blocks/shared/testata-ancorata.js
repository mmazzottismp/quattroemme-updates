/*
 * La barra che resta in cima e si riduce mentre la pagina scorre.
 *
 * Serve soprattutto alle testate. Il comportamento e' copiato da un sito
 * fatto con Blocksy, misurato nel browser il 10/11/2026, e sta tutto in una
 * riga di aritmetica:
 *
 *     altezza = massimo fra il minimo e ( altezza a riposo - quanto hai scorso )
 *
 * 120 diventa 80 dopo 40 px di scorrimento, 40 dopo 80, e poi si ferma al
 * minimo. Il contenuto - di solito il logo - si rimpicciolisce nella stessa
 * proporzione, fino alla sua quota minima.
 *
 * TRE COSE da non cambiare, perche' sono il motivo per cui l'effetto non si
 * nota mentre si legge:
 *
 * 1. Niente animazione a tempo. L'altezza e' legata al dito che scorre, non
 *    a una durata: per questo non si vede mai «partire» qualcosa.
 * 2. Il posto resta occupato. La barra, quando si stacca, esce dal flusso, e
 *    il segnaposto attorno tiene l'altezza che aveva a riposo: il contenuto
 *    sotto non salta mai.
 * 3. Si riduce alla stessa velocita' con cui la pagina scorre. Un pixel
 *    scorso, un pixel di altezza in meno: rispetto al contenuto che sale, il
 *    bordo di sotto della barra sta fermo.
 *
 * Il lavoro per fotogramma e' una sola scrittura: la variabile `--emme-anc-s`,
 * che va da 1 (tutta aperta) a 0 (tutta ridotta). Altezza, dimensione del
 * logo, sfondo e ombra li calcola il CSS a partire da li'.
 *
 * Il file viene caricato solo se nella pagina c'e' almeno una barra ancorata.
 */
( function () {
	'use strict';

	var barre = [];
	var inCoda = false;

	/**
	 * Legge una variabile CSS come numero, con un valore di ripiego.
	 *
	 * @param {CSSStyleDeclaration} stile    Stile calcolato.
	 * @param {string}              nome     Nome della variabile.
	 * @param {number}              ripiego  Valore se manca o non e' un numero.
	 * @return {number} Il numero.
	 */
	function numero( stile, nome, ripiego ) {
		var grezzo = parseFloat( stile.getPropertyValue( nome ) );

		return isNaN( grezzo ) ? ripiego : grezzo;
	}

	/**
	 * Rilegge le misure a riposo di una barra.
	 *
	 * Si rifa' al caricamento e a ogni ridimensionamento: l'altezza a riposo
	 * cambia se il testo va a capo in modo diverso, e l'interruttore per
	 * schermo cambia proprio li'.
	 *
	 * @param {Object} barra La barra registrata.
	 */
	function misura( barra ) {
		var elemento = barra.elemento;

		// Si misura da ferma: se e' gia' ancorata la si stacca un attimo, se
		// no si misurerebbe l'altezza ridotta e il segnaposto si accorcerebbe
		// a ogni ridimensionamento.
		var eraAncorata = barra.ancorata;

		if ( eraAncorata ) {
			stacca( barra, false );
		}

		var stile = window.getComputedStyle( elemento );

		barra.attiva = numero( stile, '--emme-anc-on', 0 ) === 1;
		barra.minima = numero( stile, '--emme-anc-hmin', 0 );
		barra.quota = numero( stile, '--emme-anc-pmin', 1 );
		barra.distanza = numero( stile, '--emme-anc-top', 0 );
		// Solo per «scivola»: senza, la barra compare quando la pagina ha scorso
		// quanto e' alta lei, che e' il punto in cui sparirebbe dalla vista.
		barra.soglia = numero( stile, '--emme-anc-soglia', -1 );
		barra.altezza = elemento.getBoundingClientRect().height;
		barra.cima = barra.posto.getBoundingClientRect().top + window.scrollY;

		barra.posto.style.minHeight = barra.altezza + 'px';

		// L'altezza a riposo serve al CSS per interpolare fra lei e il minimo.
		elemento.style.setProperty( '--emme-anc-h0', barra.altezza + 'px' );

		// Anche lo spazio sopra e sotto si stringe, nella stessa proporzione
		// del contenuto: se no in una barra alta 60 un pulsante alto 55 piu'
		// 20 di spazio non ci sta, e sborda.
		elemento.style.setProperty( '--emme-anc-pt', stile.paddingTop );
		elemento.style.setProperty( '--emme-anc-pb', stile.paddingBottom );

		// Lo spazio dentro i pulsanti, per assottigliarli nella stessa
		// proporzione. Si legge dal primo: in una testata hanno tutti lo
		// stesso, e leggerlo da ognuno costerebbe un calcolo di stile a testa.
		var pulsante = elemento.querySelector( '.wp-element-button, .emme-button' );

		if ( pulsante ) {
			elemento.style.setProperty(
				'--emme-anc-bpt',
				window.getComputedStyle( pulsante ).paddingTop
			);
		}

		// L'altezza naturale di ogni immagine dentro: serve al CSS per
		// rimpicciolirla in proporzione senza doverla indovinare.
		//
		// E il suo POSTO resta largo com'era. Senza, mentre il logo si
		// rimpicciolisce lo spazio che occupava si libera, e in una riga con
		// gli elementi distribuiti il menu scivola verso sinistra: misurati
		// 112 px di spostamento sulla testata della Cantamessa, dove il suo
		// sito tiene le voci ferme. Il logo si rimpicciolisce dentro uno
		// spazio che non cambia, come fa lei.
		barra.immagini.forEach( function ( immagine ) {
			var riquadro = immagine.getBoundingClientRect();

			if ( riquadro.height > 0 ) {
				immagine.style.setProperty( '--emme-anc-ih', riquadro.height + 'px' );
			}

			var posto = immagine.closest( '.emme-image-wrap' ) || immagine.parentElement;

			if ( posto && posto !== elemento && riquadro.width > 0 ) {
				posto.style.minWidth = posto.getBoundingClientRect().width + 'px';
			}
		} );

		if ( eraAncorata ) {
			attacca( barra );
		}
	}

	/**
	 * Attacca la barra in cima.
	 *
	 * @param {Object} barra La barra registrata.
	 */
	function attacca( barra ) {
		barra.ancorata = true;
		barra.elemento.classList.add( 'is-ancorata' );
	}

	/**
	 * Stacca la barra e la rimette dov'era.
	 *
	 * @param {Object} barra   La barra registrata.
	 * @param {boolean} azzera Se riportare anche il fattore a 1.
	 */
	function stacca( barra, azzera ) {
		barra.ancorata = false;
		barra.elemento.classList.remove( 'is-ancorata' );

		if ( azzera !== false ) {
			barra.elemento.style.setProperty( '--emme-anc-s', '1' );
		}
	}

	/**
	 * Ricalcola una barra alla posizione di scorrimento attuale.
	 *
	 * @param {Object} barra La barra registrata.
	 * @param {number} y     Scorrimento verticale.
	 */
	function aggiorna( barra, y ) {
		if ( ! barra.attiva ) {
			if ( barra.ancorata ) {
				stacca( barra, true );
			}

			return;
		}

		var scorso = y - barra.cima + barra.distanza;

		/*
		 * «Scivola» non si accorcia strada facendo: resta intera finche' non
		 * si supera la soglia, e poi compare gia' ridotta. Senza una soglia
		 * dichiarata si usa la sua altezza, che e' il punto in cui sarebbe
		 * comunque sparita dalla vista. E' il modo di saracantamessa.it,
		 * dove la barra arriva a 300 px gia' alta 70 invece di 140.
		 */
		if ( barra.scivola ) {
			var quando = barra.soglia >= 0 ? barra.soglia : barra.altezza;

			if ( scorso < quando ) {
				if ( barra.ancorata ) {
					stacca( barra, true );
				}

				barra.ultimaY = y;

				return;
			}

			if ( ! barra.ancorata ) {
				attacca( barra );
			}

			barra.elemento.style.setProperty( '--emme-anc-s', '0' );
			barra.ultimaY = y;

			return;
		}

		if ( scorso <= 0 ) {
			if ( barra.ancorata ) {
				stacca( barra, true );
			}

			barra.ultimaY = y;

			return;
		}

		if ( ! barra.ancorata ) {
			attacca( barra );
		}

		// La riga di aritmetica che fa tutto. Senza la riduzione il fattore
		// resta a 1 e la barra tiene la sua altezza.
		if ( barra.riduce && barra.altezza > barra.minima ) {
			var alta = Math.max( barra.minima, barra.altezza - scorso );
			var fattore = ( alta - barra.minima ) / ( barra.altezza - barra.minima );

			barra.elemento.style.setProperty( '--emme-anc-s', fattore.toFixed( 4 ) );
		}

		// Si nasconde scendendo e torna salendo: un comportamento a parte, che
		// si puo' accendere anche senza la riduzione.
		if ( barra.nasconde ) {
			var scende = y > barra.ultimaY;

			// Sotto i tre pixel non si decide niente: su un portatile con il
			// trackpad il verso cambia di continuo, e la barra lampeggerebbe.
			if ( Math.abs( y - barra.ultimaY ) > 3 ) {
				barra.elemento.classList.toggle( 'is-nascosta', scende && scorso > barra.altezza );
			}
		}

		barra.ultimaY = y;
	}

	/**
	 * Un giro su tutte le barre, dentro il ritmo di disegno del browser.
	 */
	function giro() {
		inCoda = false;

		var y = window.scrollY || window.pageYOffset || 0;

		barre.forEach( function ( barra ) {
			aggiorna( barra, y );
		} );
	}

	/**
	 * Chiede un giro, se non ce n'e' gia' uno in coda.
	 */
	function chiedi() {
		if ( inCoda ) {
			return;
		}

		inCoda = true;
		window.requestAnimationFrame( giro );
	}

	/**
	 * Mette in piedi tutto.
	 */
	function avvia() {
		var elementi = document.querySelectorAll( '[data-emme-anc]' );

		if ( ! elementi.length ) {
			return;
		}

		// Chi ha chiesto meno movimento riceve la barra ancorata ma gia'
		// ridotta: resta utile e non si muove sotto gli occhi.
		var menoMovimento =
			window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

		Array.prototype.forEach.call( elementi, function ( elemento ) {
			var posto = elemento.closest( '.emme-anc-posto' );

			// Senza segnaposto non si ancora niente: il contenuto salterebbe.
			if ( ! posto ) {
				return;
			}

			var modi = ( elemento.getAttribute( 'data-emme-anc' ) || '' ).split( ' ' );

			barre.push( {
				elemento: elemento,
				posto: posto,
				immagini: Array.prototype.slice.call( elemento.querySelectorAll( 'img' ) ),
				riduce: modi.indexOf( 'shrink' ) !== -1 && ! menoMovimento,
				scivola: modi.indexOf( 'slide' ) !== -1,
				nasconde: modi.indexOf( 'hide' ) !== -1,
				soglia: -1,
				ancorata: false,
				attiva: false,
				altezza: 0,
				minima: 0,
				quota: 1,
				distanza: 0,
				cima: 0,
				ultimaY: 0,
			} );
		} );

		if ( ! barre.length ) {
			return;
		}

		barre.forEach( misura );

		// Chi non vuole movimento salta la scalatura ma tiene l'ancoraggio:
		// la barra arriva gia' alla sua altezza minima.
		if ( menoMovimento ) {
			barre.forEach( function ( barra ) {
				barra.elemento.style.setProperty( '--emme-anc-s', '0' );
			} );
		}

		giro();

		window.addEventListener( 'scroll', chiedi, { passive: true } );

		var attesa;

		window.addEventListener(
			'resize',
			function () {
				window.clearTimeout( attesa );
				attesa = window.setTimeout( function () {
					barre.forEach( misura );
					giro();
				}, 150 );
			},
			{ passive: true }
		);

		// Le immagini cambiano l'altezza a riposo quando finiscono di
		// caricarsi, e il segnaposto deve seguirle.
		window.addEventListener( 'load', function () {
			barre.forEach( misura );
			giro();
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', avvia );
	} else {
		avvia();
	}
} )();
