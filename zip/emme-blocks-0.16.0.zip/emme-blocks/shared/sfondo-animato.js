/*
 * Sfondi animati dei contenitori quattroemme.
 *
 * Non e' un video e non e' un'immagine: e' una formula che la scheda grafica
 * esegue per ogni singolo punto dello schermo, sessanta volte al secondo. Da
 * qui le tre cose che contano:
 *
 * - pesa quanto il testo che lo descrive, e non cresce se lo sfondo e' grande;
 * - i colori arrivano dalla tavolozza del tema, quindi cambiano da soli
 *   passando da una variante di stile all'altra;
 * - nessuna libreria esterna, niente da scaricare da altri server.
 *
 * Il disegno di ogni sfondo sta in DISEGNI, qui sotto, ed e' scritto in GLSL,
 * il linguaggio delle schede grafiche. L'elenco dei tipi sta invece in
 * shared/sfondi.json, che leggono anche il PHP e l'editor: una prova controlla
 * che i due elenchi coincidano.
 *
 *
 * QUANDO NON DISEGNA
 *
 * - Se il browser non sa fare WebGL non succede niente: sotto la tela c'e' una
 *   sfumatura CSS fatta con gli stessi colori, che resta visibile.
 * - Se l'utente ha chiesto meno movimento, si disegna UN fotogramma e si sta
 *   fermi. Lo sfondo si vede, ma non si muove.
 * - Fuori dallo schermo e a scheda nascosta si smette di disegnare: uno sfondo
 *   che nessuno guarda non deve consumare batteria.
 */
( function () {
	'use strict';

	// Si disegna a tre quarti della risoluzione vera e si lascia ingrandire al
	// browser. Sono sfumature morbide: la differenza non si vede, il lavoro
	// della scheda grafica si dimezza.
	var SCALA = 0.75;

	// Oltre questa larghezza non si va comunque: uno sfondo su uno schermo 4K
	// non ha bisogno di quattromila punti per fare una sfumatura.
	var LARGHEZZA_MASSIMA = 1280;

	var COLORI_DI_RISERVA = [ [ 0.91, 0.91, 0.89 ], [ 0.78, 0.80, 0.78 ], [ 0.28, 0.36, 0.30 ] ];

	// --- i disegni ----------------------------------------------------------

	var PRELUDIO = [
		'precision mediump float;',
		'uniform vec2 dim;',    // dimensione del disegno, in punti
		'uniform float t;',     // secondi dall'avvio
		'uniform float forza;', // intensita': 1 e' il valore normale
		'uniform vec3 c1;',
		'uniform vec3 c2;',
		'uniform vec3 c3;',
		''
	].join( '\n' );

	var DISEGNI = {
		// Fasce di colore che scorrono. Tre onde di frequenza diversa sommate:
		// una sola si riconoscerebbe come onda, tre insieme no.
		onde: [
			'void main() {',
			'  vec2 u = gl_FragCoord.xy / dim;',
			'  float onda = u.y',
			'    + 0.13 * forza * sin( u.x * 3.1 + t * 0.55 )',
			'    + 0.07 * forza * sin( u.x * 6.3 - t * 0.37 )',
			'    + 0.04 * forza * sin( u.x * 11.0 + t * 0.90 );',
			'  vec3 col = mix( c1, c2, smoothstep( 0.15, 0.85, onda ) );',
			'  col = mix( col, c3, smoothstep( 0.62, 1.15, onda + 0.09 * sin( u.x * 2.2 - t * 0.29 ) ) );',
			'  gl_FragColor = vec4( col, 1.0 );',
			'}'
		].join( '\n' ),

		// Tre macchie che si spostano lentamente e si sfumano una nell'altra.
		// Le coordinate sono corrette per le proporzioni, altrimenti su un
		// contenitore largo e basso le macchie verrebbero ovali.
		aurora: [
			'float macchia( vec2 u, vec2 centro, float raggio ) {',
			'  return smoothstep( raggio, 0.0, distance( u, centro ) );',
			'}',
			'void main() {',
			'  float a = dim.x / dim.y;',
			'  vec2 u = gl_FragCoord.xy / dim;',
			'  u.x *= a;',
			'  float r = 0.62 * forza;',
			'  vec2 p1 = vec2( a * ( 0.30 + 0.20 * sin( t * 0.21 ) ), 0.38 + 0.18 * cos( t * 0.17 ) );',
			'  vec2 p2 = vec2( a * ( 0.72 + 0.16 * cos( t * 0.13 + 1.7 ) ), 0.66 + 0.22 * sin( t * 0.23 ) );',
			'  vec2 p3 = vec2( a * ( 0.52 + 0.24 * sin( t * 0.11 + 3.1 ) ), 0.28 + 0.20 * cos( t * 0.19 + 0.8 ) );',
			'  vec3 col = c1;',
			'  col = mix( col, c2, macchia( u, p2, r ) );',
			'  col = mix( col, c3, macchia( u, p3, r * 0.85 ) );',
			'  col = mix( col, c2, macchia( u, p1, r * 0.70 ) * 0.6 );',
			'  gl_FragColor = vec4( col, 1.0 );',
			'}'
		].join( '\n' ),

		// Prima si piega lo spazio, poi ci si disegna dentro. E' quella piega
		// che toglie la regolarita' da onda e fa sembrare la cosa nebbia.
		nebbia: [
			'float campo( vec2 u ) {',
			'  return sin( u.x * 1.7 + t * 0.21 )',
			'       + sin( u.y * 2.1 - t * 0.17 )',
			'       + sin( ( u.x + u.y ) * 1.3 + t * 0.13 );',
			'}',
			'void main() {',
			'  float a = dim.x / dim.y;',
			'  vec2 u = gl_FragCoord.xy / dim;',
			'  u.x *= a;',
			'  u *= 2.4;',
			'  vec2 piegato = u + 0.6 * forza * vec2( campo( u + vec2( 1.3, 0.0 ) ), campo( u + vec2( 0.0, 2.1 ) ) );',
			'  float n = clamp( campo( piegato ) / 3.0 * 0.5 * forza + 0.5, 0.0, 1.0 );',
			'  vec3 col = mix( c1, c2, smoothstep( 0.18, 0.62, n ) );',
			'  col = mix( col, c3, smoothstep( 0.55, 0.95, n ) );',
			'  gl_FragColor = vec4( col, 1.0 );',
			'}'
		].join( '\n' )
	};

	var VERTICI = 'attribute vec2 posizione; void main() { gl_Position = vec4( posizione, 0.0, 1.0 ); }';

	// --- leggere i colori ---------------------------------------------------

	// Il mestiere di capire che colore sia "#485b4c", "rgb(72 91 76)" o
	// "darkseagreen" lo sa gia' fare il browser: gli si assegna il valore e
	// glielo si richiede, e torna sempre nella stessa forma. Due valori di
	// prova diversi servono a distinguere "colore nero" da "valore rifiutato".
	var tavolozza = ( function () {
		try {
			return document.createElement( 'canvas' ).getContext( '2d' );
		} catch ( e ) {
			return null;
		}
	} )();

	function normalizza( valore ) {
		if ( ! tavolozza || ! valore ) {
			return '';
		}

		tavolozza.fillStyle = '#010203';
		tavolozza.fillStyle = valore;

		if ( tavolozza.fillStyle !== '#010203' ) {
			return tavolozza.fillStyle;
		}

		// Potrebbe essere davvero quel colore: si riprova con un altro.
		tavolozza.fillStyle = '#040506';
		tavolozza.fillStyle = valore;

		return tavolozza.fillStyle === '#040506' ? '' : tavolozza.fillStyle;
	}

	function aRgb( valore, riserva ) {
		var testo = normalizza( valore );

		if ( testo.charAt( 0 ) === '#' ) {
			var n = parseInt( testo.slice( 1 ), 16 );

			return [ ( ( n >> 16 ) & 255 ) / 255, ( ( n >> 8 ) & 255 ) / 255, ( n & 255 ) / 255 ];
		}

		var pezzi = testo.match( /[\d.]+/g );

		if ( pezzi && pezzi.length >= 3 ) {
			return [ pezzi[ 0 ] / 255, pezzi[ 1 ] / 255, pezzi[ 2 ] / 255 ];
		}

		return riserva;
	}

	function numeroDa( stile, nome, predefinito ) {
		var letto = parseFloat( stile.getPropertyValue( nome ) );

		return isFinite( letto ) ? letto : predefinito;
	}

	// --- una scena ----------------------------------------------------------

	function Scena( tela ) {
		this.tela = tela;
		this.tipo = tela.getAttribute( 'data-emme-sfondo' );
		this.viva = false;
		this.inVista = false;
		this.larghezza = 0;
		this.altezza = 0;

		// Il tempo si accumula invece di contarlo dall'avvio: cosi' una pausa
		// — scheda nascosta, sfondo uscito dallo schermo — non produce un salto
		// al ritorno. Vedi il passo massimo dentro giro().
		this.tempo = 0;
		this.ultimo = 0;
	}

	Scena.prototype.avvia = function () {
		var disegno = DISEGNI[ this.tipo ];

		if ( ! disegno ) {
			return false;
		}

		var gl;

		try {
			gl = this.tela.getContext( 'webgl', {
				alpha: true,
				antialias: false,
				depth: false,
				stencil: false,
				powerPreference: 'low-power'
			} );
		} catch ( e ) {
			gl = null;
		}

		if ( ! gl ) {
			return false;
		}

		var programma = creaProgramma( gl, VERTICI, PRELUDIO + disegno );

		if ( ! programma ) {
			return false;
		}

		this.gl = gl;
		this.programma = programma;

		// Un rettangolo che copre tutto: due triangoli, quattro vertici.
		var buffer = gl.createBuffer();
		gl.bindBuffer( gl.ARRAY_BUFFER, buffer );
		gl.bufferData( gl.ARRAY_BUFFER, new Float32Array( [ -1, -1, 1, -1, -1, 1, 1, 1 ] ), gl.STATIC_DRAW );

		var posizione = gl.getAttribLocation( programma, 'posizione' );
		gl.enableVertexAttribArray( posizione );
		gl.vertexAttribPointer( posizione, 2, gl.FLOAT, false, 0, 0 );

		gl.useProgram( programma );

		this.uDim = gl.getUniformLocation( programma, 'dim' );
		this.uT = gl.getUniformLocation( programma, 't' );
		this.uForza = gl.getUniformLocation( programma, 'forza' );

		this.leggiImpostazioni();

		// Se la scheda grafica perde il contesto (succede quando il sistema e'
		// sotto sforzo) si evita l'errore e si riprova appena torna.
		var scena = this;
		this.tela.addEventListener( 'webglcontextlost', function ( evento ) {
			evento.preventDefault();
			scena.viva = false;
		} );
		this.tela.addEventListener( 'webglcontextrestored', function () {
			scena.avvia();
		} );

		this.viva = true;

		return true;
	};

	/**
	 * Colori, velocita' e intensita' arrivano dalle variabili CSS scritte sul
	 * blocco dal generatore. Si leggono da li', e non da attributi HTML, per
	 * una ragione precisa: i colori sono riferimenti alla tavolozza del tema,
	 * quindi cambiando variante di stile cambiano da soli, senza che nessuno
	 * riscriva la pagina.
	 */
	Scena.prototype.leggiImpostazioni = function () {
		var stile = getComputedStyle( this.tela );

		this.colori = [
			aRgb( stile.getPropertyValue( '--emme-sfondo-c1' ).trim(), COLORI_DI_RISERVA[ 0 ] ),
			aRgb( stile.getPropertyValue( '--emme-sfondo-c2' ).trim(), COLORI_DI_RISERVA[ 1 ] ),
			aRgb( stile.getPropertyValue( '--emme-sfondo-c3' ).trim(), COLORI_DI_RISERVA[ 2 ] )
		];

		// Scritte in percentuale, cosi' restano numeri interi: 100 e' il normale.
		this.velocita = numeroDa( stile, '--emme-sfondo-velocita', 100 ) / 100;
		this.forza = numeroDa( stile, '--emme-sfondo-intensita', 100 ) / 100;

		var gl = this.gl;
		gl.useProgram( this.programma );
		gl.uniform3fv( gl.getUniformLocation( this.programma, 'c1' ), this.colori[ 0 ] );
		gl.uniform3fv( gl.getUniformLocation( this.programma, 'c2' ), this.colori[ 1 ] );
		gl.uniform3fv( gl.getUniformLocation( this.programma, 'c3' ), this.colori[ 2 ] );
		gl.uniform1f( this.uForza, this.forza );
	};

	Scena.prototype.misura = function () {
		var riquadro = this.tela.getBoundingClientRect();

		if ( ! riquadro.width || ! riquadro.height ) {
			return false;
		}

		var densita = Math.min( window.devicePixelRatio || 1, 2 ) * SCALA;
		var larghezza = Math.min( Math.round( riquadro.width * densita ), LARGHEZZA_MASSIMA );
		var altezza = Math.max( 1, Math.round( riquadro.height * larghezza / riquadro.width ) );

		if ( larghezza === this.larghezza && altezza === this.altezza ) {
			return true;
		}

		this.larghezza = larghezza;
		this.altezza = altezza;
		this.tela.width = larghezza;
		this.tela.height = altezza;

		this.gl.viewport( 0, 0, larghezza, altezza );
		this.gl.useProgram( this.programma );
		this.gl.uniform2f( this.uDim, larghezza, altezza );

		return true;
	};

	Scena.prototype.disegna = function ( secondi ) {
		// La misura NON si rifa' a ogni fotogramma: getBoundingClientRect
		// obbliga il browser a ricalcolare l'impaginazione, e farlo sessanta
		// volte al secondo per ogni sfondo costa piu' del disegno stesso. Si
		// rimisura solo quando qualcosa cambia davvero (vedi osservaMisura).
		if ( ! this.viva || ! this.larghezza ) {
			return;
		}

		var gl = this.gl;
		gl.useProgram( this.programma );
		gl.uniform1f( this.uT, secondi * this.velocita );
		gl.drawArrays( gl.TRIANGLE_STRIP, 0, 4 );
	};

	// --- compilare il disegno -----------------------------------------------

	function creaShader( gl, tipo, sorgente ) {
		var shader = gl.createShader( tipo );
		gl.shaderSource( shader, sorgente );
		gl.compileShader( shader );

		if ( ! gl.getShaderParameter( shader, gl.COMPILE_STATUS ) ) {
			gl.deleteShader( shader );

			return null;
		}

		return shader;
	}

	function creaProgramma( gl, sorgenteVertici, sorgenteColori ) {
		var vertici = creaShader( gl, gl.VERTEX_SHADER, sorgenteVertici );
		var colori = creaShader( gl, gl.FRAGMENT_SHADER, sorgenteColori );

		if ( ! vertici || ! colori ) {
			return null;
		}

		var programma = gl.createProgram();
		gl.attachShader( programma, vertici );
		gl.attachShader( programma, colori );
		gl.linkProgram( programma );

		if ( ! gl.getProgramParameter( programma, gl.LINK_STATUS ) ) {
			return null;
		}

		return programma;
	}

	// --- il motore, uno solo per tutta la pagina ----------------------------

	var scene = [];
	var giroChiesto = 0;
	var menoMovimento = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	function giro( adesso ) {
		giroChiesto = 0;

		var almenoUna = false;

		for ( var i = 0; i < scene.length; i++ ) {
			var scena = scene[ i ];

			if ( ! scena.viva || ! scena.inVista ) {
				scena.ultimo = 0;
				continue;
			}

			if ( ! scena.ultimo ) {
				scena.ultimo = adesso;
			}

			// Mai piu' di un decimo di secondo per fotogramma: dopo una pausa
			// lunga il tempo riparte da dov'era invece di fare un salto.
			scena.tempo += Math.min( ( adesso - scena.ultimo ) / 1000, 0.1 );
			scena.ultimo = adesso;

			scena.disegna( scena.tempo );
			almenoUna = true;
		}

		if ( almenoUna && ! menoMovimento && ! document.hidden ) {
			giroChiesto = requestAnimationFrame( giro );
		}
	}

	function sveglia() {
		if ( ! giroChiesto ) {
			giroChiesto = requestAnimationFrame( giro );
		}
	}

	function avvia() {
		var tele = document.querySelectorAll( 'canvas[data-emme-sfondo]' );

		if ( ! tele.length ) {
			return;
		}

		var osservatore =
			typeof window.IntersectionObserver === 'function'
				? new IntersectionObserver( function ( voci ) {
					voci.forEach( function ( voce ) {
						voce.target.emmeScena.inVista = voce.isIntersecting;
					} );
					sveglia();
				} )
				: null;

		// Rimisura solo quando il contenitore cambia davvero dimensione, non a
		// ogni fotogramma. Se il browser non ha ResizeObserver ci si accontenta
		// del ridimensionamento della finestra, che copre quasi tutti i casi.
		var osservatoreMisura =
			typeof window.ResizeObserver === 'function'
				? new ResizeObserver( function ( voci ) {
					voci.forEach( function ( voce ) {
						voce.target.emmeScena.misura();
					} );
					sveglia();
				} )
				: null;

		for ( var i = 0; i < tele.length; i++ ) {
			var scena = new Scena( tele[ i ] );

			if ( ! scena.avvia() ) {
				continue;
			}

			tele[ i ].emmeScena = scena;
			scene.push( scena );
			scena.misura();

			if ( osservatore ) {
				osservatore.observe( tele[ i ] );
			} else {
				scena.inVista = true;
			}

			if ( osservatoreMisura ) {
				osservatoreMisura.observe( tele[ i ] );
			}
		}

		if ( ! scene.length ) {
			return;
		}

		// A scheda nascosta non si disegna; tornando, si riparte.
		document.addEventListener( 'visibilitychange', function () {
			if ( ! document.hidden ) {
				sveglia();
			}
		} );

		if ( ! osservatoreMisura ) {
			window.addEventListener( 'resize', function () {
				for ( var k = 0; k < scene.length; k++ ) {
					scene[ k ].misura();
				}
				sveglia();
			} );
		}

		sveglia();
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', avvia );
	} else {
		avvia();
	}
} )();
