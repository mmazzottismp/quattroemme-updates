<?php
/**
 * Innesto del generatore CSS dentro WordPress.
 *
 * Il Builder e' volutamente cieco a WordPress: tutto quello che riguarda
 * filtri, azioni e stampa in pagina sta qui.
 *
 * Perche' funziona: in un tema a blocchi il contenuto della pagina viene
 * costruito PRIMA di wp_head, quindi quando wp_head arriva tutti i blocchi
 * hanno gia' dichiarato le loro regole. E' la stessa ragione per cui il core
 * di WordPress aggancia a wp_head le sue regole di blocco nei temi a blocchi,
 * e a wp_footer in quelli vecchio stile (visto in wp_enqueue_block_support_styles).
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Css;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Collega il generatore ai meccanismi di WordPress.
 */
final class Output {

	/**
	 * Vero se almeno un blocco della pagina ha un'animazione.
	 */
	private static bool $animazioni = false;

	/**
	 * Vero se almeno un'immagine della pagina si puo' ingrandire.
	 */
	private static bool $lightbox = false;

	/**
	 * Vero se almeno un contenitore della pagina ha lo sfondo animato.
	 */
	private static bool $sfondo = false;

	/**
	 * Vero se nella pagina c'e' almeno una scheda a due facce.
	 */
	private static bool $schede = false;

	/**
	 * Vero se nella pagina c'e' almeno un carosello.
	 */
	private static bool $caroselli = false;

	/**
	 * Aggancia tutto. Si chiama al caricamento del plugin.
	 */
	public static function init(): void {
		// init, non prima: a quel punto il tema e' caricato e si puo' sapere di che tipo e'.
		add_action( 'init', array( self::class, 'boot' ), 5 );
	}

	/**
	 * Un blocco dichiara di essere animato.
	 *
	 * Lo chiama render.php. Due effetti: il foglio di stile ricevera' anche le
	 * regole delle animazioni, e viene caricato lo script che se ne accorge.
	 * Se nella pagina non c'e' nessun blocco animato, non si carica niente.
	 */
	public static function use_animations(): void {
		if ( self::$animazioni ) {
			return;
		}

		self::$animazioni = true;

		// Lo script va in fondo alla pagina: li' arriva sempre in tempo, anche
		// nei temi vecchio stile dove il contenuto si costruisce dopo wp_head.
		wp_enqueue_script(
			'emme-animazioni',
			EMME_BLOCKS_URL . 'shared/animazioni.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Un blocco dichiara di avere un'immagine ingrandibile.
	 *
	 * Stessa logica delle animazioni: se nella pagina non c'e' niente da
	 * ingrandire, non si carica niente. Il foglio finisce dentro lo stesso
	 * tag <style> delle regole dei blocchi, lo script in fondo alla pagina.
	 */
	public static function use_lightbox(): void {
		if ( self::$lightbox ) {
			return;
		}

		self::$lightbox = true;

		wp_enqueue_script(
			'emme-lightbox',
			EMME_BLOCKS_URL . 'shared/lightbox.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Un contenitore dichiara di avere lo sfondo animato.
	 *
	 * Stessa logica delle animazioni e della lightbox: in una pagina senza
	 * sfondi animati non si carica niente. Lo script che disegna pesa pochi
	 * chilobyte ed e' roba nostra: non arriva da nessun altro server.
	 *
	 * Qui si carica solo lo SCRIPT. L'impalcatura CSS — la tela dietro al
	 * contenuto, la sfumatura di riserva — sta invece nel foglio del blocco
	 * contenitore, come gia' il velo colorato: cosi' c'e' una fonte sola e
	 * l'editor la vede senza doverla riscrivere.
	 */
	public static function use_sfondo(): void {
		if ( self::$sfondo ) {
			return;
		}

		self::$sfondo = true;

		wp_enqueue_script(
			'emme-sfondo-animato',
			EMME_BLOCKS_URL . 'shared/sfondo-animato.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Una scheda a due facce dichiara di esserci.
	 *
	 * Il giro lo fa il CSS, che sta nel foglio del blocco. Questo script
	 * aggiunge soltanto il tocco sui telefoni e il clic che rigira indietro:
	 * senza, la scheda funziona lo stesso al passaggio del mouse e con il
	 * tabulatore.
	 */
	public static function use_schede(): void {
		if ( self::$schede ) {
			return;
		}

		self::$schede = true;

		wp_enqueue_script(
			'emme-scheda-due-facce',
			EMME_BLOCKS_URL . 'shared/scheda-due-facce.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Un carosello dichiara di esserci.
	 *
	 * Qui lo script non e' un di piu': senza, il carosello resta una pila di
	 * diapositive. E' voluto — una pila si legge, un mucchio di riquadri
	 * sovrapposti no — ma vuol dire che il blocco va usato solo dove lo
	 * script puo' arrivare.
	 */
	public static function use_carosello(): void {
		if ( self::$caroselli ) {
			return;
		}

		self::$caroselli = true;

		wp_enqueue_script(
			'emme-carosello',
			EMME_BLOCKS_URL . 'shared/carosello.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Legge i punti di rottura e decide dove stampare.
	 */
	public static function boot(): void {
		/**
		 * Permette di cambiare i punti di rottura sito per sito.
		 *
		 * Attenzione: cambiarli dopo che un sito e' online significa rivedere
		 * le pagine. Vanno fissati prima della consegna.
		 *
		 * @param array<string, int|null> $breakpoints Larghezze massime in pixel.
		 */
		$breakpoints = apply_filters( 'emme_breakpoints', Builder::breakpoints() );

		if ( is_array( $breakpoints ) ) {
			Builder::set_breakpoints( $breakpoints );
		}

		$hook = function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ? 'wp_head' : 'wp_footer';

		// Priorita' 20: dopo i fogli di stile gia' stampati, cosi' a parita' di
		// specificita' vincono le nostre regole.
		add_action( $hook, array( self::class, 'print_styles' ), 20 );

		add_action( 'enqueue_block_editor_assets', array( self::class, 'send_breakpoints_to_editor' ) );
	}

	/**
	 * Consegna all'editor i punti di rottura in uso.
	 *
	 * L'editor deve costruire le stesse regole del sito, media query comprese.
	 * Se i due avessero numeri diversi, l'anteprima mentirebbe: ecco perche'
	 * il valore e' uno solo, sta in PHP, e viaggia da li' verso l'editor.
	 */
	public static function send_breakpoints_to_editor(): void {
		$breakpoints = Builder::breakpoints();

		wp_add_inline_script(
			'wp-blocks',
			'window.emmeBreakpoints = ' . wp_json_encode(
				array(
					'tablet' => (int) $breakpoints['tablet'],
					'mobile' => (int) $breakpoints['mobile'],
				)
			) . ';',
			'before'
		);
	}

	/**
	 * Stampa in pagina il foglio di stile dei blocchi presenti.
	 */
	public static function print_styles(): void {
		// Le regole delle animazioni vengono prima: cosi' le impostazioni del
		// singolo blocco, scritte dopo, possono sovrascriverle.
		$css  = self::$animazioni ? self::file_css( 'animazioni.css' ) : '';
		$css .= self::$lightbox ? self::file_css( 'lightbox.css' ) : '';
		$css .= Builder::is_empty() ? '' : Builder::stylesheet();

		if ( '' === $css ) {
			return;
		}

		// I valori sono gia' filtrati dal Builder, che rifiuta "</". Questo e' un
		// secondo giro di chiave: se un domani la tabella delle corrispondenze
		// contenesse qualcosa di distratto, non si esce comunque dal tag style.
		$css = str_replace( '</', '', $css );

		printf( "<style id=\"emme-blocks-inline\">%s</style>\n", $css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS gia filtrato dal Builder.

		if ( self::$animazioni ) {
			self::print_animations_guard();
		}
	}

	/**
	 * La riga che accende le animazioni, e la rete di sicurezza che le spegne.
	 *
	 * Le regole che nascondono i blocchi animati valgono solo dentro la classe
	 * emme-anim-attive, che viene messa qui. Due conseguenze volute:
	 *
	 * - senza JavaScript la classe non arriva mai, quindi niente si nasconde e
	 *   il contenuto si legge lo stesso;
	 * - se il JavaScript c'e' ma lo script delle animazioni non arriva (rete,
	 *   blocchi del browser, un errore), dopo tre secondi la classe si toglie da
	 *   sola e il contenuto compare.
	 *
	 * Un contenuto che sparisce perche' uno script non ha caricato e' il
	 * difetto peggiore che questo genere di animazioni possa avere, e succede
	 * su moltissimi siti veri. Qui non puo' succedere.
	 *
	 * Sta in testa alla pagina, insieme al foglio di stile, per non far
	 * comparire e poi sparire i blocchi.
	 */
	private static function print_animations_guard(): void {
		echo '<script id="emme-animazioni-guardia">'
			. "document.documentElement.classList.add('emme-anim-attive');"
			. 'setTimeout(function(){'
			. 'if(!window.emmeAnimazioniAvviate){'
			. "document.documentElement.classList.remove('emme-anim-attive');"
			. '}},3000);'
			. "</script>\n";
	}

	/**
	 * Legge uno dei nostri fogli di stile e lo alleggerisce.
	 *
	 * Sono file nostri, scritti a mano: niente da filtrare, solo commenti e
	 * spazi da togliere perche' finiscono dentro la pagina.
	 *
	 * @param string $nome Nome del file dentro shared/.
	 */
	private static function file_css( string $nome ): string {
		$file = dirname( __DIR__, 2 ) . '/shared/' . $nome;

		if ( ! is_readable( $file ) ) {
			return '';
		}

		$css = (string) file_get_contents( $file );

		$css = (string) preg_replace( '#/\*.*?\*/#s', '', $css );
		$css = (string) preg_replace( '/\s+/', ' ', $css );
		$css = str_replace( array( ' {', '{ ', ' }', '} ', ': ', '; ', ', ' ), array( '{', '{', '}', '}', ':', ';', ',' ), $css );

		return trim( $css );
	}
}
