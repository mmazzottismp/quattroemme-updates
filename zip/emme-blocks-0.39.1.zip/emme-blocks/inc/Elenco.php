<?php
/**
 * Le domande dell'elenco: quali articoli, quanti, in che ordine.
 *
 * PERCHE' STA FUORI DAL RENDER
 *
 * Perche' e' l'unico pezzo dell'elenco che si puo' provare senza disegnare
 * niente: si danno gli attributi, si guarda la domanda che ne esce. Dentro a
 * `render.php` sarebbe mescolata al markup e si potrebbe controllare solo
 * guardando l'HTML, cioe' tardi e male.
 *
 * I LIMITI NON SONO PRUDENZA, SONO PROTEZIONE.
 *
 * `quanti` e' limitato a 50. Un elenco senza limite, messo in una pagina di
 * un sito con diecimila articoli, li carica tutti: la pagina non si apre
 * piu' e non c'e' nessun messaggio che spieghi perche'. Chi ha bisogno di
 * mostrarne di piu' usa la paginazione, non un numero piu' grande.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Costruisce la domanda da fare a WordPress.
 */
final class Elenco {

	/**
	 * Quanti articoli al massimo puo' chiedere un elenco solo.
	 */
	public const MASSIMO = 50;

	/**
	 * I modi di ordinare, e come si traducono per WordPress.
	 *
	 * Le parole a sinistra sono quelle che si scelgono nel pannello; quelle a
	 * destra sono di WordPress. Tenerle separate vuol dire che il pannello
	 * puo' parlare come parla una persona - «dal piu' recente» - senza
	 * inventare niente sotto.
	 */
	private const ORDINI = array(
		'recenti' => array( 'orderby' => 'date', 'order' => 'DESC' ),
		'vecchi'  => array( 'orderby' => 'date', 'order' => 'ASC' ),
		'titolo'  => array( 'orderby' => 'title', 'order' => 'ASC' ),
		'casuale' => array( 'orderby' => 'rand', 'order' => 'DESC' ),
		'mano'    => array( 'orderby' => 'menu_order title', 'order' => 'ASC' ),
	);

	/**
	 * I modi di ordinare che il pannello offre.
	 *
	 * @return string[]
	 */
	public static function ordini(): array {
		return array_keys( self::ORDINI );
	}

	/**
	 * La domanda da fare a WordPress, a partire dagli attributi del blocco.
	 *
	 * @param array<string, mixed> $attributes Attributi del blocco.
	 * @param int                  $corrente   L'articolo che si sta leggendo, o 0.
	 * @return array<string, mixed> Argomenti per WP_Query.
	 */
	public static function domanda( array $attributes, int $corrente = 0 ): array {
		$tipo = (string) ( $attributes['tipo'] ?? 'post' );

		// Un tipo di contenuto che non esiste, o che non si mostra in
		// pagina, non si chiede: si ripiega sugli articoli.
		if ( ! post_type_exists( $tipo ) || ! is_post_type_viewable( $tipo ) ) {
			$tipo = 'post';
		}

		$quanti = (int) ( $attributes['quanti'] ?? 6 );
		$quanti = max( 1, min( self::MASSIMO, $quanti ) );

		$salta = max( 0, (int) ( $attributes['salta'] ?? 0 ) );

		$ordine = (string) ( $attributes['ordine'] ?? 'recenti' );
		$ordine = isset( self::ORDINI[ $ordine ] ) ? $ordine : 'recenti';

		$domanda = array(
			'post_type'           => $tipo,
			'post_status'         => 'publish',
			'posts_per_page'      => $quanti,
			'offset'              => $salta,
			'orderby'             => self::ORDINI[ $ordine ]['orderby'],
			'order'               => self::ORDINI[ $ordine ]['order'],
			'ignore_sticky_posts' => true,

			/*
			 * Niente conteggio totale: senza paginazione non serve a nessuno,
			 * ed e' una seconda interrogazione al database su ogni pagina che
			 * contiene un elenco. Quando la paginazione arrivera', questa
			 * riga tornera' `true` dove serve.
			 */
			'no_found_rows'       => true,
		);

		// Il filtro per termine: «solo gli articoli della categoria Eventi».
		$tassonomia = (string) ( $attributes['tassonomia'] ?? '' );
		$termini    = $attributes['termini'] ?? array();

		if ( '' !== $tassonomia && is_array( $termini ) && array() !== $termini && taxonomy_exists( $tassonomia ) ) {
			$puliti = array_values( array_filter( array_map( 'intval', $termini ) ) );

			if ( array() !== $puliti ) {
				$domanda['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy' => $tassonomia,
						'field'    => 'term_id',
						'terms'    => $puliti,
					),
				);
			}
		}

		/*
		 * L'ARTICOLO CHE SI STA GIA' LEGGENDO SI TOGLIE, di fabbrica.
		 *
		 * Serve al caso piu' comune di tutti: «altri articoli» in fondo alla
		 * pagina di un articolo. Trovarci dentro quello che si sta leggendo
		 * e' il genere di dettaglio che nessuno nota mentre costruisce e che
		 * tutti notano guardando il sito finito.
		 */
		if ( $corrente > 0 && ! empty( $attributes['escludiCorrente'] ) ) {
			$domanda['post__not_in'] = array( $corrente );
		}

		return $domanda;
	}
}
