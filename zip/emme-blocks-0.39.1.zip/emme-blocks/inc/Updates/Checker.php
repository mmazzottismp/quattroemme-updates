<?php
/**
 * Controllo degli aggiornamenti del plugin.
 *
 * Stesso meccanismo del tema, ma per i plugin: l'intestazione "Update URI" nel
 * file principale indica il nostro scaffale su GitHub Pages, e WordPress chiama
 * il filtro update_plugins_<nome del server>. Noi rispondiamo con l'ultima
 * versione disponibile; il confronto con quella installata lo fa WordPress.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Updates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Interroga lo scaffale degli aggiornamenti e risponde a WordPress.
 */
final class Checker {

	/**
	 * Indirizzo dello scaffale.
	 */
	private const BASE_URL = 'https://mmazzottismp.github.io/quattroemme-updates/';

	/**
	 * Nome del server, da cui WordPress costruisce il nome del filtro.
	 */
	private const HOST = 'mmazzottismp.github.io';

	/**
	 * Il nome con cui la risposta si ricorda fino alla prossima volta.
	 *
	 * C'erano due canali, `stabile` e `pilota`. Tolti il 19/11/2026: ogni
	 * versione finiva su tutti e due lo stesso giorno, compresa una rotta.
	 * Lo scaffale pubblica ancora ai vecchi indirizzi, perche' e' il codice
	 * gia' installato a decidere dove guardare.
	 */
	private const MEMORIA = 'emme_blocks_update';

	/**
	 * Nome della cartella del plugin, usato come nome del file di testo.
	 */
	private const SLUG = 'emme-blocks';

	/**
	 * Aggancia il controllo ai meccanismi di WordPress.
	 */
	public static function init(): void {
		add_filter( 'update_plugins_' . self::HOST, array( self::class, 'respond' ), 10, 3 );
		add_action( 'upgrader_process_complete', array( self::class, 'forget' ) );
	}

	/**
	 * Risponde quando WordPress chiede se c'e' una versione nuova.
	 *
	 * @param array<string, mixed>|false $update      Risposta di chi ci ha preceduto.
	 * @param array<string, mixed>       $plugin_data Intestazioni del plugin.
	 * @param string                     $plugin_file Percorso del plugin, es. emme-blocks/emme-blocks.php.
	 * @return array<string, mixed>|false
	 */
	public static function respond( $update, array $plugin_data, string $plugin_file ) {
		// Se qualcun altro ha gia' risposto, o non si parla di noi, non tocchiamo niente.
		if ( false !== $update || self::SLUG . '/' . self::SLUG . '.php' !== $plugin_file ) {
			return $update;
		}

		$manifest = self::manifest( self::controllo_forzato() );

		if ( null === $manifest || empty( $manifest['package'] ) ) {
			return $update;
		}

		// L'indirizzo del pacchetto arriva dal file del canale, cioe' da fuori.
		// Deve stare sotto il nostro indirizzo: se un giorno finisse li' dentro un
		// file sbagliato - una configurazione storta dello scaffale, una modifica
		// entrata per errore - quel file potrebbe mandare TUTTI i siti dei clienti
		// a scaricare un pacchetto di qualcun altro, che viene installato ed
		// eseguito. Con questo controllo, per farlo servirebbero due errori invece
		// di uno.
		if ( ! self::nostro_indirizzo( (string) $manifest['package'] ) ) {
			return $update;
		}

		return array(
			'slug'         => self::SLUG,
			'version'      => (string) $manifest['version'],
			'url'          => (string) ( $manifest['url'] ?? '' ),
			'package'      => (string) $manifest['package'],
			'tested'       => (string) ( $manifest['tested'] ?? '' ),
			'requires_php' => (string) ( $manifest['requires_php'] ?? '' ),
		);
	}

	/**
	 * Dice se un indirizzo sta davvero sotto il nostro scaffale.
	 *
	 * Si confronta l'inizio della stringa dopo averla normalizzata, e si
	 * pretende https: su http qualcuno sulla stessa rete potrebbe sostituire
	 * il pacchetto durante il viaggio.
	 *
	 * @param string $url Indirizzo da controllare.
	 * @return bool Vero se possiamo fidarci.
	 */
	private static function nostro_indirizzo( string $url ): bool {
		$pulito = esc_url_raw( trim( $url ) );

		if ( '' === $pulito || 0 !== strpos( $pulito, 'https://' ) ) {
			return false;
		}

		return 0 === strpos( $pulito, self::BASE_URL );
	}

	/**
	 * Dice se WordPress sta facendo un controllo CHIESTO, non di routine.
	 *
	 * Il pulsante «Controlla di nuovo» ricarica con `force-check=1`. Senza
	 * guardarlo, chi lo preme si riprende il manifesto vecchio dalla nostra
	 * memoria temporanea e non succede niente.
	 *
	 * @return bool Vero se il controllo e' stato chiesto a mano.
	 */
	private static function controllo_forzato(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Solo la presenza del parametro, nessuna decisione.
		return ! empty( $_GET['force-check'] );
	}

	/**
	 * Legge il file di testo del canale, con memoria temporanea di un'ora.
	 *
	 * Non deve durare piu' della strozzatura di WordPress stesso - che sulla
	 * pagina dei plugin e' di un'ora - se no e' sempre la nostra a decidere.
	 *
	 * @param bool $force Salta la memoria temporanea.
	 * @return array<string, mixed>|null
	 */
	public static function manifest( bool $force = false ): ?array {
		$transient_key = self::MEMORIA;

		if ( ! $force ) {
			$cached = get_site_transient( $transient_key );

			if ( is_array( $cached ) ) {
				return $cached;
			}

			if ( 'non-disponibile' === $cached ) {
				return null;
			}
		}

		$response = wp_remote_get(
			self::BASE_URL . self::SLUG . '.json',
			array(
				'timeout' => 10,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);

		$body = ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) )
			? null
			: json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $body ) || empty( $body['version'] ) ) {
			set_site_transient( $transient_key, 'non-disponibile', HOUR_IN_SECONDS );

			return null;
		}

		set_site_transient( $transient_key, $body, HOUR_IN_SECONDS );

		return $body;
	}

	/**
	 * Dimentica la memoria temporanea dopo un aggiornamento.
	 */
	public static function forget(): void {
		delete_site_transient( self::MEMORIA );

		// I nomi di quando c'erano due canali.
		delete_site_transient( 'emme_blocks_update_stabile' );
		delete_site_transient( 'emme_blocks_update_pilota' );
	}
}
