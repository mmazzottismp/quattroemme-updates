<?php
/**
 * Quali campi personalizzati esistono, e com'e' fatto ognuno.
 *
 * COS'E' UN CAMPO PERSONALIZZATO, in una riga.
 *
 * WordPress sa gia' tenere, per ogni articolo, un titolo, un testo, una data
 * di pubblicazione, delle categorie e una fotografia in evidenza. Tutto il
 * resto - le date di un corso, il luogo, il prezzo, quanti posti restano -
 * non ha un posto suo, e finisce scritto dentro al testo. Scritto li' e'
 * **prosa**: si legge, ma non si puo' ordinare, filtrare o mettere in una
 * colonna. Un campo personalizzato lo rende **dato**.
 *
 * Il magazzino e' di WordPress: i campi stanno nella sua tabella dei
 * metadati, e si leggono con `get_post_meta()`. ACF, Meta Box e Pods non
 * sono il magazzino: sono la schermata comoda per riempirlo. Questa classe e
 * le sue due sorelle sono la nostra schermata comoda.
 *
 * COSA FA QUESTO FILE, e cosa fanno gli altri due.
 *
 * - `Definizioni` (qui): l'elenco dei campi che esistono, come si legge, come
 *   si scrive, e soprattutto **come si valida**. Non chiama niente di
 *   WordPress nella parte che decide: cosi' si prova senza WordPress acceso.
 * - `Registro`: li dichiara a WordPress e li passa all'editor.
 * - `Schermata`: la pagina dove si aggiungono e si tolgono.
 *
 * PERCHE' UN'OPZIONE E NON UN TIPO DI CONTENUTO.
 *
 * ACF tiene le sue definizioni come articoli di un tipo nascosto. Per noi
 * sarebbero una manciata di righe di impostazioni: in un tipo di contenuto
 * comparirebbero negli elenchi, nelle esportazioni e nei conteggi, e per
 * leggerle servirebbe una query. Un'opzione sola si legge una volta e sta in
 * cache.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Campi;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * L'elenco dei campi personalizzati definiti su questo sito.
 */
final class Definizioni {

	/**
	 * Il nome dell'opzione che li contiene.
	 *
	 * Sta nella tabella delle opzioni di WordPress. Cambiarlo dopo il primo
	 * rilascio vorrebbe dire perdere le definizioni di chi aggiorna.
	 */
	public const OPZIONE = 'emme_campi';

	/**
	 * I tipi di campo che sappiamo disegnare.
	 *
	 * SONO POCHI APPOSTA. Ogni tipo in piu' e' una casella nel pannello, una
	 * regola di pulizia, un modo di sbagliare. Questi sette coprono quello
	 * che e' servito finora; l'ottavo si aggiunge quando serve davvero, non
	 * prima.
	 *
	 * I NOMI SONO UN CONTRATTO: finiscono scritti nelle definizioni dei
	 * clienti. Dal primo rilascio non si rinominano piu'.
	 */
	public const TIPI = array(
		'testo',
		'testolungo',
		'numero',
		'data',
		'url',
		'scelta',
		'sino',
	);

	/**
	 * Quanti campi al massimo.
	 *
	 * Non e' un limite tecnico: e' che oltre questo numero il pannello
	 * dell'editor diventa un muro, e il problema non e' piu' il nostro
	 * pannello ma come sono organizzati i contenuti.
	 */
	public const MASSIMO = 50;

	/**
	 * Quante scelte al massimo, per un campo a scelta.
	 */
	public const MASSIMO_OPZIONI = 50;

	/**
	 * Quanto puo' essere lungo il nome di un campo.
	 *
	 * La colonna `meta_key` di WordPress arriva a 255 caratteri. Cento
	 * bastano e avanzano, e lasciano spazio se un domani servisse un
	 * prefisso.
	 */
	public const MASSIMO_CHIAVE = 100;

	/**
	 * Tutti i campi definiti, gia' validati.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function tutte(): array {
		$grezze = get_option( self::OPZIONE, array() );

		return self::valida( is_array( $grezze ) ? $grezze : array() );
	}

	/**
	 * I campi che valgono per un tipo di contenuto.
	 *
	 * @param string $tipo_post Il tipo di contenuto, per esempio `post`.
	 * @return array<int, array<string, mixed>>
	 */
	public static function per_tipo_post( string $tipo_post ): array {
		$fuori = array();

		foreach ( self::tutte() as $campo ) {
			if ( in_array( $tipo_post, $campo['tipiPost'], true ) ) {
				$fuori[] = $campo;
			}
		}

		return $fuori;
	}

	/**
	 * Valida e scrive l'elenco.
	 *
	 * Restituisce quello che e' stato scritto davvero, che puo' essere meno
	 * di quello che e' arrivato: chi chiama lo confronta e dice a chi guarda
	 * cos'e' stato scartato, invece di far sparire una riga in silenzio.
	 *
	 * @param array<int, mixed> $grezze Le definizioni cosi' come arrivano.
	 * @return array<int, array<string, mixed>> Quelle buone.
	 */
	public static function salva( array $grezze ): array {
		$buone = self::valida( $grezze );

		update_option( self::OPZIONE, $buone, false );

		return $buone;
	}

	/**
	 * Tiene solo le definizioni sensate, e le mette in forma.
	 *
	 * NON CHIAMA NIENTE DI WORDPRESS. E' la parte che decide, ed e' quella
	 * che va provata: una funzione che per girare ha bisogno di un sito
	 * acceso si finisce per non provarla.
	 *
	 * Quello che non e' valido si **scarta**, non si corregge a indovinare -
	 * tranne dove c'e' un valore ovvio: un tipo sconosciuto diventa testo, e
	 * un campo senza nome prende la propria chiave come nome.
	 *
	 * @param array<int, mixed> $grezze Le definizioni cosi' come arrivano.
	 * @return array<int, array<string, mixed>>
	 */
	public static function valida( array $grezze ): array {
		$fuori = array();
		$viste = array();

		foreach ( $grezze as $grezza ) {
			if ( ! is_array( $grezza ) ) {
				continue;
			}

			$chiave = self::pulisci_chiave( (string) ( $grezza['chiave'] ?? '' ) );

			if ( '' === $chiave || isset( $viste[ $chiave ] ) ) {
				continue;
			}

			$viste[ $chiave ] = true;

			$tipo = (string) ( $grezza['tipo'] ?? 'testo' );

			if ( ! in_array( $tipo, self::TIPI, true ) ) {
				$tipo = 'testo';
			}

			$nome = trim( (string) ( $grezza['nome'] ?? '' ) );

			$campo = array(
				'chiave'   => $chiave,
				'nome'     => '' !== $nome ? $nome : $chiave,
				'tipo'     => $tipo,
				'aiuto'    => trim( (string) ( $grezza['aiuto'] ?? '' ) ),
				'opzioni'  => 'scelta' === $tipo ? self::pulisci_opzioni( $grezza['opzioni'] ?? array() ) : array(),
				'tipiPost' => self::pulisci_tipi_post( $grezza['tipiPost'] ?? array() ),
			);

			/*
			 * UN CAMPO A SCELTA SENZA SCELTE non e' un campo: nel pannello
			 * sarebbe un menu vuoto, e chi lo apre pensa che sia rotto.
			 */
			if ( 'scelta' === $tipo && array() === $campo['opzioni'] ) {
				continue;
			}

			$fuori[] = $campo;

			if ( count( $fuori ) >= self::MASSIMO ) {
				break;
			}
		}

		return $fuori;
	}

	/**
	 * Il nome del campo, ripulito, o vuoto se non va bene.
	 *
	 * LE REGOLE, E PERCHE'.
	 *
	 * - solo lettere minuscole, cifre e sottolineature: e' la convenzione di
	 *   WordPress, e una chiave con spazi o accenti si trasforma in modi
	 *   diversi a seconda di chi la legge;
	 * - deve cominciare con una lettera: una chiave che comincia con una
	 *   **sottolineatura** e' «protetta», cioe' di servizio, e WordPress non
	 *   la mostra e non la espone - ce n'e' una prova apposta in
	 *   `tests/prove-visibilita.php`;
	 * - lunghezza fra due e cento.
	 *
	 * @param string $grezza Il nome cosi' come e' stato scritto.
	 * @return string Il nome buono, o stringa vuota.
	 */
	public static function pulisci_chiave( string $grezza ): string {
		$chiave = strtolower( trim( $grezza ) );

		if ( 1 !== preg_match( '/^[a-z][a-z0-9_]{1,' . ( self::MASSIMO_CHIAVE - 1 ) . '}$/', $chiave ) ) {
			return '';
		}

		return $chiave;
	}

	/**
	 * Le scelte di un campo a scelta.
	 *
	 * @param mixed $grezze Quello che e' arrivato: un elenco, o del testo a righe.
	 * @return string[]
	 */
	private static function pulisci_opzioni( mixed $grezze ): array {
		if ( is_string( $grezze ) ) {
			$grezze = preg_split( '/\r\n|\r|\n/', $grezze );
		}

		if ( ! is_array( $grezze ) ) {
			return array();
		}

		$fuori = array();

		foreach ( $grezze as $una ) {
			if ( ! is_scalar( $una ) ) {
				continue;
			}

			$pulita = trim( (string) $una );

			if ( '' === $pulita || in_array( $pulita, $fuori, true ) ) {
				continue;
			}

			$fuori[] = $pulita;

			if ( count( $fuori ) >= self::MASSIMO_OPZIONI ) {
				break;
			}
		}

		return $fuori;
	}

	/**
	 * I tipi di contenuto su cui il campo compare.
	 *
	 * Vuoto vuol dire «gli articoli», che e' il caso di gran lunga piu'
	 * frequente: un campo senza tipo dichiarato sparirebbe da tutte le
	 * schermate senza che si capisca perche'.
	 *
	 * @param mixed $grezzi Quello che e' arrivato.
	 * @return string[]
	 */
	private static function pulisci_tipi_post( mixed $grezzi ): array {
		if ( ! is_array( $grezzi ) ) {
			return array( 'post' );
		}

		$fuori = array();

		foreach ( $grezzi as $uno ) {
			if ( ! is_scalar( $uno ) ) {
				continue;
			}

			$pulito = strtolower( trim( (string) $uno ) );

			if ( 1 !== preg_match( '/^[a-z][a-z0-9_-]{0,19}$/', $pulito ) || in_array( $pulito, $fuori, true ) ) {
				continue;
			}

			$fuori[] = $pulito;
		}

		return array() !== $fuori ? $fuori : array( 'post' );
	}
}
