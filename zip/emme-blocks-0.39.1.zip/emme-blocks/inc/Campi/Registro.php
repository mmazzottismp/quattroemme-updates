<?php
/**
 * Dichiara i campi personalizzati a WordPress, e li passa all'editor.
 *
 * PERCHE' NON BASTA SCRIVERLI NELLA TABELLA.
 *
 * `update_post_meta()` scrive un campo senza chiedere permesso a nessuno. Ma
 * un campo che nessuno ha **dichiarato** non esiste per l'editor: le API REST
 * - da cui l'editor a blocchi legge e scrive tutto - espongono solo i campi
 * registrati con `register_post_meta()` e `show_in_rest`. Senza la
 * dichiarazione il nostro pannello leggerebbe sempre vuoto e scriverebbe nel
 * nulla, **senza nessun errore**.
 *
 * La dichiarazione serve anche a tre cose che altrimenti toccherebbe
 * rifarsi a mano a ogni salvataggio:
 *
 * - `sanitize_callback`: la pulizia del valore, decisa in un posto solo;
 * - `auth_callback`: chi puo' scriverlo. Senza, WordPress rifiuta di
 *   esporre il campo;
 * - `default`: cosi' un articolo che non l'ha mai avuto risponde con il
 *   vuoto invece che con niente, e l'editor non deve indovinare.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Campi;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registra i campi e accoda il pannello dell'editor.
 */
final class Registro {

	/**
	 * L'handle dello script del pannello.
	 */
	public const HANDLE = 'emme-pannello-campi';

	/**
	 * Il nome del file compilato, senza estensione.
	 */
	public const FILE = 'pannello-campi';

	/**
	 * Aggancia le due chiamate.
	 *
	 * La registrazione su `init` a priorita' 20: i tipi di contenuto di un
	 * altro plugin si registrano su `init` a priorita' normale, e dichiarare
	 * un campo per un tipo che non esiste ancora non attacca.
	 */
	public static function init(): void {
		add_action( 'init', array( self::class, 'registra' ), 20 );
		add_action( 'enqueue_block_editor_assets', array( self::class, 'accoda' ) );
	}

	/**
	 * Dichiara a WordPress ogni campo, per ogni tipo di contenuto che lo usa.
	 */
	public static function registra(): void {
		foreach ( Definizioni::tutte() as $campo ) {
			foreach ( $campo['tipiPost'] as $tipo_post ) {
				register_post_meta(
					$tipo_post,
					$campo['chiave'],
					array(
						'type'              => self::tipo_rest( $campo['tipo'] ),
						'single'            => true,
						'default'           => self::vuoto( $campo['tipo'] ),
						'show_in_rest'      => true,
						'description'       => $campo['nome'],
						'sanitize_callback' => static function ( $valore ) use ( $campo ) {
							return self::pulisci( $campo, $valore );
						},
						'auth_callback'     => static function ( $permesso, $chiave, $quale ) {
							unset( $permesso, $chiave );

							return current_user_can( 'edit_post', (int) $quale );
						},
					)
				);
			}
		}
	}

	/**
	 * Accoda lo script del pannello e gli passa le definizioni.
	 */
	public static function accoda(): void {
		$campi = Definizioni::tutte();

		// Nessun campo definito: non c'e' niente da disegnare, e uno script
		// che non serve si evita invece di caricarlo e farlo tacere.
		if ( array() === $campi ) {
			return;
		}

		$asset = EMME_BLOCKS_PATH . 'build/' . self::FILE . '.asset.php';

		if ( ! file_exists( $asset ) ) {
			return;
		}

		/**
		 * Dipendenze e versione, scritte dalla compilazione.
		 *
		 * @var array{dependencies: string[], version: string} $dati
		 */
		$dati = require $asset;

		wp_enqueue_script(
			self::HANDLE,
			EMME_BLOCKS_URL . 'build/' . self::FILE . '.js',
			$dati['dependencies'],
			$dati['version'],
			true
		);

		/*
		 * LE DEFINIZIONI VIAGGIANO COME DATO, non come chiamata REST.
		 *
		 * L'alternativa era un'altra rotta da interrogare all'apertura
		 * dell'editor: una richiesta in piu' per una manciata di righe che
		 * il PHP ha gia' in mano mentre accoda lo script.
		 */
		wp_add_inline_script(
			self::HANDLE,
			'window.emmeCampi = ' . wp_json_encode( $campi ) . ';',
			'before'
		);

		/*
		 * Questo script NON appartiene a un blocco, quindi non passa dal giro
		 * di `Emme\Traduzioni`, che legge gli handle dal registro dei
		 * blocchi. Le sue traduzioni si indicano qui.
		 */
		wp_set_script_translations(
			self::HANDLE,
			\Emme\Traduzioni::DOMINIO,
			EMME_BLOCKS_PATH . \Emme\Traduzioni::CARTELLA
		);
	}

	/**
	 * Come WordPress deve chiamare il tipo del campo.
	 *
	 * I nomi sono i suoi, non i nostri: li usa per validare quello che arriva
	 * dalle API REST.
	 *
	 * @param string $tipo Il nostro tipo.
	 * @return string Il tipo secondo WordPress.
	 */
	public static function tipo_rest( string $tipo ): string {
		return match ( $tipo ) {
			'numero' => 'number',
			'sino'   => 'boolean',
			default  => 'string',
		};
	}

	/**
	 * Il valore di un campo mai riempito.
	 *
	 * @param string $tipo Il nostro tipo.
	 * @return string|float|bool
	 */
	public static function vuoto( string $tipo ): string|float|bool {
		return match ( $tipo ) {
			'numero' => 0.0,
			'sino'   => false,
			default  => '',
		};
	}

	/**
	 * Ripulisce il valore di un campo prima di scriverlo.
	 *
	 * @param array<string, mixed> $campo  La definizione.
	 * @param mixed                $valore Quello che e' arrivato.
	 * @return string|float|bool
	 */
	public static function pulisci( array $campo, mixed $valore ): string|float|bool {
		$tipo = (string) $campo['tipo'];

		if ( 'sino' === $tipo ) {
			return (bool) $valore;
		}

		if ( 'numero' === $tipo ) {
			return is_numeric( $valore ) ? (float) $valore : 0.0;
		}

		if ( ! is_scalar( $valore ) ) {
			return '';
		}

		$testo = trim( (string) $valore );

		if ( 'testolungo' === $tipo ) {
			return sanitize_textarea_field( $testo );
		}

		if ( 'url' === $tipo ) {
			return '' === $testo ? '' : sanitize_url( $testo );
		}

		if ( 'data' === $tipo ) {
			/*
			 * SOLO `AAAA-MM-GG`, e il vuoto.
			 *
			 * Non si tenta di interpretare quello che arriva: «03/04» e'
			 * il 3 aprile per un italiano e il 4 marzo per un americano, e
			 * indovinare vuol dire sbagliare la meta' delle volte in
			 * silenzio. La casella del pannello e' gia' un selettore di
			 * data, quindi qui arriva nella forma giusta o non arriva.
			 */
			return 1 === preg_match( '/^\d{4}-\d{2}-\d{2}$/', $testo ) ? $testo : '';
		}

		if ( 'scelta' === $tipo ) {
			$ammesse = (array) ( $campo['opzioni'] ?? array() );

			return in_array( $testo, $ammesse, true ) ? $testo : '';
		}

		return sanitize_text_field( $testo );
	}
}
