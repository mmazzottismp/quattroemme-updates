<?php
/**
 * «Quale articolo sto disegnando adesso?», in un posto solo.
 *
 * IL PROBLEMA CHE RISOLVE
 *
 * I blocchi che abbiamo fatto finora disegnano quello che hanno dentro: un
 * titolo scritto a mano, una fotografia scelta a mano. I blocchetti nuovi
 * fanno un'altra cosa: disegnano **un pezzo di un articolo**, e quale
 * articolo non lo sanno finche' non glielo si dice.
 *
 * Glielo dice WordPress, con il **contesto**: due informazioni, `postId` e
 * `postType`, che scendono dall'alto fino al blocco. Il meccanismo e' lo
 * stesso che usano tutti i blocchi del nucleo - misurato il 15/11/2026 in
 * `wp-includes/blocks/blocks-json.php`:
 *
 *     core/post-title           prende ["postId", "postType", "queryId"]
 *     core/post-date            prende ["postId", "postType", "queryId"]
 *     core/post-featured-image  prende ["postId", "postType", "queryId"]
 *     core/post-terms           prende ["postId", "postType"]
 *
 * Da dove arriva quel contesto cambia a seconda di dove sta il blocco, e
 * sono **tre** casi che vanno tutti e tre:
 *
 * 1. **dentro a un elenco** - `core/post-template` lo cambia a ogni giro:
 *    primo giro l'articolo 7, secondo giro l'articolo 12;
 * 2. **nello stampo dell'articolo singolo** - e' l'articolo che si sta
 *    leggendo, e lo mette WordPress dalla richiesta;
 * 3. **in mezzo a una pagina qualsiasi** - li' non c'e' nessun contesto, e
 *    il blocco non deve disegnare niente invece di disegnare una cosa a
 *    caso.
 *
 * PERCHE' UNA CLASSE E NON QUATTRO RIGHE PER BLOCCO
 *
 * Perche' e' gia' successo quattro volte - sfondo animato, velo, titolo e
 * fisarmonica, ancoraggio - che una cosa valida per piu' blocchi finisse
 * scritta dentro a uno solo. Qui i blocchetti saranno sei, e tutti e sei
 * cominciano con la stessa domanda.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Risale all'articolo che un blocchetto sta disegnando.
 */
final class Contenuto {

	/**
	 * Le due chiavi di contesto che ogni blocchetto deve dichiarare.
	 *
	 * Si scrive qui e nei `block.json`, e una prova controlla che le due
	 * meta' dicano la stessa cosa: un blocchetto che si dimentica di
	 * dichiararle non riceve niente e disegna il vuoto, senza errori.
	 */
	public const CONTESTO = array( 'postId', 'postType' );

	/**
	 * L'identificativo dell'articolo da disegnare, o zero.
	 *
	 * Zero vuol dire «non lo so»: il blocco e' stato messo dove nessuno gli
	 * dice di quale articolo parlare. In quel caso non si indovina - si
	 * disegna il vuoto.
	 *
	 * @param \WP_Block|null $block Il blocco in corso di resa.
	 * @return int
	 */
	public static function quale( ?\WP_Block $block ): int {
		$dal_contesto = $block->context['postId'] ?? null;

		if ( is_numeric( $dal_contesto ) && (int) $dal_contesto > 0 ) {
			return (int) $dal_contesto;
		}

		/*
		 * Nessun contesto: siamo nello stampo di un articolo singolo, o in
		 * una pagina. `get_the_ID()` risponde con l'articolo della
		 * richiesta, e restituisce `false` quando non c'e' nemmeno quello.
		 */
		$corrente = get_the_ID();

		return is_int( $corrente ) && $corrente > 0 ? $corrente : 0;
	}

	/**
	 * Il tipo di contenuto, per i casi in cui serve distinguerlo.
	 *
	 * @param \WP_Block|null $block Il blocco in corso di resa.
	 * @return string Vuoto se non si sa.
	 */
	public static function tipo( ?\WP_Block $block ): string {
		$dal_contesto = $block->context['postType'] ?? null;

		if ( is_string( $dal_contesto ) && '' !== $dal_contesto ) {
			return $dal_contesto;
		}

		$quale = self::quale( $block );

		return $quale > 0 ? (string) get_post_type( $quale ) : '';
	}

	/**
	 * Se il blocchetto puo' disegnare qualcosa.
	 *
	 * Il controllo non e' solo «c'e' un identificativo»: un articolo in
	 * bozza o nel cestino non si mostra a chi passa di li'. Si usa
	 * `is_post_publicly_viewable()`, che WordPress espone dalla 5.7 e che
	 * tiene conto anche dei tipi di contenuto non pubblici.
	 *
	 * @param \WP_Block|null $block Il blocco in corso di resa.
	 * @return bool
	 */
	public static function si_puo_mostrare( ?\WP_Block $block ): bool {
		$quale = self::quale( $block );

		if ( 0 === $quale ) {
			return false;
		}

		/*
		 * Chi puo' modificare l'articolo lo vede comunque: e' il caso
		 * dell'anteprima di una bozza, dove il contenuto non e' ancora
		 * pubblico ma chi guarda e' chi lo sta scrivendo.
		 */
		if ( is_post_publicly_viewable( $quale ) ) {
			return true;
		}

		return current_user_can( 'edit_post', $quale );
	}

	/**
	 * Se l'articolo e' chiuso da una password che chi guarda non ha dato.
	 *
	 * PERCHE' NON BASTA `si_puo_mostrare()`.
	 *
	 * `is_post_publicly_viewable()` guarda **due cose sole**: che il tipo di
	 * contenuto sia visibile e che lo stato lo sia. Letto in
	 * `wp-includes/post.php` il 16/11/2026:
	 *
	 *     return is_post_type_viewable( $post_type ) && is_post_status_viewable( $post_status );
	 *
	 * La password **non c'entra**: un articolo pubblicato e protetto e'
	 * pubblicamente visibile per quella funzione. Ed e' giusto che lo sia,
	 * perche' negli elenchi WordPress lo mostra davvero - con il titolo
	 * prefissato da «Protetto:» e il testo sostituito dal modulo della
	 * password.
	 *
	 * Quindi la password e' una domanda **separata**, e se la fanno solo i
	 * blocchetti che tirano fuori del contenuto: il riassunto e i campi. Il
	 * titolo non la fa, perche' `get_the_title()` ci mette gia' il prefisso
	 * da solo; la data e la fotografia nemmeno, che e' quello che fanno i
	 * blocchi del nucleo.
	 *
	 * Chi puo' modificare l'articolo lo legge comunque: e' il caso
	 * dell'editor, dove chi guarda e' chi lo sta scrivendo.
	 *
	 * @param \WP_Block|null $block Il blocco in corso di resa.
	 * @return bool
	 */
	public static function protetto( ?\WP_Block $block ): bool {
		$quale = self::quale( $block );

		if ( 0 === $quale ) {
			return true;
		}

		if ( ! post_password_required( $quale ) ) {
			return false;
		}

		return ! current_user_can( 'edit_post', $quale );
	}
}
