<?php
/**
 * Il gruppo al passaggio del mouse, in un posto solo.
 *
 * PERCHE' ESISTE QUESTA CLASSE
 *
 * Fino al 13/11/2026 il pannello «Al passaggio del mouse» sapeva fare una
 * cosa sola: il blocco cambia se stesso. Misurando orange1.eu e' venuto fuori
 * che **quattro dei sei effetti del sito** sono l'altra cosa - il mouse sta
 * sul genitore e cambia il figlio:
 *
 *     .o1-links8__item:hover .o1-media img       → ingrandisce a 1,05
 *     .o1-links8__item:hover .o1-links8__overlay → il velo scurisce
 *     .o1-links8__item:hover .o1-links8__plus    → il cerchio si riempie
 *     .o1-grid4__links:hover .o1-grid4__link     → i fratelli si spengono
 *
 * COME FUNZIONA, IN DUE META'
 *
 * Un blocco figlio non sa chi lo contiene: il contesto che un gruppo passa ai
 * figli e' lo stesso per tutti, e l'indice non c'e'. E' la stessa ragione per
 * cui le carte del mazzo ricevono la posizione da una regola `:nth-child()`
 * scritta dal gruppo.
 *
 * Qui pero' il figlio non ha bisogno di sapere CHI e' il genitore: gli basta
 * che esista un antenato marcato. Quindi:
 *
 * - il **genitore** accende «Gruppo al passaggio del mouse» e si marca con
 *   `data-emme-hov`, che e' quello che fa questa classe;
 * - il **figlio** sceglie, nel suo pannello, se l'effetto scatta su di lui,
 *   sul gruppo, oppure sul gruppo tranne che su di lui - e il generatore gli
 *   scrive il selettore giusto (vedi `Builder::hover_selector()`).
 *
 * Nessuno script: e' tutto CSS, con il combinatore di discendenza che c'e'
 * da sempre.
 *
 * PERCHE' UN FILTRO SOLO INVECE DI UNA RIGA IN OGNI RENDER
 *
 * E' gia' successo quattro volte - sfondo animato, velo, titolo e
 * fisarmonica, ancoraggio - che una possibilita' offerta da tutti i blocchi
 * fosse onorata da uno solo: le righe che la facevano funzionare stavano
 * dentro al render di un blocco, e chi copiava il pannello non copiava
 * quelle. La soluzione di allora era una classe condivisa che i render
 * chiamano, piu' una prova che diventa rossa se qualcuno si dimentica.
 *
 * Qui si puo' fare meglio, perche' questa cosa **non ha bisogno di markup
 * suo**: e' un attributo sul tag piu' esterno, e il tag piu' esterno
 * WordPress ce l'ha gia' in mano. Quindi niente riga da ricordarsi: il
 * filtro `render_block` passa l'HTML di **ogni** blocco, e il marcatore lo
 * mette qui `WP_HTML_Tag_Processor`, che e' API stabile dalla 6.2 e il
 * plugin chiede la 6.6.
 *
 * Il vantaggio non e' la comodita': e' che **un blocco nuovo funziona senza
 * fare niente**, compresi i blocchi che oggi escludono il pannello e che un
 * domani potrebbero volerlo.
 *
 * Il marcatore finisce sul primo tag dell'HTML reso. Per il contenitore
 * ancorato quello e' il segnaposto che lo avvolge, non il blocco: va bene
 * lo stesso, perche' il segnaposto e' comunque un antenato dei figli, ed e'
 * esattamente quello che il selettore cerca.
 *
 * NELL'EDITOR NON SI VEDE, e non e' una dimenticanza: nell'editor il blocco
 * lo disegna il JavaScript, non questo render. Il passaggio del mouse non si
 * e' mai visto nell'editor - il pannello lo dice - e qui resta cosi'.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Marca i blocchi che si sono dichiarati gruppo al passaggio del mouse.
 */
final class Hover {

	/**
	 * L'attributo che i selettori dei figli cercano.
	 *
	 * Sta scritto qui e nel generatore, e le due meta' devono dire la stessa
	 * cosa: una prova le confronta.
	 */
	public const MARCATORE = 'data-emme-hov';

	/**
	 * Aggancia il filtro.
	 */
	public static function init(): void {
		add_filter( 'render_block', array( self::class, 'segna' ), 10, 2 );
	}

	/**
	 * Se il blocco si e' dichiarato gruppo.
	 *
	 * Non e' responsive, come tutto il gruppo `hover`: sul telefono il
	 * passaggio del mouse non esiste e non c'e' niente da decidere.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return bool
	 */
	public static function e_gruppo( array $style ): bool {
		return ! empty( $style['hover']['group'] );
	}

	/**
	 * Mette il marcatore sul tag piu' esterno del blocco reso.
	 *
	 * @param string              $html  HTML gia' reso del blocco.
	 * @param array<string, mixed> $block Il blocco analizzato.
	 * @return string Lo stesso HTML, col marcatore se serve.
	 */
	public static function segna( string $html, array $block ): string {
		/*
		 * Si esce subito, e senza toccare l'HTML, su tutto quello che non ci
		 * riguarda: i blocchi del nucleo, i nostri senza il gruppo acceso, e
		 * i blocchi che non rendono niente. Girare il processore HTML su
		 * ogni blocco di ogni pagina per niente si paga.
		 */
		if ( '' === $html ) {
			return $html;
		}

		$style = $block['attrs']['emmeStyle'] ?? null;

		if ( ! is_array( $style ) || ! self::e_gruppo( $style ) ) {
			return $html;
		}

		$tag = new \WP_HTML_Tag_Processor( $html );

		if ( ! $tag->next_tag() ) {
			return $html;
		}

		/*
		 * Il valore non serve a niente - i selettori guardano solo se
		 * l'attributo c'e' - ma un attributo vuoto nel sorgente della pagina
		 * sembra un errore a chi lo legge. Una parola che si capisce costa
		 * sei caratteri.
		 */
		$tag->set_attribute( self::MARCATORE, 'gruppo' );

		return $tag->get_updated_html();
	}
}
