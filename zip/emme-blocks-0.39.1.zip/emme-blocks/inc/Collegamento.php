<?php
/**
 * Gli attributi di un collegamento, calcolati in un posto solo.
 *
 * COSA RISOLVE
 *
 * Un indirizzo non e' mai solo un indirizzo: si porta dietro `target`, e il
 * `target` si porta dietro `rel`, e il `rel` ha dentro due parole che
 * servono per ragioni diverse. Scriverlo a mano ogni volta vuol dire
 * sbagliarlo una volta su tre, e sbagliarlo non si vede.
 *
 * LA TRAPPOLA DELLA PROTEZIONE, che e' il motivo per cui questa classe NON
 * usa `esc_url()`.
 *
 * `get_block_wrapper_attributes()` prende gli attributi extra cosi' come
 * sono e alla fine ci passa sopra `esc_attr()` - letto in
 * `wp-includes/class-wp-block-supports.php`, dove ogni valore diventa
 * `$key . '="' . esc_attr( $value ) . '"'`.
 *
 * `esc_url()` fa due cose insieme: filtra i protocolli **e** codifica per
 * l'HTML, trasformando la `&` in `&#038;`. Passandogli sopra anche
 * `esc_attr()` quella entita' verrebbe codificata una seconda volta e
 * diventerebbe `&amp;#038;`: un indirizzo con un parametro in query si
 * rompe, e si rompe in silenzio.
 *
 * Quindi qui si usa `sanitize_url()`, che e' `esc_url( $url, null, 'db' )`:
 * **filtra i protocolli e basta**. La codifica per l'HTML la mette chi
 * stampa, una volta sola.
 *
 * Chi invece costruisce la stringa dell'attributo da solo deve passare da
 * `esc_attr()` a mano: vale per `href` come per gli altri.
 *
 * DEBITO DICHIARATO
 *
 * I blocchi `button` e `image` hanno ognuno la propria copia di questo
 * calcolo, scritta prima che questa classe esistesse. Funzionano, sono
 * coperti dalle prove, e unificarli e' un lavoro suo: finche' non si fa,
 * una correzione qui **non li raggiunge**. Se si tocca il `rel`, si toccano
 * tutti e tre.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Calcola href, target e rel di un collegamento.
 */
final class Collegamento {

	/**
	 * Gli attributi da mettere sul tag, pronti per
	 * `get_block_wrapper_attributes()`.
	 *
	 * I valori NON sono codificati per l'HTML: li codifica chi stampa. Vedi
	 * la spiegazione in cima al file.
	 *
	 * @param string $url           L'indirizzo, come l'ha scritto chi compone.
	 * @param bool   $nuova_scheda  Se deve aprirsi in una scheda nuova.
	 * @param bool   $nofollow      Se i motori di ricerca non devono seguirlo.
	 * @return array<string, string> Vuoto se non c'e' nessun indirizzo.
	 */
	public static function attributi( string $url, bool $nuova_scheda = false, bool $nofollow = false ): array {
		$pulito = sanitize_url( trim( $url ) );

		if ( '' === $pulito ) {
			return array();
		}

		$fuori = array( 'href' => $pulito );
		$rel   = array();

		if ( $nuova_scheda ) {
			$fuori['target'] = '_blank';

			/*
			 * Le due parole servono a cose diverse, e vanno tutte e due.
			 *
			 * `noopener`: la pagina che si apre non deve poter toccare
			 * quella di partenza attraverso `window.opener`.
			 * `noreferrer`: non le si dice da dove si arriva.
			 */
			$rel[] = 'noopener';
			$rel[] = 'noreferrer';
		}

		if ( $nofollow ) {
			$rel[] = 'nofollow';
		}

		if ( array() !== $rel ) {
			$fuori['rel'] = implode( ' ', $rel );
		}

		return $fuori;
	}
}
