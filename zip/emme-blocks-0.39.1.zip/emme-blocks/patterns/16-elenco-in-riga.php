<?php
/**
 * Title: Articles one under the other
 * Slug: emme-blocks/elenco-in-riga
 * Categories: quattroemme, posts
 * Keywords: list, loop, news, compact, sidebar, related, articles
 * Description: A compact list: a small picture on the left, the date and the title on the right. For a column beside the text, or for the «other articles» band at the foot of an article.
 * Viewport Width: 800
 *
 * La forma compatta, che serve in due posti precisi:
 *
 * - **in una colonna stretta** accanto al testo, dove una griglia di schede
 *   non ci sta;
 * - **in fondo a un articolo**, come «altri articoli». Per quello c'e'
 *   `escludiCorrente`, acceso: senza, fra gli altri articoli compare quello
 *   che si sta leggendo, e si nota subito.
 *
 * La fotografia e' piccola e quadrata, con una larghezza fissa: in una riga,
 * se la fotografia si allarga a piacere, i titoli non si allineano piu' e
 * l'elenco sembra storto.
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"emmeId":"ri16aa","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|40"}}}} -->
<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Other articles', 'emme-blocks' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:emme/elenco {"quanti":4,"escludiCorrente":true,"emmeId":"ri16cc","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|40"}}}} -->
<!-- wp:emme/container {"tagName":"a","collegaArticolo":true,"emmeId":"ri16dd","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"row"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|30"}},"hover":{"group":true}}} -->
<!-- wp:emme/dato-immagine {"misura":"thumbnail","collegato":false,"emmeId":"ri16ee","emmeStyle":{"size":{"width":{"desktop":"84px"},"aspectRatio":{"desktop":"1"},"objectFit":{"desktop":"cover"}},"border":{"radius":{"desktop":"4px"}},"hover":{"scale":1.06,"trigger":"gruppo","duration":350}}} /-->

<!-- wp:emme/container {"emmeId":"ri16ff","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|10"}},"size":{"width":{"desktop":"100%"}}}} -->
<!-- wp:emme/dato-data {"emmeId":"ri16gg","emmeStyle":{"typography":{"fontSize":{"desktop":"var:preset|font-size|small"},"color":"var:preset|color|contrast-2"}}} /-->

<!-- wp:emme/dato-titolo {"aspetto":"sottosezione","livello":"h3","collegato":false,"emmeId":"ri16hh"} /-->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
<!-- /wp:emme/elenco -->
<!-- /wp:emme/container -->
