<?php
/**
 * Title: A list of events
 * Slug: emme-blocks/elenco-eventi
 * Categories: quattroemme, posts
 * Keywords: events, courses, dates, place, list, loop, cards
 * Description: Events as cards: the kind of course on top, the picture, then the dates, the title and the place. The dates and the place come from custom fields, so each event carries its own.
 * Viewport Width: 1280
 *
 * MISURATO SU UN SITO VERO, il 15/11/2026, sulle schede degli eventi di
 * saracantamessa.it. Cinque pezzi, in quest'ordine:
 *
 *     categoria     «Formazione»                      pillola in cima
 *     fotografia    ritagliata, verticale
 *     le date       «Sabato 19 Settembre - ...»       campo personalizzato
 *     titolo        «Percorso esperenziale...»
 *     il luogo      «Bergamo (BG)»                    campo personalizzato
 *
 * La cosa che non si indovina, e che infatti avevo immaginato diversa: **la
 * data di pubblicazione non si usa**. Al suo posto c'e' un testo scritto a
 * mano con le date del corso, perche' un corso ha piu' date e non una.
 *
 * I DUE NOMI DEI CAMPI - `date_corso` e `luogo` - sono quelli che questo
 * pattern propone, non quelli di nessun sito. Chi lo usa li cambia con i
 * propri dal pannello di ogni campo: il blocco legge per nome, e un nome
 * sbagliato lascia il campo vuoto senza dire niente.
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"wide","emmeId":"ev15aa","emmeStyle":{"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|50"}}}} -->
<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Events and meetings', 'emme-blocks' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:emme/elenco {"quanti":9,"ordine":"recenti","emmeId":"ev15cc","emmeStyle":{"layout":{"display":{"desktop":"grid","mobile":"flex"},"colonne":{"desktop":3},"direction":{"mobile":"column"},"gap":{"desktop":"var:preset|spacing|50","mobile":"var:preset|spacing|40"}}}} -->
<!-- wp:emme/container {"tagName":"a","collegaArticolo":true,"emmeId":"ev15dd","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|20"}},"hover":{"group":true}}} -->
<!-- wp:emme/dato-termini {"quanti":1,"emmeId":"ev15ee","emmeStyle":{"typography":{"fontSize":{"desktop":"var:preset|font-size|small"},"fontWeight":{"desktop":"600"},"textTransform":{"desktop":"uppercase"},"letterSpacing":{"desktop":"0.08em"},"color":"var:preset|color|base"},"background":{"color":"var:preset|color|accent"},"spacing":{"padding":{"desktop":{"top":"0.3em","right":"0.9em","bottom":"0.3em","left":"0.9em"}}},"border":{"radius":{"desktop":"999px"}}}} /-->

<!-- wp:emme/dato-immagine {"collegato":false,"emmeId":"ev15ff","emmeStyle":{"size":{"aspectRatio":{"desktop":"3/4"},"objectFit":{"desktop":"cover"},"width":{"desktop":"100%"}},"border":{"radius":{"desktop":"6px"}},"hover":{"scale":1.05,"trigger":"gruppo","duration":400}}} /-->

<!-- wp:emme/dato-campo {"chiave":"date_corso","emmeId":"ev15gg","emmeStyle":{"typography":{"fontSize":{"desktop":"var:preset|font-size|small"},"fontWeight":{"desktop":"600"},"color":"var:preset|color|accent"}}} /-->

<!-- wp:emme/dato-titolo {"aspetto":"sottosezione","livello":"h3","collegato":false,"emmeId":"ev15hh"} /-->

<!-- wp:emme/dato-campo {"chiave":"luogo","emmeId":"ev15ii","emmeStyle":{"typography":{"fontSize":{"desktop":"var:preset|font-size|small"},"color":"var:preset|color|contrast-2"}}} /-->
<!-- /wp:emme/container -->
<!-- /wp:emme/elenco -->
<!-- /wp:emme/container -->
