<?php
/**
 * Title: A grid of articles
 * Slug: emme-blocks/elenco-schede
 * Categories: quattroemme, posts
 * Keywords: list, loop, news, articles, cards, grid, archive
 * Description: The latest articles of the site, as cards in a grid: picture, category and title. Each card is a link to its own article, and the picture grows a little when the pointer is over the card.
 * Viewport Width: 1280
 *
 * E' il pattern da cui si parte: la forma piu' comune che ci sia.
 *
 * TRE COSE SONO MESSE COSI' APPOSTA, e vale la pena saperlo prima di
 * cambiarle.
 *
 * **La scheda intera e' un collegamento** - `collegaArticolo` sul
 * contenitore - e per questo il titolo ha `collegato: false`. Un
 * collegamento dentro a un collegamento non e' HTML valido e il browser
 * spezza la scheda senza dire niente.
 *
 * **Il contenitore della scheda e' un gruppo al passaggio del mouse**
 * (`hover.group`) e la fotografia reagisce al gruppo (`hover.trigger:
 * gruppo`). Cosi' la fotografia ingrandisce passando il mouse **in un punto
 * qualsiasi** della scheda, non solo sopra di lei. E' come sono fatti i siti
 * curati.
 *
 * **La fotografia ha un rapporto imposto** (`aspectRatio` 4/3 con `cover`).
 * Senza, le schede vengono di altezze diverse e la griglia si sfalsa: e' il
 * difetto che si nota per primo e che non si capisce da dove venga.
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"wide","emmeId":"el14aa","emmeStyle":{"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|50"}}}} -->
<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Latest articles', 'emme-blocks' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:emme/elenco {"quanti":6,"emmeId":"el14cc","emmeStyle":{"layout":{"display":{"desktop":"grid","mobile":"flex"},"colonne":{"desktop":3},"direction":{"mobile":"column"},"gap":{"desktop":"var:preset|spacing|50","mobile":"var:preset|spacing|40"}}}} -->
<!-- wp:emme/container {"tagName":"a","collegaArticolo":true,"emmeId":"el14dd","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|20"}},"hover":{"group":true}}} -->
<!-- wp:emme/dato-immagine {"collegato":false,"emmeId":"el14ee","emmeStyle":{"size":{"aspectRatio":{"desktop":"4/3"},"objectFit":{"desktop":"cover"},"width":{"desktop":"100%"}},"border":{"radius":{"desktop":"6px"}},"hover":{"scale":1.05,"trigger":"gruppo","duration":400}}} /-->

<!-- wp:emme/dato-termini {"quanti":1,"emmeId":"el14ff","emmeStyle":{"typography":{"fontSize":{"desktop":"var:preset|font-size|small"},"textTransform":{"desktop":"uppercase"},"letterSpacing":{"desktop":"0.08em"},"color":"var:preset|color|accent"}}} /-->

<!-- wp:emme/dato-titolo {"aspetto":"sottosezione","livello":"h3","collegato":false,"emmeId":"el14gg"} /-->
<!-- /wp:emme/container -->
<!-- /wp:emme/elenco -->
<!-- /wp:emme/container -->
