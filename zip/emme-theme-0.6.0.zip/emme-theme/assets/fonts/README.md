# I caratteri, ospitati in casa

I file qui dentro sono scaricati una volta e serviti dal sito del cliente. **Nessuna chiamata a Google Fonts**: è una scelta del progetto e vale sia per la velocità sia per la privacy, perché una chiamata a un server esterno a ogni visita trasmette l'indirizzo IP del visitatore.

| File | Carattere | Uso | Licenza |
|---|---|---|---|
| `inter-latin.woff2` | Inter | testo | SIL Open Font License 1.1 |
| `inter-latin-ext.woff2` | Inter | testo, alfabeti estesi | SIL Open Font License 1.1 |
| `source-serif-4-latin.woff2` | Source Serif 4 | titoli | SIL Open Font License 1.1 |
| `source-serif-4-latin-ext.woff2` | Source Serif 4 | titoli, alfabeti estesi | SIL Open Font License 1.1 |
| `dm-serif-text-latin.woff2` | DM Serif Text | titoli, variante Cantamessa | SIL Open Font License 1.1 |
| `dm-serif-text-latin-ext.woff2` | DM Serif Text | titoli, alfabeti estesi | SIL Open Font License 1.1 |

Origine: <https://fonts.google.com/>. Inter e Source Serif 4 scaricati il 04/11/2026; DM Serif Text il 09/11/2026 (disegnato da Colophon Foundry, licenza letta da `google/fonts/ofl/dmseriftext/METADATA.pb`, non a memoria).

**DM Serif Text lo usa solo la variante `cantamessa`**, non il tema di base. Pesa 23,9 kB contro i 119,5 di Source Serif 4, e la ragione e' che non e' un carattere variabile: ha un solo spessore, il 400, che e' l'unico che quel disegno prevede.

La licenza SIL Open Font License 1.1 permette esplicitamente di ospitare i file sul proprio server e di distribuirli dentro un tema, anche a pagamento. Quello che **non** permette è vendere i soli caratteri.

## Perché due file per carattere

Sono **sottoinsiemi**. Il file `latin` contiene le lettere che servono all'italiano, accentate comprese; `latin-ext` aggiunge quelle di altre lingue europee (ungherese, polacco, ceco). Ogni file dichiara in `theme.json` l'intervallo di caratteri che copre, e **il browser scarica solo quello che serve alla pagina**: un sito italiano non scarica mai il secondo file.

## Sono caratteri variabili

Un file solo contiene tutti gli spessori, da leggero a grassetto, invece di un file per spessore. Meno file da scaricare e pesi intermedi disponibili senza costi aggiuntivi.

## Se si cambiano i caratteri

Si sostituiscono i file e si aggiornano le dichiarazioni `fontFace` in `theme.json`. Vanno aggiornati anche gli intervalli `unicodeRange`, che dipendono da come è stato ritagliato il file: copiarli dal foglio di stile fornito da chi distribuisce il carattere, non inventarli.
