<?php
/**
 * Funzioni del tema quattroemme.
 *
 * Qui dentro va solo quello che theme.json non sa fare: agganciare il foglio
 * di stile, registrare le categorie dei pattern e, piu avanti, il controllo
 * degli aggiornamenti.
 *
 * @package EmmeTheme
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Controllo degli aggiornamenti: vedi inc/Updates.php.
require_once get_template_directory() . '/inc/Updates.php';

/**
 * Dice a WordPress dove sono le traduzioni del tema.
 *
 * Un tema pubblicato su wordpress.org non ne avrebbe bisogno: WordPress le
 * scarica da solo. Il nostro no, sta su uno scaffale nostro, quindi le
 * traduzioni viaggiano dentro il pacchetto e la cartella va indicata a mano.
 *
 * COSA TRADUCE, che non e' ovvio: quasi niente di quello che si legge del
 * tema nell'editor sta dentro una chiamata di funzione. Sta dentro
 * `theme.json` e dentro le variazioni di stile - i nomi dei colori, delle
 * spaziature, delle dimensioni del testo, dei caratteri, delle ombre.
 * WordPress li traduce da solo in `WP_Theme_JSON_Resolver::translate()`, con
 * il dominio del tema e un contesto per ogni tipo di campo, ma solo se a quel
 * momento il dominio e' caricato. Da qui la chiamata.
 *
 * Su `after_setup_theme` e non piu' tardi: i dati di theme.json si risolvono
 * dopo, e una traduzione che arriva dopo non serve a niente.
 */
function emme_theme_load_textdomain(): void {
	load_theme_textdomain( 'emme-theme', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'emme_theme_load_textdomain' );

/**
 * Versione del tema, letta dall'intestazione di style.css.
 *
 * Serve per marcare i file CSS e JS: quando la versione cambia, i browser
 * dei visitatori ricaricano i file invece di usare quelli vecchi in cache.
 */
function emme_theme_version(): string {
	static $version = null;

	if ( null === $version ) {
		$version = (string) wp_get_theme()->get( 'Version' );
	}

	return $version;
}

/**
 * Aggancia style.css alle pagine del sito.
 *
 * Nei temi a blocchi WordPress non lo fa da solo: va dichiarato qui.
 */
function emme_theme_enqueue_styles(): void {
	wp_enqueue_style(
		'emme-theme',
		get_stylesheet_uri(),
		array(),
		emme_theme_version()
	);
}
add_action( 'wp_enqueue_scripts', 'emme_theme_enqueue_styles' );

/*
 * I pattern NON stanno nel tema: stanno nel plugin, insieme ai blocchi di cui
 * sono fatti. Metterli qui farebbe dipendere il tema dal plugin, al contrario
 * di quello che il progetto dichiara — e' il plugin che pretende il tema, non
 * viceversa. Vedi inc/Patterns.php dentro emme-blocks.
 */

/**
 * Toglie dalle pagine lo script delle emoji di WordPress.
 *
 * Sono 22,2 kB su ogni pagina - misurati sulla vetrina il 09/11/2026, dove
 * erano la terza cosa piu' pesante dopo i due caratteri - e servono a
 * convertire le emoji in immagini per i browser che non le disegnano da soli.
 * Quei browser oggi non esistono piu': Windows, macOS, Android e iOS le
 * disegnano tutti.
 *
 * Si tolgono in cinque punti perche' WordPress le aggancia in cinque posti
 * diversi: il sito, l'amministrazione, i feed, le email e l'editor TinyMCE.
 * Toglierne solo uno lascia lo script attaccato altrove.
 *
 * Le emoji continuano a funzionare: vengono scritte come caratteri veri nel
 * testo, e il sistema operativo le disegna. Quello che sparisce e' solo la
 * conversione in immagini.
 */
function emme_theme_niente_emoji(): void {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );

	// E il plugin di TinyMCE, che altrimenti torna dentro dall'editor classico.
	add_filter(
		'tiny_mce_plugins',
		static function ( $plugins ) {
			return is_array( $plugins ) ? array_diff( $plugins, array( 'wpemoji' ) ) : array();
		}
	);
}
add_action( 'init', 'emme_theme_niente_emoji' );
