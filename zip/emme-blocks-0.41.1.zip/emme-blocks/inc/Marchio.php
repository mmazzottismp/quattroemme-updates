<?php
/**
 * Il marchio quattroemme, dove serve dentro a WordPress.
 *
 * UN MARCHIO SOLO, TRE FORME, e non per vezzo: ogni posto ha una misura e
 * delle regole sue.
 *
 * - nel **menu della bacheca** l'icona e' alta 20 px e WordPress la colora
 *   da se' - grigia da ferma, bianca sulla pagina aperta. Li' va una sagoma
 *   a una tinta sola: il rendering a colori, a quella misura, diventa una
 *   macchia. Misurato il 20/11/2026 sul primo 4M, e di nuovo il 21 su
 *   questo;
 * - in **Bacheca → Aggiornamenti** e nella scheda del plugin l'icona e'
 *   grande 128 o 256 px e sta dentro a un `<img>`: li' va il marchio vero, a
 *   colori, e puo' anche muoversi;
 * - l'**SVG animato** sta sul server degli aggiornamenti, non nel plugin:
 *   e' WordPress a scaricarlo da li', insieme alla notizia che c'e' una
 *   versione nuova.
 *
 * I file stanno in `assets/marchio/` e li produce `marchio/prepara-marchio.py`
 * dal rendering originale.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Da dove si prende il marchio, e in che forma.
 */
final class Marchio {

	/**
	 * La cartella dei file, dentro al plugin.
	 */
	private const CARTELLA = 'assets/marchio/';

	/**
	 * L'icona per il menu della bacheca, pronta da passare a `add_menu_page()`.
	 *
	 * WordPress vuole un `data:` con dentro l'SVG: cosi' non fa una
	 * richiesta in piu' per venti pixel, e puo' colorarlo con il CSS della
	 * bacheca. Il file e' letto da disco e non scritto qui dentro, se no
	 * sarebbero due marchi da tenere allineati.
	 *
	 * @return string L'icona, oppure un dashicon di ripiego se il file manca.
	 */
	public static function per_il_menu(): string {
		$file = EMME_BLOCKS_PATH . self::CARTELLA . '4m-piatto.svg';

		if ( ! is_readable( $file ) ) {
			return 'dashicons-screenoptions';
		}

		$svg = (string) file_get_contents( $file );

		/*
		 * `currentColor` nel file diventa un colore vero qui: dentro a un
		 * `data:` non c'e' nessun elemento che lo erediti, e il marchio
		 * uscirebbe nero. Si usa il grigio delle icone del menu, e WordPress
		 * ci mette sopra il suo filtro quando la voce e' attiva.
		 */
		$svg = str_replace( 'currentColor', '#a7aaad', $svg );

		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	/**
	 * Le icone del plugin per WordPress, nel formato che si aspetta.
	 *
	 * Vanno nella risposta dell'aggiornamento e nella scheda «Visualizza
	 * dettagli». Le chiavi sono quelle che WordPress legge: `svg` prima di
	 * tutte, poi `2x` e `1x`.
	 *
	 * @param string $base Indirizzo del server degli aggiornamenti, con la barra finale.
	 * @return array<string, string> Le icone.
	 */
	public static function icone( string $base ): array {
		return array(
			'svg'     => $base . 'icone/emme-blocks.svg',
			'2x'      => $base . 'icone/emme-blocks-256.png',
			'1x'      => $base . 'icone/emme-blocks-128.png',
			'default' => $base . 'icone/emme-blocks-128.png',
		);
	}
}
