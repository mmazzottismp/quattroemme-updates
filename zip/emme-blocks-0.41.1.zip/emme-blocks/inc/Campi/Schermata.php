<?php
/**
 * La pagina dove si decide quali campi personalizzati esistono.
 *
 * Sta in «quattroemme > Campi», nel menu di sinistra della bacheca.
 *
 * PERCHE' NON C'E' UNA RIGA DI JAVASCRIPT.
 *
 * Una schermata che aggiunge righe cliccando «+» e' piu' comoda da usare e
 * molto meno comoda da fidarsi: va compilata, va tradotta a parte, e il
 * giorno che si rompe lascia chi guarda davanti a un modulo che non
 * risponde. Qui c'e' un modulo normale, di quelli che il browser sa gia'
 * mandare.
 *
 * Anche la conferma prima di togliere un campo e' senza JavaScript: non e'
 * la finestrella del browser, e' un secondo giro di pagina. Costa un clic in
 * piu' e in cambio si puo' leggere con calma cosa succede, invece di dover
 * decidere dentro a un riquadro che copre tutto.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Campi;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Il menu e la pagina dei campi personalizzati.
 */
final class Schermata {

	/**
	 * La chiave della pagina nell'indirizzo della bacheca.
	 */
	public const PAGINA = 'emme-campi';

	/**
	 * Il permesso che serve per aprirla.
	 *
	 * Definire un campo cambia quello che tutti gli altri vedranno nella
	 * schermata di scrittura: e' un'impostazione del sito, non del contenuto.
	 */
	public const PERMESSO = 'manage_options';

	/**
	 * Quante righe vuote offrire per aggiungerne di nuovi.
	 *
	 * UNA, e la decisione e' di Manuel (18/11/2026): «se ne aggiunge una alla
	 * volta, altrimenti dopo il salva vedere sempre tutto il mappazzone di
	 * righe vuote da' fastidio». Aveva ragione - la tabella dopo il
	 * salvataggio deve mostrare quello che c'e', non lo spazio per quello che
	 * non c'e' ancora.
	 */
	public const RIGHE_VUOTE = 1;

	/**
	 * Aggancia il menu.
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ) );
	}

	/**
	 * Aggiunge «quattroemme» al menu, con dentro «Campi».
	 */
	public static function menu(): void {
		add_menu_page(
			__( 'quattroemme', 'emme-blocks' ),
			__( 'quattroemme', 'emme-blocks' ),
			self::PERMESSO,
			self::PAGINA,
			array( self::class, 'disegna' ),
			\Emme\Marchio::per_il_menu(),
			58
		);

		/*
		 * WordPress crea da solo una prima voce chiamata come il menu.
		 * Ridichiararla con lo stesso slug la rinomina: senza, nel menu si
		 * legge «quattroemme > quattroemme».
		 */
		add_submenu_page(
			self::PAGINA,
			__( 'Custom fields', 'emme-blocks' ),
			__( 'Custom fields', 'emme-blocks' ),
			self::PERMESSO,
			self::PAGINA,
			array( self::class, 'disegna' )
		);
	}

	/**
	 * Disegna la pagina, e salva se e' arrivato un invio.
	 */
	public static function disegna(): void {
		if ( ! current_user_can( self::PERMESSO ) ) {
			wp_die( esc_html__( 'You are not allowed to manage custom fields.', 'emme-blocks' ) );
		}

		$esito = self::gestisci_invio();
		$campi = Definizioni::tutte();

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'Custom fields', 'emme-blocks' ) . '</h1>';

		echo '<p>' . esc_html__(
			'A custom field turns something written inside the text into a value of its own: the dates of a course, a place, a price. Once it is a value, the quattroemme "Field" block can draw it, and every article shows its own.',
			'emme-blocks'
		) . '</p>';

		if ( '' !== $esito['messaggio'] ) {
			$classe = $esito['scartate'] ? 'notice-warning' : 'notice-success';

			echo '<div class="notice ' . esc_attr( $classe ) . ' is-dismissible"><p>'
				. esc_html( $esito['messaggio'] ) . '</p></div>';
		}

		if ( '' !== $esito['da_togliere'] ) {
			self::conferma_togli( $esito['da_togliere'], $campi );
		}

		echo '<form method="post">';
		wp_nonce_field( 'emme_campi_salva' );

		echo '<table class="widefat striped" style="margin-top:1em">';
		self::intestazione();
		echo '<tbody>';

		$riga = 0;

		foreach ( $campi as $campo ) {
			self::riga( $riga, $campo );
			++$riga;
		}

		for ( $vuota = 0; $vuota < self::RIGHE_VUOTE; $vuota++ ) {
			self::riga( $riga, null );
			++$riga;
		}

		echo '</tbody></table>';

		submit_button( __( 'Save fields', 'emme-blocks' ) );

		echo '</form>';
		echo '</div>';
	}

	/**
	 * Il riquadro che chiede conferma prima di togliere un campo.
	 *
	 * DICE COSA SUCCEDE AI DATI GIA' SCRITTI, che e' la domanda che si fa
	 * chiunque stia per cliccare: togliere la definizione **non cancella
	 * niente** dagli articoli. I valori restano dove sono, semplicemente non
	 * c'e' piu' la casella per leggerli e cambiarli. Rimettendo il campo con
	 * lo stesso nome si ritrovano tutti.
	 *
	 * @param string                           $chiave Il campo da togliere.
	 * @param array<int, array<string, mixed>> $campi  I campi definiti.
	 */
	private static function conferma_togli( string $chiave, array $campi ): void {
		$nome = $chiave;

		foreach ( $campi as $campo ) {
			if ( $campo['chiave'] === $chiave ) {
				$nome = (string) $campo['nome'];
				break;
			}
		}

		echo '<div class="notice notice-warning"><p><strong>'
			. esc_html(
				sprintf(
					/* translators: %s: the label of the field. */
					__( 'Remove the field %s?', 'emme-blocks' ),
					$nome
				)
			)
			. '</strong></p><p>'
			. esc_html__(
				'It disappears from the writing screen. What is already written in the articles stays where it is: nothing is deleted, and putting the field back with the same name brings it all back.',
				'emme-blocks'
			)
			. '</p><p>';

		echo '<form method="post" style="display:inline">';
		wp_nonce_field( 'emme_campi_salva' );
		echo '<input type="hidden" name="togli" value="' . esc_attr( $chiave ) . '">';
		echo '<input type="hidden" name="conferma" value="1">';
		echo '<button type="submit" class="button button-primary">'
			. esc_html__( 'Yes, remove it', 'emme-blocks' ) . '</button>';
		echo '</form> ';

		echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGINA ) ) . '">'
			. esc_html__( 'Leave it there', 'emme-blocks' ) . '</a>';

		echo '</p></div>';
	}

	/**
	 * L'intestazione della tabella.
	 */
	private static function intestazione(): void {
		$colonne = array(
			__( 'Name in WordPress', 'emme-blocks' ),
			__( 'Label', 'emme-blocks' ),
			__( 'Type', 'emme-blocks' ),
			__( 'Where it appears', 'emme-blocks' ),
			__( 'Help text', 'emme-blocks' ),
			__( 'Choices, one per line', 'emme-blocks' ),
			__( 'Remove', 'emme-blocks' ),
		);

		echo '<thead><tr>';

		foreach ( $colonne as $colonna ) {
			echo '<th scope="col">' . esc_html( $colonna ) . '</th>';
		}

		echo '</tr></thead>';
	}

	/**
	 * Una riga della tabella.
	 *
	 * @param int                       $indice Il numero della riga nel modulo.
	 * @param array<string, mixed>|null $campo  Il campo, o null per una riga vuota.
	 */
	private static function riga( int $indice, ?array $campo ): void {
		$base = 'campi[' . $indice . ']';

		echo '<tr>';

		echo '<td><input type="text" name="' . esc_attr( $base . '[chiave]' ) . '"'
			. ' value="' . esc_attr( (string) ( $campo['chiave'] ?? '' ) ) . '"'
			. ' maxlength="' . esc_attr( (string) Definizioni::MASSIMO_CHIAVE ) . '"'
			. ' pattern="[a-z][a-z0-9_]*"'
			. ' placeholder="date_corso" class="regular-text"></td>';

		echo '<td><input type="text" name="' . esc_attr( $base . '[nome]' ) . '"'
			. ' value="' . esc_attr( (string) ( $campo['nome'] ?? '' ) ) . '"'
			. ' placeholder="' . esc_attr__( 'Course dates', 'emme-blocks' ) . '" class="regular-text"></td>';

		echo '<td><select name="' . esc_attr( $base . '[tipo]' ) . '">';

		foreach ( self::nomi_dei_tipi() as $chiave => $nome ) {
			echo '<option value="' . esc_attr( $chiave ) . '"'
				. selected( $chiave, (string) ( $campo['tipo'] ?? 'testo' ), false ) . '>'
				. esc_html( $nome ) . '</option>';
		}

		echo '</select></td>';

		echo '<td>';

		$scelti = (array) ( $campo['tipiPost'] ?? array( 'post' ) );

		foreach ( self::tipi_post_disponibili() as $tipo => $etichetta ) {
			echo '<label style="display:block;white-space:nowrap"><input type="checkbox"'
				. ' name="' . esc_attr( $base . '[tipiPost][]' ) . '"'
				. ' value="' . esc_attr( $tipo ) . '"'
				. checked( in_array( $tipo, $scelti, true ), true, false ) . '> '
				. esc_html( $etichetta ) . '</label>';
		}

		echo '</td>';

		echo '<td><input type="text" name="' . esc_attr( $base . '[aiuto]' ) . '"'
			. ' value="' . esc_attr( (string) ( $campo['aiuto'] ?? '' ) ) . '" class="regular-text"></td>';

		echo '<td><textarea name="' . esc_attr( $base . '[opzioni]' ) . '" rows="3" cols="18">'
			. esc_textarea( implode( "\n", (array) ( $campo['opzioni'] ?? array() ) ) )
			. '</textarea></td>';

		echo '<td>';

		/*
		 * UN PULSANTE, NON UNA CASELLA, su richiesta di Manuel (18/11/2026).
		 *
		 * E' lo stesso pulsante che WordPress usa per togliere le cose nelle
		 * sue schermate - `button-link-delete` - e fa un secondo giro di
		 * pagina a chiedere conferma. Con la casella bisognava spuntare e poi
		 * ricordarsi di salvare, e una spunta messa per sbaglio spariva nel
		 * salvataggio insieme a tutto il resto.
		 */
		if ( null !== $campo ) {
			echo '<button type="submit" class="button-link button-link-delete"'
				. ' name="togli" value="' . esc_attr( (string) $campo['chiave'] ) . '">'
				. esc_html__( 'Remove', 'emme-blocks' ) . '</button>';
		}

		echo '</td>';

		echo '</tr>';
	}

	/**
	 * I nomi dei tipi di campo, tradotti.
	 *
	 * Le chiavi sono quelle di `Definizioni::TIPI`, e una prova controlla che
	 * i due elenchi combacino: un tipo aggiunto li' e dimenticato qui sarebbe
	 * un tipo che nessuno puo' scegliere.
	 *
	 * @return array<string, string>
	 */
	public static function nomi_dei_tipi(): array {
		return array(
			'testo'      => __( 'Short text', 'emme-blocks' ),
			'testolungo' => __( 'Long text', 'emme-blocks' ),
			'numero'     => __( 'Number', 'emme-blocks' ),
			'data'       => __( 'Date', 'emme-blocks' ),
			'url'        => __( 'Web address', 'emme-blocks' ),
			'scelta'     => __( 'Choice from a list', 'emme-blocks' ),
			'sino'       => __( 'Yes or no', 'emme-blocks' ),
		);
	}

	/**
	 * I tipi di contenuto su cui ha senso mettere un campo.
	 *
	 * SI CHIEDE `show_in_rest`, E NON E' UN DETTAGLIO.
	 *
	 * Il nostro pannello vive nell'editor a blocchi, e l'editor a blocchi si
	 * apre solo per i tipi di contenuto esposti alle API REST: senza quelle
	 * non ha da dove leggere e dove scrivere. Offrire un tipo che non le ha
	 * vorrebbe dire offrire una casella che non comparira' mai.
	 *
	 * E' successo subito, al primo collaudo (18/11/2026): nell'elenco c'era
	 * «Messaggio», cioe' i messaggi del nostro modulo di contatto. Quelli
	 * non si scrivono a mano - li scrive chi compila il modulo - e sono
	 * registrati apposta con `show_in_rest` falso. Manuel ha chiesto cosa
	 * fossero, ed era la domanda giusta.
	 *
	 * I tipi di servizio di WordPress - allegati, blocchi sincronizzati,
	 * modelli, parti di modello, menu - le API REST ce l'hanno, quindi vanno
	 * esclusi per nome: non sono contenuti che qualcuno scrive, e un campo
	 * personalizzato li' dentro non vuol dire niente.
	 *
	 * @return array<string, string>
	 */
	private static function tipi_post_disponibili(): array {
		$di_servizio = array( 'attachment', 'wp_block', 'wp_template', 'wp_template_part', 'wp_navigation', 'wp_font_family', 'wp_font_face' );

		$fuori = array();

		foreach ( get_post_types( array( 'show_ui' => true ), 'objects' ) as $tipo ) {
			if ( in_array( $tipo->name, $di_servizio, true ) ) {
				continue;
			}

			if ( empty( $tipo->show_in_rest ) ) {
				continue;
			}

			$fuori[ $tipo->name ] = $tipo->labels->singular_name ?? $tipo->name;
		}

		return $fuori;
	}

	/**
	 * Legge l'invio, salva, e dice cosa mostrare.
	 *
	 * @return array{messaggio: string, scartate: bool, da_togliere: string}
	 */
	private static function gestisci_invio(): array {
		$niente = array(
			'messaggio'   => '',
			'scartate'    => false,
			'da_togliere' => '',
		);

		$arrivate = isset( $_POST['campi'] );
		$togliere = isset( $_POST['togli'] );

		if ( ! $arrivate && ! $togliere ) {
			return $niente;
		}

		check_admin_referer( 'emme_campi_salva' );

		$togli = '';

		if ( $togliere ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- pulisci_chiave() e' la sanificazione.
			$togli = Definizioni::pulisci_chiave( (string) wp_unslash( $_POST['togli'] ) );
		}

		/*
		 * LA CONFERMA ARRIVA DA SOLA, senza la tabella: e' un modulo suo, con
		 * dentro solo il nome del campo. Qui si toglie e si esce.
		 */
		if ( '' !== $togli && ! empty( $_POST['conferma'] ) ) {
			return self::togli_davvero( $togli );
		}

		$esito = $arrivate ? self::salva_le_righe() : $niente;

		/*
		 * Il pulsante «Togli» manda anche tutto il resto della tabella: si
		 * salva prima, cosi' quello che era stato scritto nelle altre righe
		 * non va perso mentre si pensa alla conferma.
		 */
		$esito['da_togliere'] = $togli;

		return $esito;
	}

	/**
	 * Toglie un campo e dice com'e' andata.
	 *
	 * @param string $chiave Il campo da togliere.
	 * @return array{messaggio: string, scartate: bool, da_togliere: string}
	 */
	private static function togli_davvero( string $chiave ): array {
		$restano = array();
		$nome    = $chiave;

		foreach ( Definizioni::tutte() as $campo ) {
			if ( $campo['chiave'] === $chiave ) {
				$nome = (string) $campo['nome'];
				continue;
			}

			$restano[] = $campo;
		}

		Definizioni::salva( $restano );

		return array(
			'messaggio'   => sprintf(
				/* translators: %s: the label of the field that was removed. */
				__( 'Field removed: %s. What was already written in the articles is still there.', 'emme-blocks' ),
				$nome
			),
			'scartate'    => false,
			'da_togliere' => '',
		);
	}

	/**
	 * Salva le righe della tabella.
	 *
	 * @return array{messaggio: string, scartate: bool, da_togliere: string}
	 */
	private static function salva_le_righe(): array {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- ogni valore passa da Definizioni::valida().
		$grezze = wp_unslash( $_POST['campi'] );

		if ( ! is_array( $grezze ) ) {
			return array(
				'messaggio'   => '',
				'scartate'    => false,
				'da_togliere' => '',
			);
		}

		$tenute  = array();
		$scritte = 0;

		foreach ( $grezze as $grezza ) {
			if ( ! is_array( $grezza ) ) {
				continue;
			}

			$tenute[] = $grezza;

			/*
			 * LE RIGHE CHE QUALCUNO HA PROVATO A SCRIVERE.
			 *
			 * La riga vuota in fondo arriva sempre, e non e' un tentativo:
			 * non si conta. Una riga con dentro qualcosa si conta, e se poi
			 * non esce dall'altra parte vuol dire che e' stata scartata.
			 */
			if ( '' !== trim( (string) ( $grezza['chiave'] ?? '' ) )
				|| '' !== trim( (string) ( $grezza['nome'] ?? '' ) ) ) {
				++$scritte;
			}
		}

		$dopo = count( Definizioni::salva( $tenute ) );

		/*
		 * SI DICE QUANTE NE SONO STATE SCARTATE, non «salvato».
		 *
		 * Una riga scritta male - un nome con uno spazio, un campo a scelta
		 * senza scelte - viene buttata, e senza questo numero sparirebbe in
		 * silenzio: chi guarda penserebbe di averla salvata.
		 *
		 * SI CONTANO LE RIGHE SCRITTE, NON I CAMPI DI PRIMA. Il primo giro
		 * confrontava il numero prima e dopo, e cosi' una riga buttata
		 * mentre gli altri campi restavano uguali non cambiava niente: il
		 * conto tornava, e l'avviso non usciva proprio nel caso in cui
		 * serviva.
		 */
		$scartate = $scritte - $dopo;

		if ( $scartate < 1 ) {
			return array(
				'messaggio'   => sprintf(
					/* translators: %d: how many fields are defined. */
					__( 'Saved. Fields defined: %d.', 'emme-blocks' ),
					$dopo
				),
				'scartate'    => false,
				'da_togliere' => '',
			);
		}

		return array(
			'messaggio'   => sprintf(
				/* translators: 1: how many rows were discarded, 2: how many fields are defined now. */
				__( 'Rows discarded because we cannot use them as written: %1$d. Fields defined: %2$d. A name must be lowercase letters, digits and underscores, must start with a letter, and a choice field needs at least one choice.', 'emme-blocks' ),
				$scartate,
				$dopo
			),
			'scartate'    => true,
			'da_togliere' => '',
		);
	}
}
