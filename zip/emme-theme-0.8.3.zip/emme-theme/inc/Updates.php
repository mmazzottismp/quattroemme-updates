<?php
/**
 * Controllo degli aggiornamenti del tema.
 *
 * Il tema non sta su wordpress.org, quindi WordPress non sa a chi chiedere se
 * esiste una versione nuova. Glielo diciamo noi: l'intestazione "Update URI"
 * in style.css indica il nostro scaffale, e WordPress a quel punto chiama il
 * filtro update_themes_<nome del server>. Qui rispondiamo leggendo un file di
 * testo pubblicato su GitHub Pages.
 *
 * Il confronto fra le versioni lo fa WordPress da solo: noi diciamo solo qual
 * e' l'ultima versione disponibile e dove scaricarla.
 *
 * @package EmmeTheme
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Indirizzo dello scaffale degli aggiornamenti e nome del server che lo ospita.
 *
 * Il nome del server deve corrispondere a quello dell'indirizzo, perche' da
 * quello WordPress costruisce il nome del filtro.
 */
const EMME_THEME_UPDATE_BASE = 'https://mmazzottismp.github.io/quattroemme-updates/';
const EMME_THEME_UPDATE_HOST = 'mmazzottismp.github.io';

/**
 * Il file che dice qual e' l'ultima versione. Uno solo.
 *
 * C'erano due canali, `stabile` e `pilota`, con una riga da scrivere in
 * `wp-config.php` per scegliere. Tolti il 19/11/2026: in due mesi ogni
 * versione e' finita su tutti e due lo stesso giorno, compresa una rotta,
 * quindi il pilota non ha mai protetto nessuno e costava solo una cosa da
 * capire.
 *
 * Lo scaffale continua a pubblicare anche ai vecchi indirizzi, perche' e'
 * il codice GIA' installato a decidere dove guardare: un sito fermo a una
 * versione vecchia cerca ancora `.../stabile/emme-theme.json`, e senza
 * quel file non vedrebbe mai piu' un aggiornamento.
 */
const EMME_THEME_UPDATE_FILE = 'emme-theme.json';

/**
 * Il nome con cui la risposta si ricorda fino alla prossima volta.
 */
const EMME_THEME_UPDATE_MEMORIA = 'emme_theme_update';

/**
 * Dice se WordPress sta facendo un controllo CHIESTO, non uno di routine.
 *
 * Il pulsante «Controlla di nuovo» di Bacheca > Aggiornamenti ricarica la
 * pagina con `force-check=1` (lo fa `wp-admin/update-core.php`). Senza
 * guardarlo, chi preme il pulsante si riprende il manifesto vecchio dalla
 * nostra memoria temporanea e non succede niente: e' esattamente quello che
 * e' capitato il 19/11/2026 con il tema 0.8.1 gia' sullo scaffale.
 *
 * Si guarda solo la PRESENZA del parametro, non il suo valore, e non si
 * decide niente di delicato: al massimo si fa una richiesta in piu'.
 *
 * @return bool Vero se il controllo e' stato chiesto a mano.
 */
function emme_theme_controllo_forzato(): bool {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Solo la presenza del parametro, nessuna decisione.
	return ! empty( $_GET['force-check'] );
}

/**
 * Legge il file di testo del canale, con memoria temporanea di un'ora.
 *
 * La memoria temporanea evita di interrogare GitHub a ogni caricamento della
 * bacheca. NON deve durare piu' della strozzatura di WordPress stesso - che
 * su Aspetto > Temi e' di un'ora - se no e' sempre la nostra a decidere, e
 * chi aspetta l'aggiornamento non lo vede arrivare. Se il server non risponde, ricordiamo anche l'insuccesso per un'ora:
 * cosi' un sito con problemi di rete non rallenta la bacheca a ogni visita.
 *
 * @param bool $force Salta la memoria temporanea e chiede davvero.
 * @return array<string, mixed>|null I dati, oppure null se non disponibili.
 */
function emme_theme_update_manifest( bool $force = false ): ?array {
	$transient_key = EMME_THEME_UPDATE_MEMORIA;

	if ( ! $force ) {
		$cached = get_site_transient( $transient_key );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		if ( 'non-disponibile' === $cached ) {
			return null;
		}
	}

	$response = wp_remote_get(
		EMME_THEME_UPDATE_BASE . EMME_THEME_UPDATE_FILE,
		array(
			'timeout' => 10,
			'headers' => array( 'Accept' => 'application/json' ),
		)
	);

	$body = ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) )
		? null
		: json_decode( wp_remote_retrieve_body( $response ), true );

	if ( ! is_array( $body ) || empty( $body['version'] ) ) {
		set_site_transient( $transient_key, 'non-disponibile', HOUR_IN_SECONDS );

		return null;
	}

	set_site_transient( $transient_key, $body, HOUR_IN_SECONDS );

	return $body;
}

/**
 * Dice se un indirizzo sta davvero sotto il nostro scaffale.
 *
 * Si pretende https: su http qualcuno sulla stessa rete potrebbe sostituire
 * il pacchetto durante il viaggio.
 *
 * @param string $url Indirizzo da controllare.
 * @return bool Vero se possiamo fidarci.
 */
function emme_theme_indirizzo_nostro( string $url ): bool {
	$pulito = esc_url_raw( trim( $url ) );

	if ( '' === $pulito || 0 !== strpos( $pulito, 'https://' ) ) {
		return false;
	}

	return 0 === strpos( $pulito, EMME_THEME_UPDATE_BASE );
}

/**
 * Risponde a WordPress quando chiede se c'e' una versione nuova del tema.
 *
 * @param array<string, mixed>|false $update     Risposta di chi ci ha preceduto.
 * @param array<string, mixed>       $theme_data Intestazioni del tema.
 * @param string                     $stylesheet Nome della cartella del tema.
 * @return array<string, mixed>|false
 */
function emme_theme_update_response( $update, array $theme_data, string $stylesheet ) {
	// Se qualcun altro ha gia' risposto, o se il tema non e' il nostro, non tocchiamo niente.
	if ( false !== $update || get_template() !== $stylesheet ) {
		return $update;
	}

	$manifest = emme_theme_update_manifest( emme_theme_controllo_forzato() );

	if ( null === $manifest || empty( $manifest['package'] ) ) {
		return $update;
	}

	// L'indirizzo del pacchetto arriva dal file del canale, cioe' da fuori.
	// Deve stare sotto il nostro indirizzo: se un giorno finisse li' dentro un
	// file sbagliato, quel file potrebbe mandare TUTTI i siti dei clienti a
	// scaricare un pacchetto di qualcun altro, che viene installato ed
	// eseguito. Con questo controllo servirebbero due errori invece di uno.
	if ( ! emme_theme_indirizzo_nostro( (string) $manifest['package'] ) ) {
		return $update;
	}

	return array(
		'theme'        => $stylesheet,
		'version'      => (string) $manifest['version'],
		'url'          => (string) ( $manifest['url'] ?? '' ),
		'package'      => (string) $manifest['package'],
		'tested'       => (string) ( $manifest['tested'] ?? '' ),
		'requires_php' => (string) ( $manifest['requires_php'] ?? '' ),
	);
}
add_filter( 'update_themes_' . EMME_THEME_UPDATE_HOST, 'emme_theme_update_response', 10, 3 );

/**
 * Dimentica la memoria temporanea dopo un aggiornamento andato a buon fine.
 *
 * Senza questo, per un'ora WordPress continuerebbe a credere che esista una
 * versione piu' nuova di quella appena installata.
 */
function emme_theme_update_clear_cache(): void {
	delete_site_transient( EMME_THEME_UPDATE_MEMORIA );

	// I nomi di quando c'erano due canali: un sito aggiornato da una versione
	// vecchia puo' averli ancora in giro.
	delete_site_transient( 'emme_theme_update_stabile' );
	delete_site_transient( 'emme_theme_update_pilota' );
}
add_action( 'upgrader_process_complete', 'emme_theme_update_clear_cache' );
