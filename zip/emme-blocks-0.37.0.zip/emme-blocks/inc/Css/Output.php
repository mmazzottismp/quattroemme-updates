<?php
/**
 * Innesto del generatore CSS dentro WordPress.
 *
 * Il Builder e' volutamente cieco a WordPress: tutto quello che riguarda
 * filtri, azioni e stampa in pagina sta qui.
 *
 * Perche' funziona: in un tema a blocchi il contenuto della pagina viene
 * costruito PRIMA di wp_head, quindi quando wp_head arriva tutti i blocchi
 * hanno gia' dichiarato le loro regole. E' la stessa ragione per cui il core
 * di WordPress aggancia a wp_head le sue regole di blocco nei temi a blocchi,
 * e a wp_footer in quelli vecchio stile (visto in wp_enqueue_block_support_styles).
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Css;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Collega il generatore ai meccanismi di WordPress.
 */
final class Output {

	/**
	 * Vero se almeno un blocco della pagina ha un'animazione.
	 */
	private static bool $animazioni = false;

	/**
	 * Vero se almeno un'immagine della pagina si puo' ingrandire.
	 */
	private static bool $lightbox = false;

	/**
	 * Vero se almeno un contenitore della pagina ha lo sfondo animato.
	 */
	private static bool $sfondo = false;

	/**
	 * Vero se nella pagina c'e' almeno una scheda a due facce.
	 */
	private static bool $schede = false;

	/**
	 * Vero se nella pagina c'e' almeno un carosello.
	 */
	private static bool $caroselli = false;
	
	/**
	 * Se in pagina c'e' almeno una barra ancorata allo scorrimento.
	 *
	 * @var bool
	 */
	private static bool $ancoraggi = false;

	/**
	 * Vero se in pagina c'e' almeno un modulo che aspetta un consenso.
	 *
	 * @var bool
	 */
	private static bool $moduli = false;

	/**
	 * Un contatore dichiara di esserci.
	 *
	 * @var bool
	 */
	private static bool $contatori = false;

	/**
	 * Un mazzo di carte dichiara di esserci.
	 *
	 * @var bool
	 */
	private static bool $mazzi = false;

	/**
	 * Regole CSS calcolate durante la resa, che il generatore non sa scrivere.
	 *
	 * Il generatore parte da `emmeStyle`, cioe' da quello che qualcuno ha
	 * impostato. Il mazzo di carte ha un bisogno diverso: le posizioni delle
	 * sue carte si **calcolano** mentre la pagina si scrive, e non possono
	 * finire nell'attributo `style` della singola carta perche' in WordPress
	 * un blocco figlio non sa di essere il terzo fra i fratelli. Lo sa il
	 * gruppo, e lo dice con `:nth-child()`: che e' una regola, non un valore.
	 *
	 * Finiscono nello stesso foglio di stile in testa alla pagina, dopo le
	 * regole dei blocchi.
	 *
	 * @var array<int, string>
	 */
	private static array $regole = array();

	/**
	 * Aggancia tutto. Si chiama al caricamento del plugin.
	 */
	public static function init(): void {
		// init, non prima: a quel punto il tema e' caricato e si puo' sapere di che tipo e'.
		add_action( 'init', array( self::class, 'boot' ), 5 );
	}

	/**
	 * Un blocco dichiara di essere animato.
	 *
	 * Lo chiama render.php. Due effetti: il foglio di stile ricevera' anche le
	 * regole delle animazioni, e viene caricato lo script che se ne accorge.
	 * Se nella pagina non c'e' nessun blocco animato, non si carica niente.
	 */
	public static function use_animations(): void {
		if ( self::$animazioni ) {
			return;
		}

		self::$animazioni = true;

		// Lo script va in fondo alla pagina: li' arriva sempre in tempo, anche
		// nei temi vecchio stile dove il contenuto si costruisce dopo wp_head.
		wp_enqueue_script(
			'emme-animazioni',
			EMME_BLOCKS_URL . 'shared/animazioni.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Un modulo dichiara che il suo pulsante aspetta le spunte obbligatorie.
	 *
	 * Lo script si limita a spegnere l'aspetto del pulsante: a dire cosa
	 * manca ci pensa il browser, perche' la casella e' `required`. Vedi
	 * shared/modulo.js, che spiega anche perche' non si usa `disabled`.
	 */
	public static function use_moduli(): void {
		if ( self::$moduli ) {
			return;
		}

		self::$moduli = true;

		wp_enqueue_script(
			'emme-modulo',
			EMME_BLOCKS_URL . 'shared/modulo.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Un blocco dichiara di avere un'immagine ingrandibile.
	 *
	 * Stessa logica delle animazioni: se nella pagina non c'e' niente da
	 * ingrandire, non si carica niente. Il foglio finisce dentro lo stesso
	 * tag <style> delle regole dei blocchi, lo script in fondo alla pagina.
	 */
	public static function use_lightbox(): void {
		if ( self::$lightbox ) {
			return;
		}

		self::$lightbox = true;

		wp_enqueue_script(
			'emme-lightbox',
			EMME_BLOCKS_URL . 'shared/lightbox.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Un contenitore dichiara di avere lo sfondo animato.
	 *
	 * Stessa logica delle animazioni e della lightbox: in una pagina senza
	 * sfondi animati non si carica niente. Lo script che disegna pesa pochi
	 * chilobyte ed e' roba nostra: non arriva da nessun altro server.
	 *
	 * Qui si carica solo lo SCRIPT. L'impalcatura CSS — la tela dietro al
	 * contenuto, la sfumatura di riserva — sta invece nel foglio del blocco
	 * contenitore, come gia' il velo colorato: cosi' c'e' una fonte sola e
	 * l'editor la vede senza doverla riscrivere.
	 */
	public static function use_sfondo(): void {
		if ( self::$sfondo ) {
			return;
		}

		self::$sfondo = true;

		wp_enqueue_script(
			'emme-sfondo-animato',
			EMME_BLOCKS_URL . 'shared/sfondo-animato.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Una scheda a due facce dichiara di esserci.
	 *
	 * Il giro lo fa il CSS, che sta nel foglio del blocco. Questo script
	 * aggiunge soltanto il tocco sui telefoni e il clic che rigira indietro:
	 * senza, la scheda funziona lo stesso al passaggio del mouse e con il
	 * tabulatore.
	 */
	public static function use_schede(): void {
		if ( self::$schede ) {
			return;
		}

		self::$schede = true;

		wp_enqueue_script(
			'emme-scheda-due-facce',
			EMME_BLOCKS_URL . 'shared/scheda-due-facce.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Un carosello dichiara di esserci.
	 *
	 * Qui lo script non e' un di piu': senza, il carosello resta una pila di
	 * diapositive. E' voluto — una pila si legge, un mucchio di riquadri
	 * sovrapposti no — ma vuol dire che il blocco va usato solo dove lo
	 * script puo' arrivare.
	 */
	public static function use_carosello(): void {
		if ( self::$caroselli ) {
			return;
		}

		self::$caroselli = true;

		wp_enqueue_script(
			'emme-carosello',
			EMME_BLOCKS_URL . 'shared/carosello.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Una barra ancorata allo scorrimento dichiara di esserci.
	 *
	 * Lo script aggiorna una sola variabile CSS mentre si scorre: tutto il
	 * resto - altezza, dimensione del contenuto, sfondo da ancorata - lo fa
	 * il CSS che il generatore ha gia' scritto. Senza lo script la barra
	 * resta dov'e', che e' il comportamento di sempre: nessuno se ne
	 * accorge se non arriva.
	 */
	/**
	 * Un contatore dichiara di esserci.
	 *
	 * Lo script conta da un numero all'altro quando il blocco entra nello
	 * schermo. Senza, il numero resta quello finale, che e' gia' scritto in
	 * pagina: chi legge vede il dato giusto comunque, e non si accorge che
	 * mancava qualcosa.
	 */
	public static function use_contatore(): void {
		if ( self::$contatori ) {
			return;
		}

		self::$contatori = true;

		wp_enqueue_script(
			'emme-contatore',
			EMME_BLOCKS_URL . 'shared/contatore.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	public static function use_ancoraggio(): void {
		if ( self::$ancoraggi ) {
			return;
		}

		self::$ancoraggi = true;

		wp_enqueue_script(
			'emme-ancoraggio',
			EMME_BLOCKS_URL . 'shared/testata-ancorata.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Legge i punti di rottura e decide dove stampare.
	 */
	public static function boot(): void {
		/**
		 * Permette di cambiare i punti di rottura sito per sito.
		 *
		 * Attenzione: cambiarli dopo che un sito e' online significa rivedere
		 * le pagine. Vanno fissati prima della consegna.
		 *
		 * @param array<string, int|null> $breakpoints Larghezze massime in pixel.
		 */
		$breakpoints = apply_filters( 'emme_breakpoints', Builder::breakpoints() );

		if ( is_array( $breakpoints ) ) {
			Builder::set_breakpoints( $breakpoints );
		}

		$hook = function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ? 'wp_head' : 'wp_footer';

		// Priorita' 20: dopo i fogli di stile gia' stampati, cosi' a parita' di
		// specificita' vincono le nostre regole.
		add_action( $hook, array( self::class, 'print_styles' ), 20 );

		add_action( 'enqueue_block_editor_assets', array( self::class, 'send_breakpoints_to_editor' ) );

		/*
		 * `enqueue_block_assets` e non `enqueue_block_editor_assets`: e' il
		 * solo gancio che WordPress porta **dentro alla tela**, che dalla 6.3
		 * e' un iframe. Lo dice il core stesso, nell'avviso che compare nella
		 * console quando un foglio ci entra per la strada sbagliata:
		 * «Please use block.json or enqueue_block_assets to add styles to
		 * the iframe». Vedi variabili_tavolozza().
		 */
		add_action( 'enqueue_block_assets', array( self::class, 'variabili_tavolozza' ) );
	}

	/**
	 * I colori della tavolozza come variabili CSS, dentro alla tela.
	 *
	 * PERCHE' SERVE
	 *
	 * Manuel, 12/11/2026: «il colore non e' applicato all'icona, anche
	 * l'ombra non cambia colore». Il comando salvava giusto e il generatore
	 * scriveva giusto - `color: var(--wp--preset--color--accent-2)` - ma nel
	 * suo editor non si vedeva niente.
	 *
	 * Un colore della tavolozza si salva come **riferimento**, non come
	 * valore: e' tutto il punto dei preset, ed e' quello che fa cambiare le
	 * pagine gia' fatte quando si cambia variante di stile. Il riferimento
	 * diventa una variabile CSS, e quella variabile la definisce un foglio
	 * del nucleo. Se quel foglio non entra nella tela dell'editor - e nella
	 * console di Manuel c'era proprio l'avviso che era entrato «in modo
	 * scorretto» - ogni nostro colore preso dalla tavolozza resta senza
	 * effetto **nell'editor**, mentre sul sito funziona.
	 *
	 * Qui le variabili si dichiarano una seconda volta, per conto nostro.
	 * Se ci sono gia' non cambia niente - stessi nomi, stessi valori - e se
	 * mancano il colore si vede lo stesso. Non e' una toppa sul nucleo: e'
	 * smettere di dipendere da un foglio che non e' nostro.
	 *
	 * I colori si leggono con `wp_get_global_settings()`, che e' l'API
	 * pubblica e tiene gia' conto del tema, delle varianti e di quello che
	 * il sito ha aggiunto dagli Stili.
	 */
	public static function variabili_tavolozza(): void {
		// Solo nell'editor: sul sito le variabili ci sono gia' e ridirle
		// sarebbe peso per niente.
		if ( ! is_admin() ) {
			return;
		}

		$tavolozza = wp_get_global_settings( array( 'color', 'palette' ) );

		if ( ! is_array( $tavolozza ) ) {
			return;
		}

		/*
		 * L'ordine e' quello di WordPress, dal meno importante al piu':
		 * l'ultimo che porta un nome vince, ed e' quello che il sito usa.
		 */
		$righe = array();

		foreach ( array( 'default', 'theme', 'custom' ) as $origine ) {
			foreach ( (array) ( $tavolozza[ $origine ] ?? array() ) as $colore ) {
				$slug = isset( $colore['slug'] ) ? sanitize_title( (string) $colore['slug'] ) : '';
				$vero = Builder::clean_value( $colore['color'] ?? '' );

				if ( '' === $slug || null === $vero ) {
					continue;
				}

				$righe[ $slug ] = '--wp--preset--color--' . $slug . ':' . $vero;
			}
		}

		if ( array() === $righe ) {
			return;
		}

		/*
		 * Un foglio senza file: serve solo come appiglio per la riga qui
		 * sotto. E' il modo che WordPress usa per gli stili calcolati.
		 */
		wp_register_style( 'emme-tavolozza-editor', false, array(), EMME_BLOCKS_VERSION );
		wp_enqueue_style( 'emme-tavolozza-editor' );
		wp_add_inline_style( 'emme-tavolozza-editor', ':root{' . implode( ';', $righe ) . '}' );
	}

	/**
	 * Consegna all'editor i punti di rottura in uso.
	 *
	 * L'editor deve costruire le stesse regole del sito, media query comprese.
	 * Se i due avessero numeri diversi, l'anteprima mentirebbe: ecco perche'
	 * il valore e' uno solo, sta in PHP, e viaggia da li' verso l'editor.
	 */
	public static function send_breakpoints_to_editor(): void {
		$breakpoints = Builder::breakpoints();

		wp_add_inline_script(
			'wp-blocks',
			'window.emmeBreakpoints = ' . wp_json_encode(
				array(
					'tablet' => (int) $breakpoints['tablet'],
					'mobile' => (int) $breakpoints['mobile'],
				)
			) . ';',
			'before'
		);
	}

	/**
	 * Un mazzo di carte dichiara di esserci.
	 *
	 * Lo script non serve ad aprirlo - quello lo fa il browser da solo, con
	 * la casella di spunta - ma a **chiuderlo** dove uno se lo aspetta: con
	 * un clic da un'altra parte, con il tasto di uscita, e portando via il
	 * mouse da un mazzo che si apre al passaggio. Senza, il mazzo si chiude
	 * lo stesso ricliccando la carta centrale: si perde una comodita', non
	 * il blocco. Vedi shared/mazzo.js.
	 */
	public static function use_mazzo(): void {
		if ( self::$mazzi ) {
			return;
		}

		self::$mazzi = true;

		wp_enqueue_script(
			'emme-mazzo',
			EMME_BLOCKS_URL . 'shared/mazzo.js',
			array(),
			EMME_BLOCKS_VERSION,
			true
		);
	}

	/**
	 * Un blocco consegna delle regole che ha calcolato lui.
	 *
	 * Si usa solo dove il generatore non arriva, cioe' dove quello che serve
	 * non e' un valore ma una **regola**: vedi il campo `$regole` qui sopra.
	 * Quello che arriva qui non viene da chi scrive la pagina, viene da un
	 * conto fatto su numeri gia' riportati dentro ai loro limiti.
	 *
	 * @param string $css Le regole, gia' pronte.
	 */
	public static function add_rules( string $css ): void {
		if ( '' === $css ) {
			return;
		}

		self::$regole[] = $css;
	}

	/**
	 * Stampa in pagina il foglio di stile dei blocchi presenti.
	 */
	public static function print_styles(): void {
		// Le regole delle animazioni vengono prima: cosi' le impostazioni del
		// singolo blocco, scritte dopo, possono sovrascriverle.
		$css  = self::$animazioni ? self::file_css( 'animazioni.css' ) : '';
		$css .= self::$lightbox ? self::file_css( 'lightbox.css' ) : '';

		// L'ancoraggio prima delle regole dei blocchi, come le animazioni: le
		// variabili che il generatore scrive per il singolo blocco - dove si
		// ferma, quanto resta del contenuto - devono poter vincere.
		$css .= self::$ancoraggi ? self::file_css( 'ancoraggio.css' ) : '';
		$css .= Builder::is_empty() ? '' : Builder::stylesheet();

		// Le regole calcolate durante la resa, per ultime: sono quelle piu'
		// specifiche e nessuna le deve poter coprire.
		$css .= implode( '', self::$regole );

		if ( '' === $css ) {
			return;
		}

		// I valori sono gia' filtrati dal Builder, che rifiuta "</". Questo e' un
		// secondo giro di chiave: se un domani la tabella delle corrispondenze
		// contenesse qualcosa di distratto, non si esce comunque dal tag style.
		$css = str_replace( '</', '', $css );

		printf( "<style id=\"emme-blocks-inline\">%s</style>\n", $css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS gia filtrato dal Builder.

		if ( self::$animazioni ) {
			self::print_animations_guard();
		}
	}

	/**
	 * La riga che accende le animazioni, e la rete di sicurezza che le spegne.
	 *
	 * Le regole che nascondono i blocchi animati valgono solo dentro la classe
	 * emme-anim-attive, che viene messa qui. Due conseguenze volute:
	 *
	 * - senza JavaScript la classe non arriva mai, quindi niente si nasconde e
	 *   il contenuto si legge lo stesso;
	 * - se il JavaScript c'e' ma lo script delle animazioni non arriva (rete,
	 *   blocchi del browser, un errore), dopo tre secondi la classe si toglie da
	 *   sola e il contenuto compare.
	 *
	 * Un contenuto che sparisce perche' uno script non ha caricato e' il
	 * difetto peggiore che questo genere di animazioni possa avere, e succede
	 * su moltissimi siti veri. Qui non puo' succedere.
	 *
	 * Sta in testa alla pagina, insieme al foglio di stile, per non far
	 * comparire e poi sparire i blocchi.
	 */
	private static function print_animations_guard(): void {
		echo '<script id="emme-animazioni-guardia">'
			. "document.documentElement.classList.add('emme-anim-attive');"
			. 'setTimeout(function(){'
			. 'if(!window.emmeAnimazioniAvviate){'
			. "document.documentElement.classList.remove('emme-anim-attive');"
			. '}},3000);'
			. "</script>\n";
	}

	/**
	 * Legge uno dei nostri fogli di stile e lo alleggerisce.
	 *
	 * Sono file nostri, scritti a mano: niente da filtrare, solo commenti e
	 * spazi da togliere perche' finiscono dentro la pagina.
	 *
	 * @param string $nome Nome del file dentro shared/.
	 */
	private static function file_css( string $nome ): string {
		$file = dirname( __DIR__, 2 ) . '/shared/' . $nome;

		if ( ! is_readable( $file ) ) {
			return '';
		}

		$css = (string) file_get_contents( $file );

		$css = (string) preg_replace( '#/\*.*?\*/#s', '', $css );
		$css = (string) preg_replace( '/\s+/', ' ', $css );
		$css = str_replace( array( ' {', '{ ', ' }', '} ', ': ', '; ', ', ' ), array( '{', '{', '}', '}', ':', ';', ',' ), $css );

		return trim( $css );
	}
}
