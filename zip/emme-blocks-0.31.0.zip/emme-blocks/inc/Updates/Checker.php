<?php
/**
 * Controllo degli aggiornamenti del plugin.
 *
 * Stesso meccanismo del tema, ma per i plugin: l'intestazione "Update URI" nel
 * file principale indica il nostro scaffale su GitHub Pages, e WordPress chiama
 * il filtro update_plugins_<nome del server>. Noi rispondiamo con l'ultima
 * versione disponibile; il confronto con quella installata lo fa WordPress.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Updates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Interroga lo scaffale degli aggiornamenti e risponde a WordPress.
 */
final class Checker {

	/**
	 * Indirizzo dello scaffale.
	 */
	private const BASE_URL = 'https://mmazzottismp.github.io/quattroemme-updates/';

	/**
	 * Nome del server, da cui WordPress costruisce il nome del filtro.
	 */
	private const HOST = 'mmazzottismp.github.io';

	/**
	 * Canali ammessi.
	 *
	 * @var string[]
	 */
	private const CHANNELS = array( 'stabile', 'pilota' );

	/**
	 * Nome della cartella del plugin, usato come nome del file di testo.
	 */
	private const SLUG = 'emme-blocks';

	/**
	 * Aggancia il controllo ai meccanismi di WordPress.
	 */
	public static function init(): void {
		add_filter( 'update_plugins_' . self::HOST, array( self::class, 'respond' ), 10, 3 );
		add_action( 'upgrader_process_complete', array( self::class, 'forget' ) );
	}

	/**
	 * Canale di aggiornamento di questo sito.
	 *
	 * Si sceglie per sito scrivendo in wp-config.php:
	 *
	 *     define( 'EMME_UPDATE_CHANNEL', 'pilota' );
	 *
	 * Senza quella riga il sito sta sul canale stabile.
	 */
	public static function channel(): string {
		$channel = defined( 'EMME_UPDATE_CHANNEL' ) ? (string) EMME_UPDATE_CHANNEL : 'stabile';

		return in_array( $channel, self::CHANNELS, true ) ? $channel : 'stabile';
	}

	/**
	 * Risponde quando WordPress chiede se c'e' una versione nuova.
	 *
	 * @param array<string, mixed>|false $update      Risposta di chi ci ha preceduto.
	 * @param array<string, mixed>       $plugin_data Intestazioni del plugin.
	 * @param string                     $plugin_file Percorso del plugin, es. emme-blocks/emme-blocks.php.
	 * @return array<string, mixed>|false
	 */
	public static function respond( $update, array $plugin_data, string $plugin_file ) {
		// Se qualcun altro ha gia' risposto, o non si parla di noi, non tocchiamo niente.
		if ( false !== $update || self::SLUG . '/' . self::SLUG . '.php' !== $plugin_file ) {
			return $update;
		}

		$manifest = self::manifest();

		if ( null === $manifest || empty( $manifest['package'] ) ) {
			return $update;
		}

		// L'indirizzo del pacchetto arriva dal file del canale, cioe' da fuori.
		// Deve stare sotto il nostro indirizzo: se un giorno finisse li' dentro un
		// file sbagliato - una configurazione storta dello scaffale, una modifica
		// entrata per errore - quel file potrebbe mandare TUTTI i siti dei clienti
		// a scaricare un pacchetto di qualcun altro, che viene installato ed
		// eseguito. Con questo controllo, per farlo servirebbero due errori invece
		// di uno.
		if ( ! self::nostro_indirizzo( (string) $manifest['package'] ) ) {
			return $update;
		}

		return array(
			'slug'         => self::SLUG,
			'version'      => (string) $manifest['version'],
			'url'          => (string) ( $manifest['url'] ?? '' ),
			'package'      => (string) $manifest['package'],
			'tested'       => (string) ( $manifest['tested'] ?? '' ),
			'requires_php' => (string) ( $manifest['requires_php'] ?? '' ),
		);
	}

	/**
	 * Dice se un indirizzo sta davvero sotto il nostro scaffale.
	 *
	 * Si confronta l'inizio della stringa dopo averla normalizzata, e si
	 * pretende https: su http qualcuno sulla stessa rete potrebbe sostituire
	 * il pacchetto durante il viaggio.
	 *
	 * @param string $url Indirizzo da controllare.
	 * @return bool Vero se possiamo fidarci.
	 */
	private static function nostro_indirizzo( string $url ): bool {
		$pulito = esc_url_raw( trim( $url ) );

		if ( '' === $pulito || 0 !== strpos( $pulito, 'https://' ) ) {
			return false;
		}

		return 0 === strpos( $pulito, self::BASE_URL );
	}

	/**
	 * Legge il file di testo del canale, con memoria temporanea di sei ore.
	 *
	 * @param bool $force Salta la memoria temporanea.
	 * @return array<string, mixed>|null
	 */
	public static function manifest( bool $force = false ): ?array {
		$channel       = self::channel();
		$transient_key = 'emme_blocks_update_' . $channel;

		if ( ! $force ) {
			$cached = get_site_transient( $transient_key );

			if ( is_array( $cached ) ) {
				return $cached;
			}

			if ( 'non-disponibile' === $cached ) {
				return null;
			}
		}

		$response = wp_remote_get(
			self::BASE_URL . $channel . '/' . self::SLUG . '.json',
			array(
				'timeout' => 10,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);

		$body = ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) )
			? null
			: json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $body ) || empty( $body['version'] ) ) {
			set_site_transient( $transient_key, 'non-disponibile', HOUR_IN_SECONDS );

			return null;
		}

		set_site_transient( $transient_key, $body, 6 * HOUR_IN_SECONDS );

		return $body;
	}

	/**
	 * Dimentica la memoria temporanea dopo un aggiornamento.
	 */
	public static function forget(): void {
		foreach ( self::CHANNELS as $channel ) {
			delete_site_transient( 'emme_blocks_update_' . $channel );
		}
	}
}
