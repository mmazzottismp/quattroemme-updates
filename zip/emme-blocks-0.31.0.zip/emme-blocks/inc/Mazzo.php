<?php
/**
 * Dove finisce ogni carta del mazzo, in un posto solo.
 *
 * PERCHE' ESISTE
 *
 * Il mazzo e' una carta sola che, quando la si tocca, si apre in tante carte
 * disposte attorno a lei. Dove va a finire ognuna - di quanto si sposta, in
 * che direzione, di quanto resta storta - e' un conto di trigonometria che
 * va fatto **due volte**: una dal PHP quando scrive la pagina, una dal
 * JavaScript quando l'editor mostra l'anteprima.
 *
 * Se i due conti non coincidono, l'anteprima mente: si compone una pagina
 * che a video sembra giusta e sul sito le carte stanno altrove. E' lo stesso
 * difetto che il confronto fra i due generatori di CSS esiste per escludere.
 *
 * Qui sta la meta' in PHP. La gemella e' `src/lib/mazzo.js`, e una tabella
 * di casi in `tests/casi-mazzo.json` controlla tutte e due contro gli stessi
 * numeri attesi: se una delle due cambia, la prova diventa rossa.
 *
 * IL DISORDINE NON E' A CASO
 *
 * «Lanciate su un tavolo» vuol dire che ogni carta e' storta per conto suo.
 * Ma una vera estrazione a sorte darebbe carte diverse a ogni ricarica della
 * pagina, e diverse fra editor e sito: le carte ballerebbero. Qui il
 * disordine si ricava dall'**indice** della carta con un rimescolamento di
 * numeri interi a 32 bit - niente virgola, niente differenze fra PHP e
 * JavaScript - quindi la carta numero tre e' sempre storta allo stesso modo.
 *
 * Come il generatore CSS e la libreria di icone, questa classe non usa
 * nessuna funzione di WordPress: si prova da sola.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Calcola la posizione delle carte di un mazzo.
 */
final class Mazzo {

	/**
	 * Come si dispongono le carte attorno a quella centrale.
	 *
	 * La prima e' quella di partenza: chi scrive una disposizione
	 * sconosciuta si ritrova questa, non una pagina rotta.
	 */
	public const DISPOSIZIONI = array( 'cerchio', 'ventaglio', 'sparse' );

	/**
	 * Come stanno girate le carte quando sono aperte.
	 */
	public const GIRATE = array( 'storte', 'dritte' );

	/**
	 * Cosa apre il mazzo.
	 *
	 * «passaggio» vuol dire che basta passarci sopra con il mouse - e il clic
	 * funziona comunque, perche' sul telefono il passaggio non esiste.
	 */
	public const APERTURE = array( 'passaggio', 'clic' );

	/**
	 * Le curve del tempo ammesse per il volo.
	 *
	 * Sono le stesse quattro delle animazioni di comparsa - la prima e'
	 * quella di partenza. L'elenco esiste perche' questo valore finisce
	 * dentro a un attributo `style` della pagina: quello che arriva dal
	 * contenuto non si scrive mai come arriva.
	 */
	public const CURVE = array(
		'cubic-bezier(0.34, 1.3, 0.64, 1)',
		'cubic-bezier(0.42, 0, 0.58, 1)',
		'linear',
		'ease-out',
	);

	/**
	 * Quanto si possono allontanare le carte, in pixel.
	 *
	 * Sotto i quaranta non si vede che si sono aperte; sopra i seicento
	 * escono dallo schermo di un telefono e il blocco diventa una voragine
	 * di spazio vuoto, perche' il posto va riservato anche da chiuso.
	 */
	public const DISTANZA_MINIMA  = 40;
	public const DISTANZA_MASSIMA = 600;

	/**
	 * Di quanto si allontanano, se nessuno lo dice.
	 *
	 * E' piu' della larghezza di una carta, e non per caso: a una distanza
	 * minore della sua larghezza, la carta a destra finisce sotto a quella
	 * centrale e il suo titolo non si legge piu'. Visto in Chrome il
	 * 12/11/2026, con il valore di prima: «Materna» si leggeva «erna».
	 *
	 * La larghezza di partenza di una carta e' 13rem, cioe' 208 pixel: vedi
	 * `--emme-mazzo-carta-larga` in style.scss. Chi allarga le carte deve
	 * allontanarle, e il pannello lo dice.
	 */
	public const DISTANZA_PREDEFINITA = 240;

	/**
	 * Di quanto possono essere storte, in gradi.
	 *
	 * Oltre i quarantacinque una carta non si legge piu' di sbieco: si legge
	 * girando la testa.
	 */
	public const ANGOLO_MASSIMO = 45;

	/**
	 * Quanto puo' durare il volo, in millesimi di secondo.
	 *
	 * Come per la fisarmonica, il limite non e' prudenza: oltre i due secondi
	 * l'apertura non sembra piu' morbida, sembra rotta.
	 */
	public const TEMPO_MASSIMO = 2000;

	/**
	 * Quanto sporgono le carte da sotto a quella centrale, da ferme.
	 *
	 * E' una frazione di quanto si allontaneranno: cosi' ognuna si affaccia
	 * **dalla parte in cui poi volera'**, che e' quello che fa leggere il
	 * mucchio come un mazzo di carte e non come una pila di fogli.
	 */
	public const QUOTA_RIPOSO = 0.08;

	/**
	 * L'arco su cui si apre il ventaglio, in gradi.
	 */
	public const ARCO_VENTAGLIO = 150;

	/**
	 * Riporta un valore dentro al suo elenco.
	 *
	 * @param mixed         $valore Quello che c'e' scritto nel blocco.
	 * @param array<string> $elenco I valori ammessi.
	 * @return string Il valore, oppure il primo dell'elenco.
	 */
	public static function dentro( mixed $valore, array $elenco ): string {
		return is_string( $valore ) && in_array( $valore, $elenco, true ) ? $valore : $elenco[0];
	}

	/**
	 * Un numero riportato fra due estremi.
	 *
	 * @param mixed $valore  Quello che c'e' scritto nel blocco.
	 * @param int   $minimo  Il piu' piccolo accettato.
	 * @param int   $massimo Il piu' grande accettato.
	 * @param int   $quando_manca Il valore da usare se non c'e' niente.
	 * @return int Un numero intero dentro ai limiti.
	 */
	public static function numero( mixed $valore, int $minimo, int $massimo, int $quando_manca ): int {
		if ( ! is_numeric( $valore ) ) {
			return $quando_manca;
		}

		return max( $minimo, min( $massimo, self::arrotonda( (float) $valore ) ) );
	}

	/**
	 * Arrotonda allo stesso modo in PHP e in JavaScript.
	 *
	 * Non si usa `round()`: PHP arrotonda i mezzi lontano dallo zero
	 * (-2.5 diventa -3) e `Math.round` del JavaScript li arrotonda verso
	 * l'alto (-2.5 diventa -2). Una carta su un confine finirebbe in due
	 * posti diversi. `floor( v + 0.5 )` fa la stessa cosa in tutti e due.
	 *
	 * @param float $valore Il numero da arrotondare.
	 * @return int Il numero intero.
	 */
	public static function arrotonda( float $valore ): int {
		return (int) floor( $valore + 0.5 );
	}

	/**
	 * Un numero fra zero e uno, sempre lo stesso per lo stesso indice.
	 *
	 * E' il rimescolamento che fa il disordine. Tutto a numeri interi su 32
	 * bit, e in JavaScript con `Math.imul`: cosi' PHP e JavaScript danno lo
	 * **stesso** numero, cifra per cifra. Con un `sin()` moltiplicato per una
	 * costante grande - il modo che si trova scritto dappertutto - i due si
	 * sarebbero divisi all'ultima cifra, e l'errore si sarebbe visto solo su
	 * qualche carta, solo su qualche sito.
	 *
	 * @param int $indice Il numero della carta.
	 * @param int $seme   A cosa serve il numero: distanza, angolo, rotazione.
	 * @return float Un numero da 0 compreso a 1 escluso.
	 */
	public static function caso( int $indice, int $seme ): float {
		$h = ( self::per( $indice + 1, 2654435761 ) + self::per( $seme, 2246822519 ) ) & 0xFFFFFFFF;
		$h = ( $h ^ ( $h >> 15 ) ) & 0xFFFFFFFF;
		$h = self::per( $h, 2246822519 );
		$h = ( $h ^ ( $h >> 13 ) ) & 0xFFFFFFFF;
		$h = self::per( $h, 3266489917 );
		$h = ( $h ^ ( $h >> 16 ) ) & 0xFFFFFFFF;

		return $h / 4294967296;
	}

	/**
	 * Moltiplicazione fra interi a 32 bit, con quello che esce dal fondo
	 * buttato via.
	 *
	 * Serve perche' il prodotto di due numeri a 32 bit ne vuole 64, e i piu'
	 * grandi - 4294967295 per 2246822519 fa 9,6 miliardi di miliardi - non
	 * ci stanno nemmeno in quelli: PHP li trasformerebbe in numeri con la
	 * virgola e l'ultima cifra andrebbe persa, mentre il JavaScript con
	 * `Math.imul` continuerebbe a contare giusto. I due si dividerebbero
	 * proprio sulle carte piu' in fondo al mazzo.
	 *
	 * Si moltiplica a meta' per volta - sedici bit alti e sedici bassi -
	 * cosi' nessun prodotto intermedio passa i 48 bit.
	 *
	 * @param int $a Primo fattore.
	 * @param int $b Secondo fattore.
	 * @return int Il prodotto, tenuti solo i 32 bit bassi.
	 */
	private static function per( int $a, int $b ): int {
		$a &= 0xFFFFFFFF;
		$b &= 0xFFFFFFFF;

		$alti  = ( ( ( $a >> 16 ) * $b ) & 0xFFFF ) << 16;
		$bassi = ( $a & 0xFFFF ) * $b;

		return ( $alti + $bassi ) & 0xFFFFFFFF;
	}

	/**
	 * Dove va ogni carta, aperta e da ferma.
	 *
	 * La carta numero zero e' quella centrale: non si sposta mai, e l'unica
	 * cosa che puo' fare e' stare storta anche da ferma. Tutte le altre
	 * partono da sotto di lei, sporgono un po', e all'apertura volano.
	 *
	 * @param int                 $quante   Quante carte ci sono in tutto, quella centrale compresa.
	 * @param array<string,mixed> $opzioni  disposizione, distanza, girate, angolo, angoloPerno.
	 * @return array<int, array<string,int>> Un elemento per carta, con x, y, rot, rx, ry, rrot, z.
	 */
	public static function posti( int $quante, array $opzioni ): array {
		if ( $quante < 1 ) {
			return array();
		}

		$disposizione = self::dentro( $opzioni['disposizione'] ?? null, self::DISPOSIZIONI );
		$girate       = self::dentro( $opzioni['girate'] ?? null, self::GIRATE );
		$distanza     = self::numero( $opzioni['distanza'] ?? null, self::DISTANZA_MINIMA, self::DISTANZA_MASSIMA, self::DISTANZA_PREDEFINITA );
		$angolo       = self::numero( $opzioni['angolo'] ?? null, 0, self::ANGOLO_MASSIMO, 12 );
		$angolo_perno = self::numero( $opzioni['angoloPerno'] ?? null, -self::ANGOLO_MASSIMO, self::ANGOLO_MASSIMO, 0 );

		// La carta centrale: ferma al suo posto, storta quanto le si e'
		// chiesto, e sopra a tutte le altre.
		$posti = array(
			array(
				'x'    => 0,
				'y'    => 0,
				'rot'  => $angolo_perno,
				'rx'   => 0,
				'ry'   => 0,
				'rrot' => $angolo_perno,
				'z'    => $quante,
			),
		);

		$satelliti = $quante - 1;

		for ( $s = 0; $s < $satelliti; $s++ ) {
			$gradi = self::angolo_carta( $s, $satelliti, $disposizione );
			$lungo = (float) $distanza;

			if ( 'sparse' === $disposizione ) {
				// Sparse: ognuna si allontana un po' diversamente, fra tre
				// quarti e un quarto in piu' della distanza chiesta.
				$lungo *= 0.75 + self::caso( $s, 7 ) * 0.5;
			}

			$radianti = deg2rad( $gradi );
			$x        = self::arrotonda( $lungo * cos( $radianti ) );
			$y        = self::arrotonda( $lungo * sin( $radianti ) );

			$rot = 'dritte' === $girate
				? 0
				: self::arrotonda( ( self::caso( $s, 13 ) * 2 - 1 ) * $angolo );

			$posti[] = array(
				'x'    => $x,
				'y'    => $y,
				'rot'  => $rot,
				'rx'   => self::arrotonda( $x * self::QUOTA_RIPOSO ),
				'ry'   => self::arrotonda( $y * self::QUOTA_RIPOSO ),
				'rrot' => self::arrotonda( $rot * self::QUOTA_RIPOSO ),
				'z'    => $satelliti - $s,
			);
		}

		return $posti;
	}

	/**
	 * In che direzione vola una carta, in gradi.
	 *
	 * Zero gradi e' a destra e i gradi crescono verso il basso, come vuole
	 * il sistema di coordinate dello schermo: per questo il «sopra» e'
	 * -90 e non +90.
	 *
	 * @param int    $s            Il numero del satellite, da zero.
	 * @param int    $satelliti    Quanti satelliti ci sono.
	 * @param string $disposizione cerchio, ventaglio o sparse.
	 * @return float I gradi.
	 */
	private static function angolo_carta( int $s, int $satelliti, string $disposizione ): float {
		if ( 'ventaglio' === $disposizione ) {
			// Un solo satellite: dritto sopra la carta centrale, perche'
			// dividere un arco per zero non si puo' e mezzo ventaglio con una
			// carta sola non si vedrebbe come un ventaglio.
			if ( $satelliti < 2 ) {
				return -90.0;
			}

			return -90.0 - self::ARCO_VENTAGLIO / 2 + self::ARCO_VENTAGLIO * $s / ( $satelliti - 1 );
		}

		$passo = 360.0 / $satelliti;
		$gradi = -90.0 + $passo * $s;

		if ( 'sparse' === $disposizione ) {
			// Scostamento fino a tre decimi del passo, in un verso o
			// nell'altro: le carte restano distribuite attorno, ma non piu'
			// in fila come i raggi di una ruota.
			$gradi += ( self::caso( $s, 3 ) * 2 - 1 ) * $passo * 0.3;
		}

		return $gradi;
	}

	/**
	 * Quanto spazio serve attorno alla carta centrale perche' ci stiano tutte.
	 *
	 * Lo spazio si riserva **anche da chiuso**: se comparisse all'apertura,
	 * aprendo il mazzo tutta la pagina sotto farebbe un salto.
	 *
	 * I quattro lati si contano separatamente, e non e' pignoleria: il
	 * ventaglio si apre solo verso l'alto, e riservargli sotto lo stesso
	 * spazio che ha sopra lascerebbe nella pagina un buco alto quanto il
	 * ventaglio in cui non c'e' niente.
	 *
	 * Attenzione a cosa sono questi numeri: sono quanto viaggia il **centro**
	 * della carta, non il suo bordo. La meta' di carta che avanza la
	 * aggiunge il foglio di stile, che e' l'unico a sapere quanto e' grande
	 * una carta. Vedi style.scss, dove lo spazio e' il margine delle carte e
	 * non il bordo interno del tavolo.
	 *
	 * @param array<int, array<string,int>> $posti Quelli restituiti da posti().
	 * @return array{sopra:int, sotto:int, sinistra:int, destra:int} I pixel per lato.
	 */
	public static function ingombro( array $posti ): array {
		$ingombro = array(
			'sopra'    => 0,
			'sotto'    => 0,
			'sinistra' => 0,
			'destra'   => 0,
		);

		foreach ( $posti as $posto ) {
			$ingombro['sopra']    = max( $ingombro['sopra'], -$posto['y'] );
			$ingombro['sotto']    = max( $ingombro['sotto'], $posto['y'] );
			$ingombro['sinistra'] = max( $ingombro['sinistra'], -$posto['x'] );
			$ingombro['destra']   = max( $ingombro['destra'], $posto['x'] );
		}

		return $ingombro;
	}

	/**
	 * Di quanto sporge una carta storta, in frazione della sua larghezza.
	 *
	 * Una carta girata ha un **riquadro** piu' grande della carta: girandola
	 * di dodici gradi, una carta larga 240 pixel diventa alta 25 pixel di
	 * piu', dodici per parte. Misurato in Chrome il 12/11/2026, e si vedeva:
	 * gli angoli delle carte uscivano dal blocco e finivano sopra al titolo
	 * che stava li' sotto.
	 *
	 * Quanto sporge e' `(larghezza x seno + altezza x coseno - altezza) / 2`.
	 * L'altezza di una carta da qui non si sa - e' quella del suo contenuto -
	 * ma il secondo pezzo e' sempre negativo o zero, perche' il coseno non
	 * passa mai l'uno: quindi **meta' della larghezza per il seno** e' sempre
	 * abbastanza. Si tiene quella, e il seno si calcola qui perche' il foglio
	 * di stile deve funzionare anche sui browser che `sin()` non ce l'hanno.
	 *
	 * @param array<int, array<string,int>> $posti Quelli restituiti da posti().
	 * @return float La frazione, con quattro decimali.
	 */
	public static function quota_storto( array $posti ): float {
		$storto = 0;

		foreach ( $posti as $posto ) {
			$storto = max( $storto, abs( $posto['rot'] ) );
		}

		// Quattro decimali, e arrotondati come li arrotonda il JavaScript:
		// `round()` con il numero di posizioni ha un suo aggiustamento che
		// la meta' gemella non fa, e il numero finisce in pagina come testo.
		return round( sin( deg2rad( $storto ) ) * 10000 ) / 10000;
	}

	/**
	 * Le regole CSS che mettono ogni carta al suo posto.
	 *
	 * Le posizioni non possono stare nell'attributo `style` della carta,
	 * perche' la carta la scrive il blocco figlio e il blocco figlio non sa
	 * di essere la terza: in WordPress un blocco non conosce il proprio
	 * posto fra i fratelli. Lo sa il gruppo, che li ha tutti, e lo dice con
	 * `:nth-child()`.
	 *
	 * La stessa funzione la usa l'editor: cosi' le regole sono le stesse,
	 * carattere per carattere, e l'anteprima non puo' divergere.
	 *
	 * @param string                        $emme_id L'identificativo del gruppo.
	 * @param array<int, array<string,int>> $posti   Quelli restituiti da posti().
	 * @return string Il CSS, oppure la stringa vuota se non c'e' niente da dire.
	 */
	public static function foglio( string $emme_id, array $posti ): string {
		if ( '' === $emme_id || array() === $posti ) {
			return '';
		}

		$css = '';

		foreach ( $posti as $i => $posto ) {
			$css .= sprintf(
				'.emme-b-%1$s .emme-mazzo__carte>.emme-mazzo__carta:nth-child(%2$d){'
					. '--emme-mazzo-x:%3$dpx;--emme-mazzo-y:%4$dpx;--emme-mazzo-rot:%5$ddeg;'
					. '--emme-mazzo-rx:%6$dpx;--emme-mazzo-ry:%7$dpx;--emme-mazzo-rrot:%8$ddeg;'
					. '--emme-mazzo-z:%9$d}',
				$emme_id,
				$i + 1,
				$posto['x'],
				$posto['y'],
				$posto['rot'],
				$posto['rx'],
				$posto['ry'],
				$posto['rrot'],
				$posto['z']
			);
		}

		return $css;
	}
}
