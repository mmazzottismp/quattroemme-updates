<?php
/**
 * La libreria di pattern.
 *
 * Un "pattern" e' una sezione gia' composta — un'apertura, una riga di
 * servizi, una citazione — che si inserisce dall'editor e poi si modifica
 * liberamente. E' la differenza fra avere dei blocchi e avere un modo di fare
 * i siti: con i soli blocchi ogni pagina si ricompone da zero.
 *
 * PERCHE' STANNO NEL PLUGIN E NON NEL TEMA
 *
 * WordPress scopre da solo i pattern dentro la cartella `patterns/` di un
 * TEMA, non di un plugin: qui quindi si fa a mano quello che il core fa li'
 * (`_register_theme_block_patterns`), leggendo le stesse intestazioni con la
 * stessa funzione. I file restano percio' identici a quelli di un tema, e
 * spostarli un giorno non costerebbe niente.
 *
 * La ragione della scelta e' la direzione della dipendenza. I nostri pattern
 * sono fatti con i blocchi `emme/*`: se stessero nel tema, il tema
 * dipenderebbe dal plugin, al contrario di quello che abbiamo dichiarato
 * (vedi TemaRichiesto). Stando nel plugin, dipendono dai propri blocchi — che
 * ci sono sempre — e dai preset del tema, che il plugin gia' pretende.
 *
 * In piu' ereditano le traduzioni: il testo dei pattern passa da
 * `esc_html__()` con il dominio del plugin, quindi finisce nello stesso
 * catalogo di tutto il resto.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Registra le categorie e i pattern del plugin.
 */
final class Patterns {

	/**
	 * La categoria sotto cui compaiono tutti i nostri pattern.
	 *
	 * Ognuno dichiara anche una categoria del core (`services`,
	 * `call-to-action`, `about`...), cosi' si trova sia cercando quattroemme
	 * sia guardando nel posto dove uno si aspetterebbe quel tipo di sezione.
	 */
	public const CATEGORIA = 'quattroemme';

	/**
	 * Il dominio delle traduzioni: lo stesso di tutto il plugin.
	 *
	 * Non si ridichiara qui: si prende da Traduzioni, che e' il posto dove
	 * sta scritto una volta sola.
	 */
	private const DOMINIO = Traduzioni::DOMINIO;

	/**
	 * Le intestazioni dei file, le stesse che legge WordPress nei temi.
	 *
	 * @var array<string, string>
	 */
	private const INTESTAZIONI = array(
		'title'         => 'Title',
		'slug'          => 'Slug',
		'description'   => 'Description',
		'viewportWidth' => 'Viewport Width',
		'inserter'      => 'Inserter',
		'categories'    => 'Categories',
		'keywords'      => 'Keywords',
		'blockTypes'    => 'Block Types',
	);

	/**
	 * Le intestazioni che contengono un elenco separato da virgole.
	 *
	 * @var string[]
	 */
	private const ELENCHI = array( 'categories', 'keywords', 'blockTypes' );

	/**
	 * Aggancia la registrazione.
	 *
	 * Priorita' 20 su `init`: i blocchi si registrano a 10, e un pattern
	 * registrato prima dei suoi blocchi comparirebbe nell'inseritore con
	 * dentro dei blocchi che non esistono ancora.
	 */
	public static function init(): void {
		add_action( 'init', array( self::class, 'registra' ), 20 );
	}

	/**
	 * Registra la categoria e tutti i file di `patterns/`.
	 */
	public static function registra(): void {
		if ( ! function_exists( 'register_block_pattern' ) ) {
			return;
		}

		register_block_pattern_category(
			self::CATEGORIA,
			array(
				'label'       => __( 'quattroemme', 'emme-blocks' ),
				'description' => __( 'Sections ready to drop into a page: openings, services, quotes, calls to action.', 'emme-blocks' ),
			)
		);

		foreach ( self::file() as $percorso ) {
			$dati = self::leggi( $percorso );

			if ( null === $dati ) {
				continue;
			}

			/*
			 * Titolo e descrizione arrivano dal commento in cima al file, non
			 * da una chiamata di traduzione: vanno tradotti qui, con gli
			 * stessi contesti che usa il core per i pattern dei temi
			 * (wp-includes/block-patterns.php). Senza questo restano in
			 * inglese anche su un sito italiano — ed era cosi' fino al
			 * 09/11/2026, perche' le prove controllavano le stringhe senza
			 * contesto e quindi non se ne accorgevano.
			 */
			$dati['title'] = translate_with_gettext_context( $dati['title'], 'Pattern title', self::DOMINIO );

			if ( ! empty( $dati['description'] ) ) {
				$dati['description'] = translate_with_gettext_context( $dati['description'], 'Pattern description', self::DOMINIO );
			}

			register_block_pattern( $dati['slug'], $dati );
		}
	}

	/**
	 * I file dei pattern, in ordine.
	 *
	 * L'ordine del nome e' l'ordine nell'inseritore: per questo i file sono
	 * numerati. Senza numeri l'elenco verrebbe in ordine alfabetico, cioe'
	 * casuale rispetto a come si costruisce una pagina.
	 *
	 * @return string[] I percorsi.
	 */
	public static function file(): array {
		$trovati = glob( EMME_BLOCKS_PATH . 'patterns/*.php' );

		if ( ! is_array( $trovati ) ) {
			return array();
		}

		sort( $trovati );

		return $trovati;
	}

	/**
	 * Legge un file di pattern: intestazioni e contenuto.
	 *
	 * @param string $percorso Il file.
	 * @return array<string, mixed>|null I dati pronti per register_block_pattern, o null se il file non va bene.
	 */
	public static function leggi( string $percorso ): ?array {
		$dati = get_file_data( $percorso, self::INTESTAZIONI );

		if ( empty( $dati['slug'] ) || empty( $dati['title'] ) ) {
			return null;
		}

		foreach ( self::ELENCHI as $chiave ) {
			if ( ! empty( $dati[ $chiave ] ) ) {
				$dati[ $chiave ] = array_filter( array_map( 'trim', explode( ',', $dati[ $chiave ] ) ) );
			} else {
				unset( $dati[ $chiave ] );
			}
		}

		if ( ! empty( $dati['viewportWidth'] ) ) {
			$dati['viewportWidth'] = (int) $dati['viewportWidth'];
		} else {
			unset( $dati['viewportWidth'] );
		}

		// `Inserter: no` nasconde il pattern dall'inseritore: serve ai pattern
		// pensati solo per essere richiamati da un modello.
		$dati['inserter'] = ! ( isset( $dati['inserter'] ) && in_array( strtolower( $dati['inserter'] ), array( 'no', 'false' ), true ) );

		// Il contenuto si prende eseguendo il file: dentro ci sono le
		// chiamate di traduzione, che vanno eseguite e non stampate.
		ob_start();
		include $percorso;
		$dati['content'] = (string) ob_get_clean();

		if ( '' === trim( $dati['content'] ) ) {
			return null;
		}

		return $dati;
	}
}
