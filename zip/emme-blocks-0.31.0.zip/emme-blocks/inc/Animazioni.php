<?php
/**
 * Le animazioni di comparsa: l'elenco, in un posto solo.
 *
 * Prima questo elenco era ripetuto in sei punti — lo schema, il pannello
 * dell'editor e il render.php di ogni blocco — e aggiungere un'animazione
 * voleva dire ricordarsene sei volte. Dimenticarne uno non dava nessun
 * errore: l'animazione semplicemente non compariva su quel blocco, oppure
 * compariva nel menu e poi in pagina non succedeva niente.
 *
 * Adesso la fonte e' una sola, shared/animazioni.json, e una prova controlla
 * che ogni tipo dichiarato li' abbia davvero i suoi fotogrammi in
 * animazioni.css.
 *
 * Come il generatore CSS e la libreria di icone, questa classe non usa
 * nessuna funzione di WordPress: si prova da sola.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Legge l'elenco delle animazioni di comparsa.
 */
final class Animazioni {

	/**
	 * Il contenuto del file, letto una volta sola.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $data = null;

	/**
	 * Tutti i tipi, con nome e gruppo.
	 *
	 * @return array<string, array<string, string>>
	 */
	public static function tipi(): array {
		$dati = self::load();

		return isset( $dati['tipi'] ) && is_array( $dati['tipi'] ) ? $dati['tipi'] : array();
	}

	/**
	 * I gruppi in cui sono divise, nell'ordine in cui vanno mostrati.
	 *
	 * @return array<string, string>
	 */
	public static function gruppi(): array {
		$dati = self::load();

		return isset( $dati['gruppi'] ) && is_array( $dati['gruppi'] ) ? $dati['gruppi'] : array();
	}

	/**
	 * Dice se un valore e' un tipo di animazione che conosciamo.
	 *
	 * Quello che arriva qui viene dal contenuto della pagina, cioe' da fuori:
	 * finisce dentro un attributo HTML e non si scrive mai come arriva.
	 *
	 * @param mixed $tipo Valore grezzo.
	 * @return bool Vero se si puo' scrivere in pagina.
	 */
	public static function valida( mixed $tipo ): bool {
		return is_string( $tipo ) && '' !== $tipo && isset( self::tipi()[ $tipo ] );
	}

	/**
	 * Legge il file, una volta sola per richiesta.
	 *
	 * @return array<string, mixed>
	 */
	private static function load(): array {
		if ( null !== self::$data ) {
			return self::$data;
		}

		self::$data = array();

		$file = dirname( __DIR__ ) . '/shared/animazioni.json';

		if ( ! is_readable( $file ) ) {
			return self::$data;
		}

		$letto = json_decode( (string) file_get_contents( $file ), true );

		if ( is_array( $letto ) ) {
			self::$data = $letto;
		}

		return self::$data;
	}
}
