<?php
/**
 * Dove finiscono i messaggi arrivati dai moduli.
 *
 * Non una tabella nostra, ma un **tipo di contenuto** di WordPress, non
 * pubblico. La scelta ha una ragione pratica: cosi' l'elenco, la ricerca, i
 * filtri, il cestino e soprattutto la **cancellazione** ci sono gia', scritti
 * e collaudati da WordPress. Con una tabella propria andrebbe costruita una
 * schermata di amministrazione da zero, e con dentro dati personali la parte
 * che conta non e' mostrarli: e' poterli cancellare senza sbagliare.
 *
 * Non pubblico vuol dire: nessun indirizzo sul sito, niente nelle ricerche,
 * niente nelle mappe. Si vede solo da dentro l'amministrazione.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Moduli;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Il tipo di contenuto degli invii, e la sua schermata.
 */
final class Invii {

	/**
	 * Il nome del tipo di contenuto.
	 *
	 * Finisce nel database di ogni sito: dal primo rilascio non si cambia.
	 */
	public const TIPO = 'emme_invio';

	/**
	 * I dati del messaggio: etichetta e valore di ogni campo.
	 */
	public const META_CAMPI = '_emme_campi';

	/**
	 * Quale modulo l'ha mandato.
	 */
	public const META_MODULO = '_emme_modulo';

	/**
	 * Da quale pagina.
	 */
	public const META_PAGINA = '_emme_pagina';

	/**
	 * Per quanti giorni si tiene. Zero vuol dire per sempre.
	 */
	public const META_GIORNI = '_emme_conservazione';

	/**
	 * L'indirizzo di posta di chi ha scritto, in una chiave sua.
	 *
	 * Sta a parte e non solo dentro ai dati perche' e' la chiave con cui si
	 * ritrovano i messaggi di una persona che chiede di vederli o di
	 * cancellarli. Cercarlo dentro al blocco di tutti i campi — con un LIKE —
	 * pescherebbe anche i messaggi di ALTRI in cui quell'indirizzo e' solo
	 * nominato nel testo: visti da chi non doveva, o peggio cancellati.
	 */
	public const META_EMAIL = '_emme_email';

	/**
	 * Chi puo' leggere i messaggi arrivati.
	 *
	 * **Non** `edit_posts`: quel permesso ce l'hanno anche Collaboratore e
	 * Autore, che su un sito di un cliente sono spesso persone che scrivono
	 * articoli e basta. I messaggi di un modulo di contatto sono dati di
	 * persone che hanno scritto, e li devono vedere solo Editore e
	 * Amministratore: il permesso che distingue i due gruppi e' questo.
	 */
	public const PERMESSO = 'edit_others_posts';

	/**
	 * Aggancia tutto.
	 */
	public static function init(): void {
		add_action( 'init', array( self::class, 'registra' ) );
		add_action( 'admin_menu', array( self::class, 'riquadro' ) );
		add_action( 'admin_post_emme_invii_csv', array( self::class, 'scarica_csv' ) );

		add_filter( 'manage_' . self::TIPO . '_posts_columns', array( self::class, 'colonne' ) );
		add_action( 'manage_' . self::TIPO . '_posts_custom_column', array( self::class, 'colonna' ), 10, 2 );
		add_filter( 'bulk_actions-edit-' . self::TIPO, array( self::class, 'azioni_in_blocco' ) );
		add_action( 'restrict_manage_posts', array( self::class, 'pulsante_csv' ) );
	}

	/**
	 * Dichiara il tipo di contenuto.
	 *
	 * `public => false` con `show_ui => true` e' la combinazione che serve:
	 * esiste solo in amministrazione. E `create_posts => do_not_allow` toglie
	 * il pulsante «Aggiungi nuovo», che qui non avrebbe senso: un invio lo
	 * scrive chi compila il modulo, non chi tiene il sito.
	 */
	public static function registra(): void {
		register_post_type(
			self::TIPO,
			array(
				'labels'              => array(
					'name'               => __( 'Form messages', 'emme-blocks' ),
					'singular_name'      => __( 'Message', 'emme-blocks' ),
					'menu_name'          => __( 'Form messages', 'emme-blocks' ),
					'search_items'       => __( 'Search messages', 'emme-blocks' ),
					'not_found'          => __( 'No messages yet.', 'emme-blocks' ),
					'not_found_in_trash' => __( 'No messages in the bin.', 'emme-blocks' ),
					'all_items'          => __( 'All messages', 'emme-blocks' ),
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_rest'        => false,
				'menu_icon'           => 'dashicons-email-alt',
				'menu_position'       => 26,
				'supports'            => array( 'title' ),
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'capability_type'     => 'post',
				// I permessi primitivi si usano come sono scritti qui, senza
				// la traduzione automatica: cosi' quello che serve per vedere
				// questa schermata e' scritto in un posto solo e si legge.
				'map_meta_cap'        => false,
				'capabilities'        => array(
					// Un invio non si scrive a mano: lo scrive chi compila il
					// modulo, e nessun altro.
					'create_posts'       => 'do_not_allow',
					'publish_posts'      => 'do_not_allow',
					'edit_post'          => self::PERMESSO,
					'read_post'          => self::PERMESSO,
					'delete_post'        => self::PERMESSO,
					'edit_posts'         => self::PERMESSO,
					'edit_others_posts'  => self::PERMESSO,
					'delete_posts'       => self::PERMESSO,
					'delete_others_posts' => self::PERMESSO,
					'read_private_posts' => self::PERMESSO,
				),
			)
		);

		// I dati non si scrivono da fuori: niente REST, nessun permesso di
		// scrittura. Li scrive solo Ricezione, dopo aver controllato tutto.
		foreach ( array( self::META_CAMPI, self::META_MODULO, self::META_PAGINA, self::META_GIORNI, self::META_EMAIL ) as $chiave ) {
			register_post_meta(
				self::TIPO,
				$chiave,
				array(
					'show_in_rest'  => false,
					'single'        => true,
					'auth_callback' => '__return_false',
				)
			);
		}
	}

	/**
	 * Scrive un invio nel database.
	 *
	 * @param array<int, array<string, string>> $campi      Etichetta e valore di ogni campo.
	 * @param string                            $titolo     Come si chiama nell'elenco.
	 * @param string                            $modulo_id  Identificativo del modulo.
	 * @param int                               $pagina     Pagina da cui e' arrivato.
	 * @param int                               $giorni     Per quanti giorni si tiene; 0 = per sempre.
	 * @param string                            $email      Indirizzo di chi ha scritto, se l'ha lasciato.
	 * @return int L'identificativo dell'invio, oppure 0 se non si e' potuto salvare.
	 */
	public static function salva( array $campi, string $titolo, string $modulo_id, int $pagina, int $giorni, string $email = '' ): int {
		$id = wp_insert_post(
			array(
				'post_type'   => self::TIPO,
				'post_status' => 'publish',
				'post_title'  => '' !== $titolo ? $titolo : __( 'Message', 'emme-blocks' ),
			),
			true
		);

		if ( is_wp_error( $id ) || 0 === (int) $id ) {
			return 0;
		}

		$id = (int) $id;

		update_post_meta( $id, self::META_CAMPI, $campi );
		update_post_meta( $id, self::META_MODULO, $modulo_id );
		update_post_meta( $id, self::META_PAGINA, $pagina );
		update_post_meta( $id, self::META_GIORNI, max( 0, $giorni ) );

		// Minuscolo: gli indirizzi si confrontano senza guardare le maiuscole,
		// e chi chiede di vedere i suoi messaggi puo' scriverlo in un altro
		// modo da come l'aveva scritto allora.
		update_post_meta( $id, self::META_EMAIL, strtolower( $email ) );

		return $id;
	}

	/**
	 * I dati di un invio.
	 *
	 * @param int $id Identificativo dell'invio.
	 * @return array<int, array<string, string>> Etichetta e valore di ogni campo.
	 */
	public static function dati( int $id ): array {
		$campi = get_post_meta( $id, self::META_CAMPI, true );

		return is_array( $campi ) ? $campi : array();
	}

	/**
	 * Le colonne dell'elenco.
	 *
	 * @param array<string, string> $colonne Quelle di WordPress.
	 * @return array<string, string> Le nostre.
	 */
	public static function colonne( array $colonne ): array {
		return array(
			'cb'          => $colonne['cb'] ?? '',
			'title'       => __( 'From', 'emme-blocks' ),
			'emme_estratto' => __( 'Message', 'emme-blocks' ),
			'emme_pagina' => __( 'Page', 'emme-blocks' ),
			'date'        => __( 'Received', 'emme-blocks' ),
		);
	}

	/**
	 * Il contenuto di una colonna nostra.
	 *
	 * @param string $colonna Nome della colonna.
	 * @param int    $id      Identificativo dell'invio.
	 */
	public static function colonna( string $colonna, int $id ): void {
		if ( 'emme_pagina' === $colonna ) {
			$pagina = (int) get_post_meta( $id, self::META_PAGINA, true );
			$titolo = $pagina > 0 ? get_the_title( $pagina ) : '';

			echo '' !== $titolo ? esc_html( $titolo ) : '—';

			return;
		}

		if ( 'emme_estratto' !== $colonna ) {
			return;
		}

		// Il primo campo lungo: e' quasi sempre il messaggio, ed e' quello che
		// si vuole leggere senza aprire.
		$pezzi = array();

		foreach ( self::dati( $id ) as $campo ) {
			$valore = (string) ( $campo['valore'] ?? '' );

			if ( '' !== $valore ) {
				$pezzi[] = $valore;
			}
		}

		$testo = implode( ' · ', $pezzi );

		echo esc_html( mb_strimwidth( $testo, 0, 120, '…' ) );
	}

	/**
	 * Toglie «Modifica» dalle azioni in blocco.
	 *
	 * Un invio non si modifica: e' il verbale di quello che una persona ha
	 * scritto. Si legge, si esporta, si cancella.
	 *
	 * @param array<string, string> $azioni Quelle di WordPress.
	 * @return array<string, string> Senza la modifica.
	 */
	public static function azioni_in_blocco( array $azioni ): array {
		unset( $azioni['edit'] );

		return $azioni;
	}

	/**
	 * Il riquadro che mostra il messaggio, e toglie l'editor.
	 */
	public static function riquadro(): void {
		add_meta_box(
			'emme-invio',
			__( 'What was written', 'emme-blocks' ),
			array( self::class, 'disegna_riquadro' ),
			self::TIPO,
			'normal',
			'high'
		);

		remove_meta_box( 'submitdiv', self::TIPO, 'side' );
	}

	/**
	 * Disegna il contenuto del messaggio, in sola lettura.
	 *
	 * @param \WP_Post $post L'invio.
	 */
	public static function disegna_riquadro( \WP_Post $post ): void {
		$campi = self::dati( $post->ID );

		if ( array() === $campi ) {
			echo '<p>' . esc_html__( 'This message has no content.', 'emme-blocks' ) . '</p>';

			return;
		}

		echo '<table class="widefat striped"><tbody>';

		foreach ( $campi as $campo ) {
			printf(
				'<tr><th scope="row" style="width:220px">%1$s</th><td>%2$s</td></tr>',
				esc_html( (string) ( $campo['etichetta'] ?? '' ) ),
				nl2br( esc_html( (string) ( $campo['valore'] ?? '' ) ) )
			);
		}

		echo '</tbody></table>';

		$pagina = (int) get_post_meta( $post->ID, self::META_PAGINA, true );

		if ( $pagina > 0 ) {
			printf(
				'<p><a href="%1$s">%2$s</a></p>',
				esc_url( (string) get_permalink( $pagina ) ),
				esc_html__( 'Open the page it was sent from', 'emme-blocks' )
			);
		}
	}

	/**
	 * Il pulsante che scarica tutto in un foglio di calcolo.
	 *
	 * E' la ragione per cui si installa CF7DB accanto a Contact Form 7: i
	 * messaggi servono anche fuori da WordPress.
	 *
	 * @param string $tipo Tipo di contenuto della schermata.
	 */
	public static function pulsante_csv( string $tipo ): void {
		if ( self::TIPO !== $tipo || ! current_user_can( self::PERMESSO ) ) {
			return;
		}

		$indirizzo = wp_nonce_url(
			admin_url( 'admin-post.php?action=emme_invii_csv' ),
			'emme_invii_csv'
		);

		printf(
			'<a href="%1$s" class="button">%2$s</a>',
			esc_url( $indirizzo ),
			esc_html__( 'Download as CSV', 'emme-blocks' )
		);
	}

	/**
	 * Scrive il file da scaricare.
	 *
	 * Separatore punto e virgola e marcatore iniziale UTF-8: e' la forma che
	 * i fogli di calcolo italiani aprono senza che nessuno debba scegliere
	 * niente in una finestra di importazione.
	 */
	public static function scarica_csv(): void {
		if ( ! current_user_can( self::PERMESSO ) ) {
			wp_die( esc_html__( 'You cannot download these messages.', 'emme-blocks' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( 'emme_invii_csv' );

		$invii = get_posts(
			array(
				'post_type'      => self::TIPO,
				'post_status'    => 'publish',
				'posts_per_page' => 5000,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'no_found_rows'  => true,
			)
		);

		// Le colonne: la data, poi tutte le etichette incontrate, nell'ordine
		// in cui compaiono. Moduli diversi hanno campi diversi, e una colonna
		// vuota e' meglio di una riga sfasata.
		$colonne = array( __( 'Received', 'emme-blocks' ) );

		foreach ( $invii as $invio ) {
			foreach ( self::dati( $invio->ID ) as $campo ) {
				$etichetta = (string) ( $campo['etichetta'] ?? '' );

				if ( '' !== $etichetta && ! in_array( $etichetta, $colonne, true ) ) {
					$colonne[] = $etichetta;
				}
			}
		}

		$righe = array( $colonne );

		foreach ( $invii as $invio ) {
			$riga = array_fill( 0, count( $colonne ), '' );
			$riga[0] = get_the_date( 'Y-m-d H:i', $invio );

			foreach ( self::dati( $invio->ID ) as $campo ) {
				$dove = array_search( (string) ( $campo['etichetta'] ?? '' ), $colonne, true );

				if ( false !== $dove ) {
					$riga[ $dove ] = (string) ( $campo['valore'] ?? '' );
				}
			}

			$righe[] = $riga;
		}

		$nome = 'messaggi-' . gmdate( 'Y-m-d' ) . '.csv';

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $nome . '"' );

		// Il marcatore iniziale: senza, Excel legge le lettere accentate male.
		echo "\xEF\xBB\xBF"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- tre byte fissi.

		$uscita = fopen( 'php://output', 'w' );

		if ( false !== $uscita ) {
			foreach ( $righe as $riga ) {
				fputcsv( $uscita, array_map( array( self::class, 'cella' ), $riga ), ';', '"', '\\' );
			}

			fclose( $uscita );
		}

		exit;
	}

	/**
	 * Disinnesca una cella che un foglio di calcolo prenderebbe per formula.
	 *
	 * Un valore che comincia per uguale, piu', meno o chiocciola viene
	 * eseguito da Excel all'apertura: e' il modo in cui un messaggio di un
	 * visitatore diventa un comando sul computer di chi lo legge.
	 *
	 * @param string $valore Il valore.
	 * @return string Il valore, preceduto da un apice se serve.
	 */
	private static function cella( string $valore ): string {
		return 1 === preg_match( '/^[=+\-@\t\r]/', $valore ) ? "'" . $valore : $valore;
	}
}
