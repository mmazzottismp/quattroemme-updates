<?php
/**
 * I dati delle persone che scrivono: quanto si tengono, e come si tolgono.
 *
 * Un modulo di contatto non e' una rubrica. Su un sito di uno studio medico o
 * di una psicologa, dentro ci finiscono persone che chiedono aiuto, e la cosa
 * piu' importante che si puo' fare di quei messaggi e' **non tenerli piu' del
 * necessario**.
 *
 * Qui ci sono tre cose:
 *
 * 1. La **cancellazione automatica** dopo un numero di giorni deciso nel
 *    pannello del modulo. Si fa una volta al giorno, e il numero di giorni
 *    e' scritto su ogni singolo messaggio: cambiare l'impostazione non
 *    riscrive il passato.
 * 2. L'aggancio agli strumenti che WordPress ha gia' per **esportare** i dati
 *    di una persona che li chiede.
 * 3. Lo stesso per **cancellarli**.
 *
 * Gli ultimi due sono quelli che il Garante chiama diritto di accesso e
 * diritto alla cancellazione: WordPress ha una schermata apposta, in
 * Strumenti, e funziona solo per chi ci si aggancia.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Moduli;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Conservazione e diritti delle persone.
 */
final class Privacy {

	/**
	 * Il nome dell'appuntamento quotidiano.
	 */
	public const PULIZIA = 'emme_pulizia_invii';

	/**
	 * Quanti messaggi si guardano a ogni giro.
	 */
	public const PER_GIRO = 200;

	/**
	 * Aggancia tutto.
	 */
	public static function init(): void {
		add_action( 'init', array( self::class, 'programma' ) );
		add_action( self::PULIZIA, array( self::class, 'pulisci' ) );

		add_filter( 'wp_privacy_personal_data_exporters', array( self::class, 'esportatore' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( self::class, 'cancellatore' ) );
	}

	/**
	 * Mette in calendario la pulizia, se non c'e' gia'.
	 */
	public static function programma(): void {
		if ( ! wp_next_scheduled( self::PULIZIA ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::PULIZIA );
		}
	}

	/**
	 * Toglie l'appuntamento. Si chiama quando il plugin viene disattivato.
	 */
	public static function ferma(): void {
		$quando = wp_next_scheduled( self::PULIZIA );

		if ( false !== $quando ) {
			wp_unschedule_event( $quando, self::PULIZIA );
		}
	}

	/**
	 * Cancella i messaggi piu' vecchi del tempo che era stato deciso.
	 *
	 * Si cancella davvero (`force_delete`), senza passare dal cestino: un
	 * messaggio «cancellato» che resta nel cestino non e' cancellato, e la
	 * persona che l'ha chiesto ha ragione lei.
	 *
	 * @return int Quanti ne sono stati cancellati.
	 */
	public static function pulisci(): int {
		$invii = get_posts(
			array(
				'post_type'      => Invii::TIPO,
				'post_status'    => 'any',
				'posts_per_page' => self::PER_GIRO,
				'orderby'        => 'date',
				'order'          => 'ASC',
				'no_found_rows'  => true,
				'fields'         => 'ids',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- gira una volta al giorno, non a ogni visita.
					array(
						'key'     => Invii::META_GIORNI,
						'value'   => 0,
						'compare' => '>',
						'type'    => 'NUMERIC',
					),
				),
			)
		);

		$tolti = 0;
		$adesso = time();

		foreach ( $invii as $id ) {
			$id     = (int) $id;
			$giorni = (int) get_post_meta( $id, Invii::META_GIORNI, true );

			if ( $giorni <= 0 ) {
				continue;
			}

			$nato = (int) get_post_time( 'U', true, $id );

			if ( 0 === $nato || ( $adesso - $nato ) < ( $giorni * DAY_IN_SECONDS ) ) {
				continue;
			}

			wp_delete_post( $id, true );
			++$tolti;
		}

		return $tolti;
	}

	/**
	 * Dichiara a WordPress come si esportano i nostri dati.
	 *
	 * @param array<string, array<string, mixed>> $esportatori Quelli gia' dichiarati.
	 * @return array<string, array<string, mixed>> Con il nostro in piu'.
	 */
	public static function esportatore( array $esportatori ): array {
		$esportatori['emme-blocks-moduli'] = array(
			'exporter_friendly_name' => __( 'quattroemme form messages', 'emme-blocks' ),
			'callback'               => array( self::class, 'esporta' ),
		);

		return $esportatori;
	}

	/**
	 * Dichiara a WordPress come si cancellano i nostri dati.
	 *
	 * @param array<string, array<string, mixed>> $cancellatori Quelli gia' dichiarati.
	 * @return array<string, array<string, mixed>> Con il nostro in piu'.
	 */
	public static function cancellatore( array $cancellatori ): array {
		$cancellatori['emme-blocks-moduli'] = array(
			'eraser_friendly_name' => __( 'quattroemme form messages', 'emme-blocks' ),
			'callback'             => array( self::class, 'cancella' ),
		);

		return $cancellatori;
	}

	/**
	 * Raccoglie i messaggi di una persona, per darglieli.
	 *
	 * @param string $email  Indirizzo di posta della persona.
	 * @param int    $pagina Numero della pagina di risultati, da 1.
	 * @return array{data: array<int, array<string, mixed>>, done: bool} Quello che WordPress si aspetta.
	 */
	public static function esporta( string $email, int $pagina = 1 ): array {
		$invii = self::suoi( $email, $pagina );
		$fuori = array();

		foreach ( $invii as $invio ) {
			$dati = array();

			foreach ( Invii::dati( $invio->ID ) as $campo ) {
				$dati[] = array(
					'name'  => (string) ( $campo['etichetta'] ?? '' ),
					'value' => (string) ( $campo['valore'] ?? '' ),
				);
			}

			$dati[] = array(
				'name'  => __( 'Received', 'emme-blocks' ),
				'value' => get_the_date( 'c', $invio ),
			);

			$fuori[] = array(
				'group_id'    => 'emme-moduli',
				'group_label' => __( 'Messages sent through the website forms', 'emme-blocks' ),
				'item_id'     => 'emme-invio-' . $invio->ID,
				'data'        => $dati,
			);
		}

		return array(
			'data' => $fuori,
			'done' => count( $invii ) < self::PER_GIRO,
		);
	}

	/**
	 * Cancella i messaggi di una persona.
	 *
	 * @param string $email  Indirizzo di posta della persona.
	 * @param int    $pagina Numero della pagina di risultati, da 1.
	 * @return array{items_removed: bool, items_retained: bool, messages: string[], done: bool} Quello che WordPress si aspetta.
	 */
	public static function cancella( string $email, int $pagina = 1 ): array {
		// Si chiede sempre la prima pagina: cancellando, i risultati scalano.
		$invii = self::suoi( $email, 1 );
		$tolti = false;

		foreach ( $invii as $invio ) {
			wp_delete_post( $invio->ID, true );
			$tolti = true;
		}

		return array(
			'items_removed'  => $tolti,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => count( $invii ) < self::PER_GIRO,
		);
	}

	/**
	 * I messaggi di una certa persona.
	 *
	 * **Si cerca l'indirizzo esatto**, nella chiave in cui e' scritto da solo.
	 * La prima versione cercava con un LIKE dentro al blocco di tutti i campi,
	 * ed era sbagliata in un modo che si vede solo pensandoci: un messaggio di
	 * un'ALTRA persona che nel testo nomina quell'indirizzo - «scrivete anche
	 * a mario@example.com» - veniva pescato lo stesso. Esportato a chi non
	 * doveva riceverlo, e su una richiesta di cancellazione **cancellato**.
	 *
	 * Resta anche un filtro sul risultato: una ricerca per meta e' comunque
	 * una ricerca, e un giorno qualcuno potrebbe riscriverla.
	 *
	 * @param string $email  L'indirizzo.
	 * @param int    $pagina Numero della pagina, da 1.
	 * @return \WP_Post[] I messaggi.
	 */
	private static function suoi( string $email, int $pagina ): array {
		$email = sanitize_email( $email );

		if ( '' === $email || ! is_email( $email ) ) {
			return array();
		}

		$email = strtolower( $email );

		$trovati = get_posts(
			array(
				'post_type'      => Invii::TIPO,
				'post_status'    => 'any',
				'posts_per_page' => self::PER_GIRO,
				'paged'          => max( 1, $pagina ),
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- gira solo dalla schermata degli strumenti.
					array(
						'key'     => Invii::META_EMAIL,
						'value'   => $email,
						'compare' => '=',
					),
				),
			)
		);

		return array_values(
			array_filter(
				$trovati,
				static fn( $post ) => $email === strtolower( (string) get_post_meta( $post->ID, Invii::META_EMAIL, true ) )
			)
		);
	}
}
