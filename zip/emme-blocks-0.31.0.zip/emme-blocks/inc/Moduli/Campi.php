<?php
/**
 * I tipi di campo di un modulo: l'elenco, i controlli e il disegno.
 *
 * Come la libreria di icone e l'elenco delle animazioni, la fonte e' un file
 * JSON solo — shared/campi.json — letto sia da qui sia dall'editor. Un tipo
 * che esiste nel menu ma non qui produrrebbe un campo che il sito rifiuta
 * senza dire niente.
 *
 * Questa classe fa tre lavori, e conviene tenerli distinti:
 *
 * 1. **Pulire** quello che arriva dal visitatore (`pulisci`): togliere tag,
 *    tagliare la lunghezza, scartare quello che non e' fra le opzioni.
 * 2. **Controllare** se il valore ripulito va bene (`controlla`): obbligatorio
 *    ma vuoto, indirizzo di posta che non e' un indirizzo di posta.
 * 3. **Disegnare** il campo in pagina (`html`).
 *
 * Primo e secondo sono due cose diverse: si pulisce sempre, anche quello che
 * poi si scarta, perche' il valore ripulito torna in pagina dentro il modulo
 * ricompilato.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Moduli;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * I tipi di campo, con i loro controlli e il loro disegno.
 */
final class Campi {

	/**
	 * Quanto puo' essere lungo un valore di una riga sola.
	 */
	public const LUNGHEZZA_RIGA = 200;

	/**
	 * Quanto puo' essere lungo un messaggio.
	 *
	 * Diecimila caratteri sono quattro pagine fitte: oltre non e' piu' un
	 * messaggio, e un limite serve perche' quello che arriva finisce nel
	 * database.
	 */
	public const LUNGHEZZA_TESTO = 10000;

	/**
	 * Il contenuto del file, letto una volta sola.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $data = null;

	/**
	 * Tutti i tipi, con il loro comportamento.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function tipi(): array {
		$dati = self::load();

		return isset( $dati['tipi'] ) && is_array( $dati['tipi'] ) ? $dati['tipi'] : array();
	}

	/**
	 * I gruppi in cui sono divisi, nell'ordine in cui vanno mostrati.
	 *
	 * @return array<string, string>
	 */
	public static function gruppi(): array {
		$dati = self::load();

		return isset( $dati['gruppi'] ) && is_array( $dati['gruppi'] ) ? $dati['gruppi'] : array();
	}

	/**
	 * Dice se un valore e' un tipo di campo che conosciamo.
	 *
	 * @param mixed $tipo Valore grezzo, che arriva dal contenuto della pagina.
	 * @return bool Vero se si puo' usare.
	 */
	public static function valida( mixed $tipo ): bool {
		return is_string( $tipo ) && '' !== $tipo && isset( self::tipi()[ $tipo ] );
	}

	/**
	 * La descrizione di un tipo, oppure quella del tipo «testo».
	 *
	 * @param string $tipo Nome del tipo.
	 * @return array<string, mixed> Come si comporta.
	 */
	public static function tipo( string $tipo ): array {
		$tipi = self::tipi();

		if ( isset( $tipi[ $tipo ] ) ) {
			return $tipi[ $tipo ];
		}

		return $tipi['testo'] ?? array(
			'elemento' => 'input',
			'html'     => 'text',
			'opzioni'  => false,
			'controllo' => 'testo',
		);
	}

	/**
	 * Dice se un tipo porta un elenco di opzioni.
	 *
	 * @param string $tipo Nome del tipo.
	 * @return bool Vero per tendina, scelta singola e caselle.
	 */
	public static function ha_opzioni( string $tipo ): bool {
		return ! empty( self::tipo( $tipo )['opzioni'] );
	}

	/**
	 * Dice se un tipo puo' tenere piu' di un valore.
	 *
	 * @param string $tipo Nome del tipo.
	 * @return bool Vero solo per le caselle.
	 */
	public static function multiplo( string $tipo ): bool {
		return 'piuOpzioni' === ( self::tipo( $tipo )['controllo'] ?? '' );
	}

	/**
	 * I valori ammessi per «cosa chiede questo campo».
	 *
	 * Sono i nomi che lo standard HTML da' ai dati di una persona. Dichiararli
	 * fa si' che il browser offra da solo quello che ha gia' memorizzato.
	 *
	 * @return string[] L'elenco.
	 */
	public static function autocompletamenti(): array {
		$dati = self::load();

		return isset( $dati['autocompletamento'] ) && is_array( $dati['autocompletamento'] )
			? array_values( array_filter( $dati['autocompletamento'], 'is_string' ) )
			: array();
	}

	/**
	 * Dice se un valore e' un «cosa chiede» che conosciamo.
	 *
	 * @param mixed $valore Valore grezzo.
	 * @return bool Vero se si puo' scrivere in pagina.
	 */
	public static function autocompletamento_valido( mixed $valore ): bool {
		return is_string( $valore ) && in_array( $valore, self::autocompletamenti(), true );
	}

	/**
	 * Ripulisce quello che ha scritto il visitatore.
	 *
	 * Si pulisce **sempre**, anche quello che poi verra' scartato: il valore
	 * ripulito torna in pagina dentro il modulo ricompilato, e li' dev'essere
	 * innocuo.
	 *
	 * @param array<string, mixed> $campo  La descrizione del campo.
	 * @param mixed                $grezzo Quello che e' arrivato.
	 * @return string|string[] Il valore ripulito: un elenco solo per le caselle.
	 */
	public static function pulisci( array $campo, mixed $grezzo ): string|array {
		$tipo = (string) ( $campo['tipo'] ?? 'testo' );

		if ( self::multiplo( $tipo ) ) {
			if ( ! is_array( $grezzo ) ) {
				return array();
			}

			$ammesse = self::opzioni( $campo );
			$scelte  = array();

			foreach ( $grezzo as $voce ) {
				$voce = self::riga( $voce );

				if ( in_array( $voce, $ammesse, true ) && ! in_array( $voce, $scelte, true ) ) {
					$scelte[] = $voce;
				}
			}

			return $scelte;
		}

		if ( is_array( $grezzo ) ) {
			return '';
		}

		$controllo = (string) ( self::tipo( $tipo )['controllo'] ?? 'testo' );

		if ( 'testoLungo' === $controllo ) {
			// I capoversi si tengono, i tag no. La lunghezza si taglia qui:
			// quello che arriva finisce nel database.
			$testo = sanitize_textarea_field( (string) $grezzo );

			return self::taglia( $testo, self::LUNGHEZZA_TESTO );
		}

		if ( 'unaOpzione' === $controllo ) {
			$voce = self::riga( $grezzo );

			return in_array( $voce, self::opzioni( $campo ), true ) ? $voce : '';
		}

		if ( 'spunta' === $controllo ) {
			return '' !== (string) $grezzo ? '1' : '';
		}

		return self::riga( $grezzo );
	}

	/**
	 * Controlla un valore gia' ripulito.
	 *
	 * @param array<string, mixed> $campo  La descrizione del campo.
	 * @param string|string[]      $valore Il valore ripulito.
	 * @return string Il messaggio di errore, oppure la stringa vuota se va bene.
	 */
	public static function controlla( array $campo, string|array $valore ): string {
		$tipo         = (string) ( $campo['tipo'] ?? 'testo' );
		$obbligatorio = ! empty( $campo['obbligatorio'] );
		$vuoto        = is_array( $valore ) ? array() === $valore : '' === trim( $valore );

		if ( $vuoto ) {
			if ( ! $obbligatorio ) {
				return '';
			}

			if ( 'spunta' === ( self::tipo( $tipo )['controllo'] ?? '' ) ) {
				return __( 'You have to tick this box to go on.', 'emme-blocks' );
			}

			return __( 'This field is required.', 'emme-blocks' );
		}

		if ( is_array( $valore ) ) {
			return '';
		}

		$controllo = (string) ( self::tipo( $tipo )['controllo'] ?? 'testo' );

		if ( 'email' === $controllo && ! is_email( $valore ) ) {
			return __( 'This does not look like an email address.', 'emme-blocks' );
		}

		if ( 'telefono' === $controllo && 1 !== preg_match( '/^[0-9+().\/ -]{5,30}$/', $valore ) ) {
			// Larghi di proposito: i numeri si scrivono in dieci modi diversi,
			// e un controllo severo rifiuta numeri veri.
			return __( 'This does not look like a phone number.', 'emme-blocks' );
		}

		if ( 'numero' === $controllo && ! is_numeric( $valore ) ) {
			return __( 'Only numbers here.', 'emme-blocks' );
		}

		if ( 'url' === $controllo && '' === esc_url_raw( $valore ) ) {
			return __( 'This does not look like a web address.', 'emme-blocks' );
		}

		if ( 'data' === $controllo && 1 !== preg_match( '/^\d{4}-\d{2}-\d{2}$/', $valore ) ) {
			return __( 'This is not a valid date.', 'emme-blocks' );
		}

		return '';
	}

	/**
	 * Le opzioni di un campo, una per riga nel pannello.
	 *
	 * @param array<string, mixed> $campo La descrizione del campo.
	 * @return string[] Le opzioni, senza righe vuote e senza doppioni.
	 */
	public static function opzioni( array $campo ): array {
		$grezze = $campo['opzioni'] ?? array();

		if ( is_string( $grezze ) ) {
			$grezze = preg_split( '/\r\n|\r|\n/', $grezze ) ?: array();
		}

		if ( ! is_array( $grezze ) ) {
			return array();
		}

		$fuori = array();

		foreach ( $grezze as $voce ) {
			$voce = self::riga( $voce );

			if ( '' !== $voce && ! in_array( $voce, $fuori, true ) ) {
				$fuori[] = $voce;
			}
		}

		return $fuori;
	}

	/**
	 * Il nome con cui un campo finisce nel database e nella posta.
	 *
	 * Se il pannello non ne ha uno, lo si ricava dall'etichetta: cosi' un
	 * modulo scritto a mano nel markup funziona lo stesso. Resta pero' meglio
	 * scriverlo, perche' cambiando l'etichetta cambierebbe anche la colonna.
	 *
	 * @param array<string, mixed> $campo  La descrizione del campo.
	 * @param int                  $numero Posizione nel modulo, per l'ultimo ripiego.
	 * @return string Il nome, fatto di lettere minuscole, cifre e trattini bassi.
	 */
	public static function nome( array $campo, int $numero = 0 ): string {
		$nome = self::chiave( (string) ( $campo['nome'] ?? '' ) );

		if ( '' === $nome ) {
			$nome = self::chiave( (string) ( $campo['etichetta'] ?? '' ) );
		}

		if ( '' === $nome ) {
			$nome = 'campo_' . max( 1, $numero );
		}

		return $nome;
	}

	/**
	 * Riduce un testo a una chiave: minuscole, cifre e trattini bassi.
	 *
	 * @param string $testo Testo di partenza.
	 * @return string La chiave, al massimo 40 caratteri.
	 */
	public static function chiave( string $testo ): string {
		$testo = remove_accents( $testo );
		$testo = strtolower( $testo );
		$testo = (string) preg_replace( '/[^a-z0-9]+/', '_', $testo );
		$testo = trim( $testo, '_' );

		return substr( $testo, 0, 40 );
	}

	/**
	 * Disegna un campo in pagina.
	 *
	 * @param array<string, mixed> $campo   La descrizione del campo.
	 * @param string               $nome    Il nome con cui viaggia.
	 * @param string|string[]      $valore  Quello che c'e' gia' scritto dentro.
	 * @param string               $errore  Il messaggio di errore, se c'e'.
	 * @param string               $prefisso Prefisso degli identificativi HTML, per non ripeterli.
	 * @return string Il pezzo di pagina.
	 */
	public static function html( array $campo, string $nome, string|array $valore, string $errore, string $prefisso ): string {
		$tipo      = (string) ( $campo['tipo'] ?? 'testo' );
		$forma     = self::tipo( $tipo );
		$elemento  = (string) ( $forma['elemento'] ?? 'input' );
		$id        = $prefisso . '-' . $nome;
		$id_errore = $id . '-errore';
		$id_aiuto  = $id . '-aiuto';

		$etichetta    = (string) ( $campo['etichetta'] ?? '' );
		$descrizione  = (string) ( $campo['descrizione'] ?? '' );
		$obbligatorio = ! empty( $campo['obbligatorio'] );

		// Quello che il campo dichiara a chi non vede: il testo dell'errore e
		// la spiegazione, collegati con aria-describedby. Senza quel legame un
		// lettore di schermo legge il campo e non dice perche' e' sbagliato.
		$descritto = array();

		if ( '' !== $errore ) {
			$descritto[] = $id_errore;
		}

		if ( '' !== $descrizione ) {
			$descritto[] = $id_aiuto;
		}

		$comuni = array(
			'id'   => $id,
			'name' => self::multiplo( $tipo ) ? 'emme[' . $nome . '][]' : 'emme[' . $nome . ']',
		);

		if ( $obbligatorio ) {
			$comuni['required'] = 'required';
		}

		if ( '' !== $errore ) {
			$comuni['aria-invalid'] = 'true';
		}

		if ( array() !== $descritto ) {
			$comuni['aria-describedby'] = implode( ' ', $descritto );
		}

		$auto = (string) ( $campo['autocompletamento'] ?? '' );

		if ( self::autocompletamento_valido( $auto ) ) {
			$comuni['autocomplete'] = $auto;
		}

		$segnaposto = (string) ( $campo['segnaposto'] ?? '' );

		// --- il comando vero e proprio -------------------------------------
		$dentro = match ( $elemento ) {
			'textarea' => self::html_textarea( $comuni, $segnaposto, is_array( $valore ) ? '' : $valore, self::righe( $campo ) ),
			'select'   => self::html_select( $comuni, $segnaposto, self::opzioni( $campo ), is_array( $valore ) ? '' : $valore ),
			'radio'    => self::html_gruppo( $comuni, self::opzioni( $campo ), $valore, 'radio', $id ),
			'checkbox' => self::html_gruppo( $comuni, self::opzioni( $campo ), $valore, 'checkbox', $id ),
			'consenso' => self::html_consenso( $comuni, $campo, is_array( $valore ) ? '' : $valore ),
			default    => self::html_input( $comuni, (string) ( $forma['html'] ?? 'text' ), $segnaposto, is_array( $valore ) ? '' : $valore ),
		};

		// --- l'etichetta ----------------------------------------------------
		// Un gruppo di scelte non ha un comando solo a cui legarsi: li' si usa
		// un fieldset con la sua legend, che e' la forma giusta e quella che i
		// lettori di schermo annunciano come «gruppo di N scelte».
		$gruppo  = in_array( $elemento, array( 'radio', 'checkbox' ), true );
		$stella  = $obbligatorio ? '<span class="emme-campo__stella" aria-hidden="true">*</span>' : '';
		$visibile = '' !== $etichetta ? esc_html( $etichetta ) . $stella : '';

		$testa = '';

		if ( '' !== $visibile ) {
			$testa = $gruppo
				? '<legend class="emme-campo__etichetta">' . $visibile . '</legend>'
				: '<label class="emme-campo__etichetta" for="' . esc_attr( $id ) . '">' . $visibile . '</label>';
		}

		$aiuto = '' !== $descrizione
			? '<p class="emme-campo__aiuto" id="' . esc_attr( $id_aiuto ) . '">' . esc_html( $descrizione ) . '</p>'
			: '';

		// role="alert" fa leggere l'errore appena compare, senza che chi
		// ascolta debba andarselo a cercare.
		$avviso = '' !== $errore
			? '<p class="emme-campo__errore" id="' . esc_attr( $id_errore ) . '" role="alert">' . esc_html( $errore ) . '</p>'
			: '';

		// Il consenso porta la sua etichetta accanto alla casella: qui sopra
		// non si ripete.
		if ( 'consenso' === $elemento ) {
			$testa = '';
		}

		$corpo = $testa . $aiuto . $dentro . $avviso;

		return $gruppo
			? '<fieldset class="emme-campo__gruppo">' . $corpo . '</fieldset>'
			: $corpo;
	}

	/**
	 * Un comando di una riga sola.
	 *
	 * @param array<string, string> $comuni     Attributi comuni.
	 * @param string                $html       Tipo HTML (text, email, tel...).
	 * @param string                $segnaposto Testo grigio dentro al campo.
	 * @param string                $valore     Valore gia' scritto.
	 * @return string Il pezzo di pagina.
	 */
	private static function html_input( array $comuni, string $html, string $segnaposto, string $valore ): string {
		$comuni['type']      = $html;
		$comuni['value']     = $valore;
		$comuni['class']     = 'emme-campo__comando';
		$comuni['maxlength'] = (string) self::LUNGHEZZA_RIGA;

		if ( '' !== $segnaposto ) {
			$comuni['placeholder'] = $segnaposto;
		}

		if ( 'number' === $html ) {
			unset( $comuni['maxlength'] );
		}

		return '<input ' . self::attributi( $comuni ) . ' />';
	}

	/**
	 * Un messaggio su piu' righe.
	 *
	 * @param array<string, string> $comuni     Attributi comuni.
	 * @param string                $segnaposto Testo grigio dentro al campo.
	 * @param string                $valore     Valore gia' scritto.
	 * @param int                   $righe      Quante righe e' alto.
	 * @return string Il pezzo di pagina.
	 */
	private static function html_textarea( array $comuni, string $segnaposto, string $valore, int $righe ): string {
		$comuni['class']     = 'emme-campo__comando emme-campo__comando--testo';
		$comuni['rows']      = (string) $righe;
		$comuni['maxlength'] = (string) self::LUNGHEZZA_TESTO;

		if ( '' !== $segnaposto ) {
			$comuni['placeholder'] = $segnaposto;
		}

		return '<textarea ' . self::attributi( $comuni ) . '>' . esc_textarea( $valore ) . '</textarea>';
	}

	/**
	 * Un elenco a tendina.
	 *
	 * @param array<string, string> $comuni     Attributi comuni.
	 * @param string                $segnaposto Prima voce, quella che non sceglie niente.
	 * @param string[]              $opzioni    Le voci.
	 * @param string                $valore     Voce gia' scelta.
	 * @return string Il pezzo di pagina.
	 */
	private static function html_select( array $comuni, string $segnaposto, array $opzioni, string $valore ): string {
		$comuni['class'] = 'emme-campo__comando emme-campo__comando--tendina';

		$voci = '<option value="">' . esc_html( '' !== $segnaposto ? $segnaposto : __( 'Choose…', 'emme-blocks' ) ) . '</option>';

		foreach ( $opzioni as $voce ) {
			$voci .= '<option value="' . esc_attr( $voce ) . '"' . selected( $voce, $valore, false ) . '>' . esc_html( $voce ) . '</option>';
		}

		return '<select ' . self::attributi( $comuni ) . '>' . $voci . '</select>';
	}

	/**
	 * Un gruppo di scelte: pallini oppure caselle.
	 *
	 * @param array<string, string> $comuni  Attributi comuni.
	 * @param string[]              $opzioni Le voci.
	 * @param string|string[]       $valore  Voce o voci gia' scelte.
	 * @param string                $html    radio oppure checkbox.
	 * @param string                $id      Identificativo di partenza.
	 * @return string Il pezzo di pagina.
	 */
	private static function html_gruppo( array $comuni, array $opzioni, string|array $valore, string $html, string $id ): string {
		$scelte = is_array( $valore ) ? $valore : array( $valore );
		$fuori  = '';
		$numero = 0;

		// L'identificativo sta su ogni singola scelta, non sul gruppo: deve
		// essere diverso per ognuna, se no l'etichetta punta sempre alla prima.
		unset( $comuni['id'] );

		foreach ( $opzioni as $voce ) {
			++$numero;
			$suo = $id . '-' . $numero;

			$attr          = $comuni;
			$attr['id']    = $suo;
			$attr['type']  = $html;
			$attr['value'] = $voce;
			$attr['class'] = 'emme-campo__scelta';

			// «Obbligatorio» su una casella di un gruppo vorrebbe dire «questa
			// qui», che non e' quello che si intende: il controllo lo fa il
			// server, che sa guardare il gruppo intero.
			if ( 'checkbox' === $html ) {
				unset( $attr['required'] );
			}

			if ( in_array( $voce, $scelte, true ) ) {
				$attr['checked'] = 'checked';
			}

			$fuori .= '<label class="emme-campo__voce" for="' . esc_attr( $suo ) . '">'
				. '<input ' . self::attributi( $attr ) . ' />'
				. '<span>' . esc_html( $voce ) . '</span>'
				. '</label>';
		}

		return '<div class="emme-campo__scelte">' . $fuori . '</div>';
	}

	/**
	 * La spunta del consenso, con il suo testo accanto.
	 *
	 * E' l'unico campo in cui l'etichetta puo' contenere un collegamento —
	 * quello all'informativa — quindi passa da wp_kses invece che da esc_html.
	 *
	 * @param array<string, string> $comuni Attributi comuni.
	 * @param array<string, mixed>  $campo  La descrizione del campo.
	 * @param string                $valore Valore gia' scelto.
	 * @return string Il pezzo di pagina.
	 */
	private static function html_consenso( array $comuni, array $campo, string $valore ): string {
		$comuni['type']  = 'checkbox';
		$comuni['value'] = '1';
		$comuni['class'] = 'emme-campo__scelta';

		if ( '' !== $valore ) {
			$comuni['checked'] = 'checked';
		}

		$testo = (string) ( $campo['etichetta'] ?? '' );
		$lecito = array(
			'a'      => array(
				'href'   => array(),
				'target' => array(),
				'rel'    => array(),
			),
			'strong' => array(),
			'em'     => array(),
		);

		$stella = ! empty( $campo['obbligatorio'] )
			? '<span class="emme-campo__stella" aria-hidden="true">*</span>'
			: '';

		return '<label class="emme-campo__voce emme-campo__voce--consenso" for="' . esc_attr( $comuni['id'] ) . '">'
			. '<input ' . self::attributi( $comuni ) . ' />'
			. '<span>' . wp_kses( $testo, $lecito ) . $stella . '</span>'
			. '</label>';
	}

	/**
	 * Quante righe e' alto un messaggio.
	 *
	 * Fra due e trenta: una riga sola non e' un messaggio, e trenta righe
	 * sono gia' piu' di uno schermo.
	 *
	 * @param array<string, mixed> $campo La descrizione del campo.
	 * @return int Il numero di righe.
	 */
	public static function righe( array $campo ): int {
		$righe = isset( $campo['righe'] ) && is_numeric( $campo['righe'] ) ? (int) $campo['righe'] : 6;

		return max( 2, min( 30, $righe ) );
	}

	/**
	 * Scrive una serie di attributi HTML, tutti filtrati.
	 *
	 * @param array<string, string> $attributi Nome => valore.
	 * @return string Gli attributi pronti.
	 */
	private static function attributi( array $attributi ): string {
		$fuori = array();

		foreach ( $attributi as $nome => $valore ) {
			$fuori[] = esc_attr( $nome ) . '="' . esc_attr( $valore ) . '"';
		}

		return implode( ' ', $fuori );
	}

	/**
	 * Riduce un valore a una riga di testo pulita.
	 *
	 * @param mixed $grezzo Quello che e' arrivato.
	 * @return string Il testo, tagliato alla lunghezza massima.
	 */
	private static function riga( mixed $grezzo ): string {
		if ( is_array( $grezzo ) || is_object( $grezzo ) ) {
			return '';
		}

		return self::taglia( sanitize_text_field( (string) $grezzo ), self::LUNGHEZZA_RIGA );
	}

	/**
	 * Taglia un testo, contando i caratteri e non i byte.
	 *
	 * @param string $testo   Il testo.
	 * @param int    $massimo Quanti caratteri al massimo.
	 * @return string Il testo tagliato.
	 */
	private static function taglia( string $testo, int $massimo ): string {
		return function_exists( 'mb_substr' ) ? mb_substr( $testo, 0, $massimo ) : substr( $testo, 0, $massimo );
	}

	/**
	 * Legge il file, una volta sola per richiesta.
	 *
	 * @return array<string, mixed>
	 */
	private static function load(): array {
		if ( null !== self::$data ) {
			return self::$data;
		}

		self::$data = array();

		// Da inc/Moduli/ alla radice del plugin ci sono due salti.
		$file = dirname( __DIR__, 2 ) . '/shared/campi.json';

		if ( ! is_readable( $file ) ) {
			return self::$data;
		}

		$letto = json_decode( (string) file_get_contents( $file ), true );

		if ( is_array( $letto ) ) {
			self::$data = $letto;
		}

		return self::$data;
	}
}
