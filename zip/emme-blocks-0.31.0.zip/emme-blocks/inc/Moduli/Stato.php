<?php
/**
 * Il collegamento fra un campo disegnato in pagina e lo stesso campo
 * controllato quando l'invio arriva.
 *
 * Il problema che risolve e' piccolo ma vero. Il nome con cui un campo
 * viaggia — la «chiave» — dipende anche dai suoi fratelli: due campi che si
 * chiamerebbero uguale diventano `email` ed `email_2`, altrimenti il secondo
 * cancellerebbe il primo in silenzio. Ma `render.php` di un campo i fratelli
 * non li vede: sa solo di se'.
 *
 * Quindi la chiave la decide **una volta sola**, per tutto il modulo, la
 * stessa funzione che la decide quando l'invio arriva (`Struttura`). Qui si
 * tiene il risultato per il tempo di una visita.
 *
 * Se il modulo non si ritrova nel contenuto — succede nell'anteprima
 * dell'editor, o in un pattern non ancora salvato — si ripiega su un conteggio
 * nell'ordine in cui i campi si disegnano, che e' lo stesso ordine in cui si
 * leggono.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Moduli;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Le chiavi dei campi di un modulo, per il tempo di una visita.
 */
final class Stato {

	/**
	 * Le mappe gia' costruite: identificativo del modulo => mappa.
	 *
	 * @var array<string, array<string, string>>
	 */
	private static array $mappe = array();

	/**
	 * Quanti campi si sono gia' disegnati, modulo per modulo.
	 *
	 * @var array<string, int>
	 */
	private static array $contatori = array();

	/**
	 * La chiave di un campo dentro un modulo.
	 *
	 * @param string               $modulo_id Identificativo del modulo.
	 * @param array<string, mixed> $campo     Gli attributi del campo.
	 * @return string La chiave.
	 */
	public static function chiave( string $modulo_id, array $campo ): string {
		$suo = (string) ( $campo['emmeId'] ?? '' );
		$mappa = self::mappa( $modulo_id );

		if ( '' !== $suo && isset( $mappa[ $suo ] ) ) {
			return $mappa[ $suo ];
		}

		// Ripiego: il nome ricavato dal campo, piu' il conteggio per i casi
		// in cui non c'e' nemmeno quello.
		$numero = ( self::$contatori[ $modulo_id ] ?? 0 ) + 1;

		self::$contatori[ $modulo_id ] = $numero;

		return Campi::nome( $campo, $numero );
	}

	/**
	 * Dimentica tutto. Serve alle prove.
	 */
	public static function azzera(): void {
		self::$mappe     = array();
		self::$contatori = array();
	}

	/**
	 * La mappa identificativo del campo => chiave, costruita una volta sola.
	 *
	 * @param string $modulo_id Identificativo del modulo.
	 * @return array<string, string> La mappa, eventualmente vuota.
	 */
	private static function mappa( string $modulo_id ): array {
		if ( isset( self::$mappe[ $modulo_id ] ) ) {
			return self::$mappe[ $modulo_id ];
		}

		self::$mappe[ $modulo_id ] = array();

		// `false`: qui si sta solo DISEGNANDO. E' l'unico punto in cui una
		// bozza si legge, e solo a chi la puo' modificare: serve all'anteprima
		// di chi sta scrivendo la pagina. Da qui non parte nessuna posta.
		$struttura = Struttura::trova( $modulo_id, self::pagina(), false );

		if ( null === $struttura ) {
			return self::$mappe[ $modulo_id ];
		}

		foreach ( $struttura['campi'] as $campo ) {
			$suo = (string) ( $campo['emmeId'] ?? '' );

			if ( '' !== $suo ) {
				self::$mappe[ $modulo_id ][ $suo ] = (string) ( $campo['chiave'] ?? '' );
			}
		}

		return self::$mappe[ $modulo_id ];
	}

	/**
	 * La pagina che si sta guardando.
	 *
	 * @return int L'identificativo, oppure zero.
	 */
	public static function pagina(): int {
		$id = get_the_ID();

		if ( is_int( $id ) && $id > 0 ) {
			return $id;
		}

		return (int) get_queried_object_id();
	}
}
