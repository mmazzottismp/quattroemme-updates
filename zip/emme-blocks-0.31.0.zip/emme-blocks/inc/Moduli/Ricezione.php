<?php
/**
 * Quello che succede quando qualcuno preme «Invia».
 *
 * Il modulo e' un modulo HTML vero, che manda i dati alla stessa pagina:
 * **funziona senza JavaScript**. E' la stessa scelta fatta per la scheda a
 * due facce e per il carosello, e qui pesa di piu', perche' un modulo di
 * contatto che non parte e' un cliente perso senza che nessuno lo sappia.
 *
 * Il giro, in ordine:
 *
 * 1. **Riuscito**: si salva, si manda la posta, e si rimanda alla stessa
 *    pagina con un indirizzo diverso. E' lo schema «manda, rimanda, mostra»,
 *    e serve a una cosa sola: se chi ha mandato ricarica la pagina, non
 *    rimanda il messaggio una seconda volta.
 * 2. **Sbagliato**: non si rimanda niente. La pagina si disegna com'e', e il
 *    modulo ritrova dentro quello che era stato scritto, con gli errori
 *    accanto ai campi giusti. Perdere mezza pagina di testo perche' manca un
 *    numero di telefono e' il modo piu' veloce di far chiudere la scheda.
 *
 * Tre filtri contro lo spam, tutti **nostri**: nessuna chiamata a un server
 * di altri, che e' la regola del progetto e insieme un argomento di vendita.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Moduli;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Riceve gli invii dei moduli.
 */
final class Ricezione {

	/**
	 * Il nome del campo esca.
	 *
	 * E' un campo vero, nascosto alla vista e tolto dal giro del tabulatore:
	 * una persona non lo vede e non lo raggiunge, un programma che compila
	 * tutto quello che trova lo riempie e si qualifica da solo.
	 */
	public const ESCA = 'emme_sito_web';

	/**
	 * Quanti secondi devono passare, come minimo, fra l'apertura e l'invio.
	 */
	public const SECONDI_MINIMI = 3;

	/**
	 * Quanti invii si accettano da uno stesso collegamento, e in quanti secondi.
	 */
	public const INVII_MASSIMI = 5;

	/**
	 * In quanti secondi si contano.
	 */
	public const FINESTRA = 600;

	/**
	 * L'esito dell'invio in corso, se c'e' stato un invio in questa pagina.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $esito = null;

	/**
	 * Aggancia la ricezione.
	 */
	public static function init(): void {
		// Prima che la pagina cominci a scriversi: cosi' il rimando dopo un
		// invio riuscito puo' ancora partire.
		add_action( 'template_redirect', array( self::class, 'ricevi' ), 5 );
	}

	/**
	 * L'esito dell'invio per un certo modulo.
	 *
	 * Lo chiama render.php del modulo per sapere se deve mostrare gli errori,
	 * ricompilare i campi, oppure dire che e' andata bene.
	 *
	 * @param string $modulo_id Identificativo del modulo.
	 * @return array<string, mixed>|null Null se questo modulo non c'entra.
	 */
	public static function esito( string $modulo_id ): ?array {
		if ( null === self::$esito || $modulo_id !== ( self::$esito['modulo'] ?? '' ) ) {
			return null;
		}

		return self::$esito;
	}

	/**
	 * Dice se un modulo ha appena mandato un messaggio con successo.
	 *
	 * Si legge dall'indirizzo, perche' dopo un invio riuscito la pagina viene
	 * ricaricata: lo stato in memoria non sopravvive al rimando.
	 *
	 * @param string $modulo_id Identificativo del modulo.
	 * @return bool Vero se va mostrato il messaggio di riuscita.
	 */
	public static function appena_inviato( string $modulo_id ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- si legge un indirizzo, non si cambia niente.
		$arrivato = isset( $_GET['emme-inviato'] ) ? sanitize_key( wp_unslash( $_GET['emme-inviato'] ) ) : '';

		return '' !== $arrivato && $arrivato === $modulo_id;
	}

	/**
	 * Il campo esca, da scrivere dentro il modulo.
	 *
	 * Nascosto con il CSS del blocco e non con `type="hidden"`: un campo
	 * nascosto per tipo i programmi lo saltano, uno nascosto per aspetto no.
	 *
	 * @return string Il pezzo di pagina.
	 */
	public static function html_esca(): string {
		return '<div class="emme-modulo__esca" aria-hidden="true">'
			. '<label for="' . esc_attr( self::ESCA ) . '">' . esc_html__( 'Leave this field empty', 'emme-blocks' ) . '</label>'
			. '<input type="text" id="' . esc_attr( self::ESCA ) . '" name="' . esc_attr( self::ESCA ) . '" value="" tabindex="-1" autocomplete="off" />'
			. '</div>';
	}

	/**
	 * I campi nascosti che accompagnano ogni invio.
	 *
	 * @param string $modulo_id Identificativo del modulo.
	 * @param int    $pagina    Pagina in cui sta il modulo.
	 * @return string Il pezzo di pagina.
	 */
	public static function html_controlli( string $modulo_id, int $pagina ): string {
		$quando = time();

		return '<input type="hidden" name="emme_modulo" value="' . esc_attr( $modulo_id ) . '" />'
			. '<input type="hidden" name="emme_pagina" value="' . esc_attr( (string) $pagina ) . '" />'
			. '<input type="hidden" name="emme_quando" value="' . esc_attr( (string) $quando ) . '" />'
			. '<input type="hidden" name="emme_firma" value="' . esc_attr( self::firma( $quando, $modulo_id, $pagina ) ) . '" />'
			. wp_nonce_field( 'emme_modulo_' . $modulo_id, '_emme_nonce', true, false );
	}

	/**
	 * Dichiara che in pagina c'e' un modulo che aspetta un consenso.
	 *
	 * Sta qui e non dentro a render.php perche' e' la stessa coppia di
	 * «dichiara e carica» che usano le animazioni, la lightbox e il
	 * carosello: in una pagina senza moduli non si carica niente.
	 */
	public static function serve_lo_script(): void {
		\Emme\Css\Output::use_moduli();
	}

	/**
	 * Guarda se e' arrivato un invio, e in caso lo tratta.
	 */
	public static function ricevi(): void {
		if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- il nonce si controlla due righe piu' sotto, appena si sa di quale modulo si tratta.
		$modulo_id = isset( $_POST['emme_modulo'] ) ? sanitize_key( wp_unslash( $_POST['emme_modulo'] ) ) : '';

		if ( '' === $modulo_id ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- idem.
		$pagina = isset( $_POST['emme_pagina'] ) ? absint( wp_unslash( $_POST['emme_pagina'] ) ) : 0;

		$nonce = isset( $_POST['_emme_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_emme_nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'emme_modulo_' . $modulo_id ) ) {
			// Succede davvero, e quasi mai per colpa di un malintenzionato:
			// una pagina rimasta aperta mezza giornata, oppure servita da una
			// copia in cache. Si dice che cosa fare, non «accesso negato».
			self::$esito = self::fallita(
				$modulo_id,
				__( 'This page had been open for too long and the message was not sent. Press send again.', 'emme-blocks' )
			);

			return;
		}

		// --- primo filtro: il campo esca ------------------------------------
		// Se e' pieno non si dice niente: si fa finta che sia andata bene.
		// Dirgli che e' stato scoperto servirebbe solo a farlo migliorare.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce gia verificato qui sopra.
		$esca = isset( $_POST[ self::ESCA ] ) ? trim( (string) wp_unslash( $_POST[ self::ESCA ] ) ) : '';

		if ( '' !== $esca ) {
			self::vai_via( $modulo_id );

			return;
		}

		// --- secondo filtro: quanto ci ha messo -----------------------------
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce gia verificato.
		$quando = isset( $_POST['emme_quando'] ) ? absint( wp_unslash( $_POST['emme_quando'] ) ) : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce gia verificato.
		$firma  = isset( $_POST['emme_firma'] ) ? sanitize_text_field( wp_unslash( $_POST['emme_firma'] ) ) : '';

		if ( ! hash_equals( self::firma( $quando, $modulo_id, $pagina ), $firma ) ) {
			self::vai_via( $modulo_id );

			return;
		}

		if ( ( time() - $quando ) < self::SECONDI_MINIMI ) {
			// Qui invece si parla, perche' una persona vera puo' incapparci
			// incollando tutto e premendo subito: basta riprovare.
			self::$esito = self::fallita(
				$modulo_id,
				__( 'That was too quick. Press send again.', 'emme-blocks' )
			);

			return;
		}

		// --- terzo filtro: quanti ne sono arrivati da li' --------------------
		if ( self::troppi() ) {
			self::$esito = self::fallita(
				$modulo_id,
				__( 'Too many messages have been sent from here in a short time. Try again in a few minutes.', 'emme-blocks' )
			);

			return;
		}

		// --- il modulo vero, ritrovato nel contenuto -------------------------
		// Senza terzo argomento, cioe' con il controllo severo: per accettare
		// un invio la pagina dev'essere aperta a tutti. Dentro ci sono il
		// destinatario della posta e il testo della ricevuta.
		$struttura = Struttura::trova( $modulo_id, $pagina );

		if ( null === $struttura || array() === $struttura['campi'] ) {
			self::$esito = self::fallita(
				$modulo_id,
				__( 'This form could not be read. Reload the page and try again.', 'emme-blocks' )
			);

			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce gia verificato.
		$arrivati = isset( $_POST['emme'] ) && is_array( $_POST['emme'] ) ? wp_unslash( $_POST['emme'] ) : array();

		$valori = array();
		$errori = array();

		foreach ( $struttura['campi'] as $campo ) {
			$chiave = (string) ( $campo['chiave'] ?? '' );

			if ( '' === $chiave ) {
				continue;
			}

			$valore = Campi::pulisci( $campo, $arrivati[ $chiave ] ?? null );
			$errore = Campi::controlla( $campo, $valore );

			$valori[ $chiave ] = $valore;

			if ( '' !== $errore ) {
				$errori[ $chiave ] = $errore;
			}
		}

		if ( array() !== $errori ) {
			self::$esito = array(
				'modulo'   => $modulo_id,
				'errori'   => $errori,
				'valori'   => $valori,
				'generale' => __( 'Something is missing. Have a look at the fields marked below.', 'emme-blocks' ),
			);

			return;
		}

		self::accetta( $modulo_id, $pagina, $struttura, $valori );
	}

	/**
	 * Un invio buono: si salva, si avvisa, si rimanda.
	 *
	 * @param string                                                                        $modulo_id Identificativo del modulo.
	 * @param int                                                                           $pagina    Pagina di partenza.
	 * @param array{attributi: array<string, mixed>, campi: array<int, array<string, mixed>>} $struttura Il modulo ritrovato.
	 * @param array<string, string|string[]>                                                $valori    I valori ripuliti.
	 */
	private static function accetta( string $modulo_id, int $pagina, array $struttura, array $valori ): void {
		$attributi = $struttura['attributi'];

		// La forma leggibile: etichetta e valore, nell'ordine del modulo. E'
		// quello che si legge nella posta, in amministrazione e nel CSV, e
		// l'ordine conta perche' racconta la domanda prima della risposta.
		$leggibile = array();

		foreach ( $struttura['campi'] as $campo ) {
			$chiave = (string) ( $campo['chiave'] ?? '' );
			$valore = $valori[ $chiave ] ?? '';

			if ( is_array( $valore ) ) {
				$valore = implode( ', ', $valore );
			}

			if ( 'consenso' === ( $campo['tipo'] ?? '' ) ) {
				$valore = '' !== $valore ? __( 'Yes', 'emme-blocks' ) : __( 'No', 'emme-blocks' );
			}

			$leggibile[] = array(
				'chiave'    => $chiave,
				'etichetta' => '' !== (string) ( $campo['etichetta'] ?? '' )
					? wp_strip_all_tags( (string) $campo['etichetta'] )
					: $chiave,
				'valore'    => (string) $valore,
			);
		}

		$salvare = ! isset( $attributi['salva'] ) || false !== $attributi['salva'];
		$giorni  = isset( $attributi['conservazione'] ) ? absint( $attributi['conservazione'] ) : 0;

		$suo = self::indirizzo_di_chi_scrive( $struttura['campi'], $valori );

		if ( $salvare ) {
			Invii::salva( $leggibile, self::titolo( $struttura['campi'], $valori ), $modulo_id, $pagina, $giorni, $suo );
		}

		self::posta( $attributi, $leggibile, $suo, $pagina );

		/**
		 * Dopo che un invio e' stato accettato.
		 *
		 * @param array<int, array<string, string>> $leggibile Etichetta e valore di ogni campo.
		 * @param string                            $modulo_id Identificativo del modulo.
		 * @param int                               $pagina    Pagina di partenza.
		 */
		do_action( 'emme_modulo_inviato', $leggibile, $modulo_id, $pagina );

		self::conta_uno();
		self::vai_via( $modulo_id );
	}

	/**
	 * Manda la posta a chi tiene il sito, e la ricevuta a chi ha scritto.
	 *
	 * @param array<string, mixed>              $attributi Impostazioni del modulo.
	 * @param array<int, array<string, string>> $leggibile Etichetta e valore di ogni campo.
	 * @param string                            $suo       Indirizzo di chi ha scritto, gia' controllato.
	 * @param int                               $pagina    Pagina di partenza.
	 */
	private static function posta( array $attributi, array $leggibile, string $suo, int $pagina ): void {
		$a = sanitize_email( (string) ( $attributi['destinatario'] ?? '' ) );

		if ( '' === $a || ! is_email( $a ) ) {
			$a = (string) get_option( 'admin_email' );
		}

		if ( '' === $a ) {
			return;
		}

		$oggetto = trim( wp_strip_all_tags( (string) ( $attributi['oggetto'] ?? '' ) ) );

		if ( '' === $oggetto ) {
			/* translators: %s: name of the website. */
			$oggetto = sprintf( __( 'New message from %s', 'emme-blocks' ), (string) get_bloginfo( 'name' ) );
		}

		$righe = array();

		foreach ( $leggibile as $campo ) {
			$righe[] = $campo['etichetta'] . ': ' . $campo['valore'];
		}

		if ( $pagina > 0 ) {
			$righe[] = '';
			$righe[] = __( 'Sent from:', 'emme-blocks' ) . ' ' . (string) get_permalink( $pagina );
		}

		$intestazioni = array( 'Content-Type: text/plain; charset=UTF-8' );

		// Rispondi-a con l'indirizzo di chi ha scritto: e' quello che fa la
		// differenza fra «leggo e poi cerco il suo indirizzo» e «rispondo».
		// Va messo solo se e' davvero un indirizzo: un valore qualunque qui
		// dentro sarebbe una riga di intestazione scritta da un estraneo.
		if ( '' !== $suo ) {
			$intestazioni[] = 'Reply-To: ' . $suo;
		}

		wp_mail( $a, $oggetto, implode( "\n", $righe ), $intestazioni );

		// --- la ricevuta a chi ha scritto -----------------------------------
		// Il testo e' quello scritto nel pannello e basta: non ci si rimette
		// dentro niente di quello che ha mandato il visitatore, se no il
		// modulo diventa un modo per far partire posta con dentro quello che
		// si vuole, dal nostro indirizzo.
		$ricevuta = trim( (string) ( $attributi['ricevuta'] ?? '' ) );

		if ( '' !== $ricevuta && '' !== $suo ) {
			wp_mail(
				$suo,
				$oggetto,
				wp_strip_all_tags( $ricevuta ),
				array( 'Content-Type: text/plain; charset=UTF-8' )
			);
		}
	}

	/**
	 * L'indirizzo di posta di chi ha scritto, se l'ha lasciato.
	 *
	 * @param array<int, array<string, mixed>> $campi  La descrizione dei campi.
	 * @param array<string, string|string[]>   $valori I valori ripuliti.
	 * @return string L'indirizzo, oppure la stringa vuota.
	 */
	private static function indirizzo_di_chi_scrive( array $campi, array $valori ): string {
		foreach ( $campi as $campo ) {
			if ( 'email' !== ( $campo['tipo'] ?? '' ) ) {
				continue;
			}

			$valore = $valori[ (string) ( $campo['chiave'] ?? '' ) ] ?? '';

			if ( is_string( $valore ) && is_email( $valore ) ) {
				return sanitize_email( $valore );
			}
		}

		return '';
	}

	/**
	 * Come si chiama l'invio nell'elenco in amministrazione.
	 *
	 * Si cerca il nome, poi l'indirizzo di posta: e' quello che si guarda per
	 * primo scorrendo l'elenco.
	 *
	 * @param array<int, array<string, mixed>> $campi  La descrizione dei campi.
	 * @param array<string, string|string[]>   $valori I valori ripuliti.
	 * @return string Il titolo.
	 */
	private static function titolo( array $campi, array $valori ): string {
		$nome  = '';
		$posta = '';

		foreach ( $campi as $campo ) {
			$valore = $valori[ (string) ( $campo['chiave'] ?? '' ) ] ?? '';

			if ( ! is_string( $valore ) || '' === $valore ) {
				continue;
			}

			$auto = (string) ( $campo['autocompletamento'] ?? '' );

			if ( '' === $nome && in_array( $auto, array( 'name', 'given-name', 'family-name' ), true ) ) {
				$nome = $valore;
			}

			if ( '' === $posta && 'email' === ( $campo['tipo'] ?? '' ) ) {
				$posta = $valore;
			}
		}

		if ( '' !== $nome && '' !== $posta ) {
			return $nome . ' (' . $posta . ')';
		}

		return '' !== $nome ? $nome : $posta;
	}

	/**
	 * Rimanda alla stessa pagina dicendo che e' andata bene.
	 *
	 * @param string $modulo_id Identificativo del modulo.
	 */
	private static function vai_via( string $modulo_id ): void {
		$dove = remove_query_arg( array( 'emme-inviato' ) );
		$dove = add_query_arg( 'emme-inviato', $modulo_id, $dove );

		wp_safe_redirect( $dove . '#emme-modulo-' . $modulo_id, 303 );
		exit;
	}

	/**
	 * L'esito di un invio andato storto per un motivo generale.
	 *
	 * I valori si ritrovano lo stesso dentro al modulo: anche quando il
	 * motivo non riguarda un campo, quello che la persona aveva scritto non
	 * si butta via.
	 *
	 * @param string $modulo_id Identificativo del modulo.
	 * @param string $messaggio Che cosa e' successo.
	 * @return array<string, mixed> L'esito.
	 */
	private static function fallita( string $modulo_id, string $messaggio ): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- i valori si rimettono nel modulo, non si usano per decidere niente.
		$arrivati = isset( $_POST['emme'] ) && is_array( $_POST['emme'] ) ? wp_unslash( $_POST['emme'] ) : array();

		$valori = array();

		foreach ( $arrivati as $chiave => $valore ) {
			$chiave = Campi::chiave( (string) $chiave );

			if ( '' === $chiave ) {
				continue;
			}

			$valori[ $chiave ] = is_array( $valore )
				? array_map( 'sanitize_text_field', array_filter( $valore, 'is_scalar' ) )
				: sanitize_textarea_field( (string) $valore );
		}

		return array(
			'modulo'   => $modulo_id,
			'errori'   => array(),
			'valori'   => $valori,
			'generale' => $messaggio,
		);
	}

	/**
	 * La firma del momento in cui il modulo e' stato disegnato.
	 *
	 * Senza, l'orario sarebbe un campo nascosto come un altro e chiunque
	 * potrebbe scriverci quello che vuole.
	 *
	 * **Dentro c'e' anche la pagina**, e non e' un dettaglio: senza, chi manda
	 * potrebbe cambiare `emme_pagina` e far cercare il modulo in una pagina
	 * qualunque - per esempio una bozza con un destinatario diverso - e far
	 * partire la posta verso li'.
	 *
	 * @param int    $quando    Il momento, in secondi.
	 * @param string $modulo_id Identificativo del modulo.
	 * @param int    $pagina    Pagina in cui sta il modulo.
	 * @return string La firma.
	 */
	private static function firma( int $quando, string $modulo_id, int $pagina ): string {
		return wp_hash( 'emme-modulo|' . $modulo_id . '|' . $pagina . '|' . $quando );
	}

	/**
	 * Dice se da questo collegamento sono gia' arrivati troppi messaggi.
	 *
	 * Il collegamento non si conserva: si conserva la sua **impronta**, cioe'
	 * un numero da cui l'indirizzo non si ricava. Serve a contare, non a
	 * sapere chi e'.
	 *
	 * @return bool Vero se si e' superato il tetto.
	 */
	private static function troppi(): bool {
		$chiave = self::chiave_conteggio();

		if ( '' === $chiave ) {
			return false;
		}

		return (int) get_transient( $chiave ) >= self::INVII_MASSIMI;
	}

	/**
	 * Segna che un invio e' passato.
	 */
	private static function conta_uno(): void {
		$chiave = self::chiave_conteggio();

		if ( '' === $chiave ) {
			return;
		}

		$quanti = (int) get_transient( $chiave );

		set_transient( $chiave, $quanti + 1, self::FINESTRA );
	}

	/**
	 * La chiave con cui si contano gli invii di un collegamento.
	 *
	 * @return string La chiave, oppure la stringa vuota se l'indirizzo non si sa.
	 */
	private static function chiave_conteggio(): string {
		$indirizzo = isset( $_SERVER['REMOTE_ADDR'] )
			? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) )
			: '';

		if ( '' === $indirizzo ) {
			return '';
		}

		return 'emme_mod_' . substr( wp_hash( 'conteggio|' . $indirizzo ), 0, 20 );
	}
}
