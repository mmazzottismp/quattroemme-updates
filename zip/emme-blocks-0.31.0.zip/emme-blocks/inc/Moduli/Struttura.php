<?php
/**
 * Dove sta un modulo, e di quali campi e' fatto.
 *
 * Quando arriva un invio, il server **non si fida** dell'elenco di campi che
 * gli manda il browser: se lo va a ricostruire dal contenuto della pagina. E'
 * la differenza fra un modulo e una porta aperta — senza questo passaggio,
 * chiunque potrebbe aggiungere campi a piacere, saltare un obbligatorio o
 * mandare un messaggio di dieci megabyte.
 *
 * Il contenuto di una pagina WordPress e' una sequenza di commenti HTML, e
 * `parse_blocks()` la trasforma in un albero. Qui si cammina su quell'albero
 * cercando il nostro modulo, e poi i campi che ha dentro — anche se sono
 * dentro a dei contenitori, perche' la disposizione su due colonne e' proprio
 * un contenitore.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Moduli;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ritrova un modulo nel contenuto e ne legge i campi.
 */
final class Struttura {

	/**
	 * Quanti campi puo' avere un modulo.
	 *
	 * Non e' un limite di gusto: e' la rete che impedisce a un contenuto
	 * malformato di far girare a vuoto il controllo di un invio.
	 */
	public const CAMPI_MASSIMI = 60;

	/**
	 * Cerca un modulo e restituisce le sue impostazioni e i suoi campi.
	 *
	 * @param string $modulo_id Identificativo del modulo (l'emmeId del blocco).
	 * @param int    $post_id   Pagina da cui e' partito l'invio.
	 * @param bool   $per_invio Vero quando si sta accettando un invio, falso
	 *                          quando si sta solo disegnando il modulo. Il
	 *                          predefinito e' il caso severo: un chiamante
	 *                          nuovo che se ne dimentica ottiene il controllo
	 *                          stretto, non quello largo.
	 * @return array{attributi: array<string, mixed>, campi: array<int, array<string, mixed>>}|null Null se il modulo non si trova.
	 */
	public static function trova( string $modulo_id, int $post_id, bool $per_invio = true ): ?array {
		if ( '' === $modulo_id ) {
			return null;
		}

		$contenuti = array();

		$pagina = $post_id > 0 ? get_post( $post_id ) : null;

		/*
		 * Il numero della pagina arriva dal modulo mandato, quindi da fuori, e
		 * dentro a una pagina ci sono il destinatario della posta e il testo
		 * della ricevuta. Chi puo' far leggere al server una pagina scelta da
		 * lui fa partire posta dove vuole: il controllo e' in `visibile()`,
		 * che spiega anche perche' disegnare e accettare un invio sono due
		 * permessi diversi.
		 */
		if ( $pagina instanceof \WP_Post && self::visibile( $pagina, $per_invio ) ) {
			$contenuti[] = (string) $pagina->post_content;
		}

		foreach ( $contenuti as $contenuto ) {
			$trovato = self::cerca( parse_blocks( $contenuto ), $modulo_id, 0 );

			if ( null !== $trovato ) {
				return $trovato;
			}
		}

		// Non era nel contenuto della pagina: puo' stare in una parte del sito
		// — una testata, un pie' — che e' salvata nel database a parte.
		foreach ( self::parti_del_sito() as $contenuto ) {
			$trovato = self::cerca( parse_blocks( $contenuto ), $modulo_id, 0 );

			if ( null !== $trovato ) {
				return $trovato;
			}
		}

		return null;
	}

	/**
	 * Legge i campi che stanno dentro a un blocco modulo gia' trovato.
	 *
	 * Serve anche a render.php, che il modulo ce l'ha gia' in mano.
	 *
	 * @param array<int, array<string, mixed>> $blocchi I blocchi interni.
	 * @return array<int, array<string, mixed>> I campi, nell'ordine in cui si leggono.
	 */
	public static function campi( array $blocchi ): array {
		$campi = array();

		self::raccogli( $blocchi, $campi, 0 );

		return self::battezza( $campi );
	}

	/**
	 * Cammina sull'albero cercando il modulo con quell'identificativo.
	 *
	 * @param array<int, array<string, mixed>> $blocchi    I blocchi da guardare.
	 * @param string                           $modulo_id  Identificativo cercato.
	 * @param int                              $profondita Quanto si e' scesi, per non girare a vuoto.
	 * @return array{attributi: array<string, mixed>, campi: array<int, array<string, mixed>>}|null
	 */
	private static function cerca( array $blocchi, string $modulo_id, int $profondita ): ?array {
		if ( $profondita > 20 ) {
			return null;
		}

		foreach ( $blocchi as $blocco ) {
			if ( ! is_array( $blocco ) ) {
				continue;
			}

			$nome      = (string) ( $blocco['blockName'] ?? '' );
			$attributi = isset( $blocco['attrs'] ) && is_array( $blocco['attrs'] ) ? $blocco['attrs'] : array();

			if ( 'emme/modulo' === $nome && $modulo_id === (string) ( $attributi['emmeId'] ?? '' ) ) {
				return array(
					'attributi' => $attributi,
					'campi'     => self::campi( $blocco['innerBlocks'] ?? array() ),
				);
			}

			// Un blocco riusabile tiene il suo contenuto in un altro articolo:
			// senza aprirlo, un modulo messo li' dentro non si troverebbe.
			$dentro = 'core/block' === $nome
				? self::blocco_riusabile( $attributi )
				: ( isset( $blocco['innerBlocks'] ) && is_array( $blocco['innerBlocks'] ) ? $blocco['innerBlocks'] : array() );

			$trovato = self::cerca( $dentro, $modulo_id, $profondita + 1 );

			if ( null !== $trovato ) {
				return $trovato;
			}
		}

		return null;
	}

	/**
	 * Raccoglie i campi camminando sull'albero.
	 *
	 * Si scende dentro a tutto, perche' i campi stanno quasi sempre dentro a
	 * dei contenitori: e' cosi' che si mettono Nome e Cognome affiancati.
	 *
	 * @param array<int, array<string, mixed>> $blocchi    I blocchi da guardare.
	 * @param array<int, array<string, mixed>> $campi      Dove accumulare, passato per riferimento.
	 * @param int                              $profondita Quanto si e' scesi.
	 */
	private static function raccogli( array $blocchi, array &$campi, int $profondita ): void {
		if ( $profondita > 20 || count( $campi ) >= self::CAMPI_MASSIMI ) {
			return;
		}

		foreach ( $blocchi as $blocco ) {
			if ( ! is_array( $blocco ) ) {
				continue;
			}

			$nome = (string) ( $blocco['blockName'] ?? '' );

			if ( 'emme/campo' === $nome ) {
				$campi[] = self::descrizione( isset( $blocco['attrs'] ) && is_array( $blocco['attrs'] ) ? $blocco['attrs'] : array() );

				if ( count( $campi ) >= self::CAMPI_MASSIMI ) {
					return;
				}

				continue;
			}

			// Un modulo dentro un modulo non si fa, e i suoi campi non sono
			// nostri: si salta tutto il ramo.
			if ( 'emme/modulo' === $nome ) {
				continue;
			}

			$dentro = isset( $blocco['innerBlocks'] ) && is_array( $blocco['innerBlocks'] ) ? $blocco['innerBlocks'] : array();

			self::raccogli( $dentro, $campi, $profondita + 1 );
		}
	}

	/**
	 * Traduce gli attributi salvati di un campo nella sua descrizione.
	 *
	 * Qui si decide anche cosa fare di un tipo che non conosciamo: diventa un
	 * campo di testo, invece di sparire. Un campo che scompare da un modulo
	 * gia' consegnato e' peggio di un campo generico.
	 *
	 * @param array<string, mixed> $attributi Attributi del blocco.
	 * @return array<string, mixed> La descrizione.
	 */
	private static function descrizione( array $attributi ): array {
		$tipo = (string) ( $attributi['tipo'] ?? 'testo' );

		if ( ! Campi::valida( $tipo ) ) {
			$tipo = 'testo';
		}

		return array(
			'tipo'              => $tipo,
			'nome'              => (string) ( $attributi['nome'] ?? '' ),
			'etichetta'         => (string) ( $attributi['etichetta'] ?? '' ),
			'descrizione'       => (string) ( $attributi['descrizione'] ?? '' ),
			'segnaposto'        => (string) ( $attributi['segnaposto'] ?? '' ),
			'obbligatorio'      => ! empty( $attributi['obbligatorio'] ),
			'opzioni'           => (string) ( $attributi['opzioni'] ?? '' ),
			'autocompletamento' => (string) ( $attributi['autocompletamento'] ?? '' ),
			'righe'             => isset( $attributi['righe'] ) ? (int) $attributi['righe'] : 6,
			'emmeId'            => (string) ( $attributi['emmeId'] ?? '' ),
		);
	}

	/**
	 * Da a ogni campo il suo nome, e lo rende unico.
	 *
	 * Due campi con lo stesso nome vorrebbe dire che il secondo cancella il
	 * primo, in silenzio: capita facilmente duplicando un campo nell'editor.
	 *
	 * @param array<int, array<string, mixed>> $campi I campi, nell'ordine.
	 * @return array<int, array<string, mixed>> Gli stessi, con la chiave «chiave».
	 */
	private static function battezza( array $campi ): array {
		$presi  = array();
		$numero = 0;

		foreach ( $campi as $indice => $campo ) {
			++$numero;
			$nome = Campi::nome( $campo, $numero );

			if ( isset( $presi[ $nome ] ) ) {
				$doppio = 2;

				while ( isset( $presi[ $nome . '_' . $doppio ] ) ) {
					++$doppio;
				}

				$nome = $nome . '_' . $doppio;
			}

			$presi[ $nome ]           = true;
			$campi[ $indice ]['chiave'] = $nome;
		}

		return $campi;
	}

	/**
	 * Dice se una pagina e' aperta a tutti.
	 *
	 * `is_post_publicly_viewable` c'e' dalla 5.7 e tiene conto sia dello stato
	 * sia della protezione con parola d'ordine; il minimo dichiarato dal
	 * plugin e' la 6.6, quindi c'e' sempre.
	 *
	 * **DISEGNARE un modulo e ACCETTARNE un invio sono due permessi diversi**,
	 * e tenerli insieme e' stato un errore: segnalato dal controllo automatico
	 * di sicurezza l'11/11/2026, poche ore dopo che l'avevo introdotto.
	 *
	 * Il numero della pagina viaggia in un campo nascosto, quindi arriva da
	 * fuori. Dentro a una pagina ci sono il **destinatario** della posta e il
	 * testo della **ricevuta**: chi riesce a far leggere al server una pagina
	 * scelta da lui fa partire posta verso l'indirizzo che vuole, con il testo
	 * che vuole. E un Collaboratore — che su un sito di un cliente e' spesso
	 * solo chi scrive articoli — una bozza la puo' salvare con dentro quello
	 * che gli pare: bastava poterla leggere per avere un postino.
	 *
	 * Quindi:
	 *
	 * - per **accettare un invio** serve una pagina che chiunque puo' aprire,
	 *   e basta. Nessuna eccezione, per nessun ruolo;
	 * - per **disegnare** il modulo si accetta anche una bozza, ma solo a chi
	 *   quella pagina la puo' modificare. Li' non parte niente: si decide
	 *   soltanto con che nome viaggia ogni campo.
	 *
	 * @param \WP_Post $post      La pagina.
	 * @param bool     $per_invio Vero se si sta accettando un invio.
	 * @return bool Vero se si puo' leggere il modulo che c'e' dentro.
	 */
	private static function visibile( \WP_Post $post, bool $per_invio ): bool {
		if ( '' !== (string) $post->post_password ) {
			return false;
		}

		if ( is_post_publicly_viewable( $post ) ) {
			return true;
		}

		if ( $per_invio ) {
			return false;
		}

		return current_user_can( 'edit_post', $post->ID );
	}

	/**
	 * Il contenuto di un blocco riusabile.
	 *
	 * @param array<string, mixed> $attributi Attributi del blocco core/block.
	 * @return array<int, array<string, mixed>> I blocchi che ci sono dentro.
	 */
	private static function blocco_riusabile( array $attributi ): array {
		$ref = isset( $attributi['ref'] ) ? (int) $attributi['ref'] : 0;

		if ( $ref <= 0 ) {
			return array();
		}

		$post = get_post( $ref );

		if ( ! $post instanceof \WP_Post || 'wp_block' !== $post->post_type ) {
			return array();
		}

		return parse_blocks( (string) $post->post_content );
	}

	/**
	 * Il contenuto delle parti del sito salvate nel database.
	 *
	 * Sono testate, pie' di pagina e simili: li' dentro puo' starci un modulo
	 * breve, per esempio un «richiedi informazioni» nel pie'.
	 *
	 * @return string[] I contenuti.
	 */
	private static function parti_del_sito(): array {
		$parti = get_posts(
			array(
				'post_type'      => 'wp_template_part',
				'post_status'    => 'publish',
				'posts_per_page' => 50,
				'no_found_rows'  => true,
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- poche righe, e solo quando un modulo non si trova.
					array(
						'taxonomy' => 'wp_theme',
						'field'    => 'name',
						'terms'    => get_stylesheet(),
					),
				),
			)
		);

		$fuori = array();

		foreach ( $parti as $parte ) {
			if ( $parte instanceof \WP_Post ) {
				$fuori[] = (string) $parte->post_content;
			}
		}

		return $fuori;
	}
}
