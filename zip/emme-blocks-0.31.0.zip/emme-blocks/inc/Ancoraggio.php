<?php
/**
 * L'ancoraggio allo scorrimento, in un posto solo.
 *
 * PERCHE' ESISTE QUESTA CLASSE
 *
 * Il pannello «Scorrimento» e' offerto da **tutti** i blocchi, e fino al
 * 12/11/2026 lo onorava **solo il contenitore**: su tutti gli altri si poteva
 * accendere «Resta in cima mentre la pagina scorre», scegliere come si
 * rimpicciolisce e a che distanza si ferma, e non succedeva niente.
 *
 * Manuel l'ha trovato sulla fisarmonica: «guarda come l'ho impostata, non si
 * aggancia alla pagina in alto e la distanza l'ho impostata a wide». Il CSS
 * c'era - il generatore scrive le regole per ogni blocco - ma l'ancoraggio
 * non e' solo CSS: vuole un attributo che lo script riconosce, lo script
 * acceso, e un segnaposto attorno al blocco.
 *
 * E' la quarta volta che lo stesso difetto si presenta nella stessa forma -
 * una possibilita' offerta da molti blocchi e onorata da uno - dopo lo sfondo
 * animato, il velo e le due del titolo. Da qui la regola: **quello che vale
 * per piu' blocchi sta in una classe, e i render la chiamano**. Una prova in
 * `tests/prove-controlli.php` diventa rossa se un blocco offre il pannello e
 * non chiama questa classe.
 *
 * COSA SERVE, OLTRE AL CSS
 *
 * - `data-emme-anc` sul blocco: lo script legge da li' quali comportamenti
 *   accendere (`pin`, `shrink`, `slide`, `hide`).
 * - lo script `shared/testata-ancorata.js`, caricato solo dove serve.
 * - un **segnaposto** attorno al blocco: un blocco ancorato esce dal flusso,
 *   e senza qualcuno che gli tenga il posto il contenuto sotto salterebbe su
 *   di colpo. Il segnaposto resta alto quanto il blocco a riposo. E' lo
 *   stesso meccanismo di Blocksy, misurato il 10/11/2026.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Prepara un blocco ad ancorarsi mentre la pagina scorre.
 */
final class Ancoraggio {

	/**
	 * I modi che lo script riconosce, oltre al semplice restare in cima.
	 */
	private const MODI = array( 'shrink', 'slide' );

	/**
	 * Se il blocco e' ancorato su almeno uno schermo.
	 *
	 * `pin` e' l'unica proprieta' responsive del gruppo - una barra ancorata
	 * su telefono mangia meta' dello spazio utile, e spesso si spegne - e qui
	 * basta che sia accesa da qualche parte: a decidere su quali schermi vale
	 * poi e' il CSS, non il marcatore.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return bool Vero se e' ancorato.
	 */
	public static function attivo( array $style ): bool {
		$scroll = $style['scroll'] ?? array();

		if ( ! is_array( $scroll ) || empty( $scroll['pin'] ) || ! is_array( $scroll['pin'] ) ) {
			return false;
		}

		return in_array( true, $scroll['pin'], true );
	}

	/**
	 * I comportamenti da accendere, nella forma che legge lo script.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return string Per esempio «pin» oppure «shrink hide». Vuoto se spento.
	 */
	private static function modi( array $style ): string {
		if ( ! self::attivo( $style ) ) {
			return '';
		}

		$scroll = $style['scroll'];
		$modi   = array();

		// Il nome del modo viaggia tale e quale nell'attributo: lo script lo
		// legge da li'.
		if ( in_array( $scroll['mode'] ?? '', self::MODI, true ) ) {
			$modi[] = (string) $scroll['mode'];
		}

		if ( ! empty( $scroll['hideDown'] ) ) {
			$modi[] = 'hide';
		}

		return $modi ? implode( ' ', $modi ) : 'pin';
	}

	/**
	 * Il marcatore gia' scritto, per i blocchi che compongono gli attributi
	 * a mano invece di passare da `get_block_wrapper_attributes()`.
	 *
	 * Sono quelli in cui il riquadro esterno serve solo ad allineare e la
	 * classe del blocco sta sull'elemento DENTRO - pulsante, icona, immagine.
	 * Il marcatore deve stare sullo stesso elemento su cui il generatore
	 * scrive le regole, se no lo script muove una cosa e il CSS ne ferma
	 * un'altra.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return string L'attributo con lo spazio davanti, oppure niente.
	 */
	public static function attributo( array $style ): string {
		$modi = self::modi( $style );

		if ( '' === $modi ) {
			return '';
		}

		self::accendi();

		return ' data-emme-anc="' . esc_attr( $modi ) . '"';
	}

	/**
	 * Accende lo script, una volta sola per pagina.
	 */
	private static function accendi(): void {
		Css\Output::use_ancoraggio();
	}

	/**
	 * Aggiunge il marcatore agli attributi e accende lo script.
	 *
	 * Si usa cosi', prima di `get_block_wrapper_attributes()`:
	 *
	 *     $emme_extra = \Emme\Ancoraggio::segna( $emme_style, $emme_extra );
	 *
	 * @param array<string, mixed>  $style Contenuto di emmeStyle.
	 * @param array<string, string> $extra Attributi gia' raccolti.
	 * @return array<string, string> Gli stessi attributi, piu' il marcatore.
	 */
	public static function segna( array $style, array $extra ): array {
		$modi = self::modi( $style );

		if ( '' === $modi ) {
			return $extra;
		}

		$extra['data-emme-anc'] = $modi;

		self::accendi();

		return $extra;
	}

	/**
	 * L'apertura del segnaposto, o niente.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return string Il tag di apertura, oppure la stringa vuota.
	 */
	public static function apri( array $style ): string {
		return self::attivo( $style ) ? '<div class="emme-anc-posto">' : '';
	}

	/**
	 * La chiusura del segnaposto, o niente.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return string Il tag di chiusura, oppure la stringa vuota.
	 */
	public static function chiudi( array $style ): string {
		return self::attivo( $style ) ? '</div>' : '';
	}
}
