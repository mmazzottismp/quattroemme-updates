<?php
/**
 * La categoria «quattroemme» nell'elenco dei blocchi.
 *
 * Senza di questa i nostri blocchi stanno sparsi dentro «Design» e «Media»,
 * in mezzo a quelli di WordPress, e chi apre l'elenco non ha modo di capire
 * quali arrivano da qui. Con la categoria stanno tutti in un riquadro loro,
 * con la sua intestazione, ed e' il modo con cui WordPress raggruppa i
 * blocchi di un plugin: il filtro `block_categories_all` esiste dalla 5.8.
 *
 * Il prefisso nel titolo e le parole chiave (vedi i block.json) servono per
 * la ricerca; questa serve per chi guarda l'elenco senza cercare niente.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Aggiunge la categoria dei blocchi quattroemme.
 */
final class Categoria {

	/**
	 * La chiave della categoria.
	 *
	 * E' scritta in ogni block.json: cambiandola i blocchi finirebbero in una
	 * categoria che non esiste e WordPress li metterebbe fra quelli senza
	 * categoria.
	 */
	public const SLUG = 'quattroemme';

	/**
	 * Si aggancia al filtro.
	 */
	public static function init(): void {
		add_filter( 'block_categories_all', array( self::class, 'aggiungi' ) );
	}

	/**
	 * Mette la categoria in cima all'elenco.
	 *
	 * In cima e non in fondo perche' su un sito costruito con questi blocchi
	 * sono quelli che si usano tutto il giorno: averli sotto a sei riquadri
	 * del core vuol dire scorrere ogni volta.
	 *
	 * @param array<int, array<string, mixed>> $categorie Le categorie attuali.
	 * @return array<int, array<string, mixed>> Le categorie con la nostra davanti.
	 */
	public static function aggiungi( array $categorie ): array {
		foreach ( $categorie as $categoria ) {
			if ( isset( $categoria['slug'] ) && self::SLUG === $categoria['slug'] ) {
				return $categorie;
			}
		}

		array_unshift(
			$categorie,
			array(
				'slug'  => self::SLUG,
				'title' => __( 'quattroemme', 'emme-blocks' ),
				'icon'  => null,
			)
		);

		return $categorie;
	}
}
