<?php
/**
 * I nostri aspetti aggiuntivi per i blocchi di WordPress.
 *
 * Non tutto quello che serve merita un blocco nuovo. Misurando i siti di
 * Manuel sono emerse due cose che lui usa spesso e che WordPress sa gia' fare
 * quasi del tutto:
 *
 * - una linea di separazione che sfuma ai lati (dieci volte, sempre uguale);
 * - un elenco con un'icona al posto del pallino (quattro volte).
 *
 * Per tutte e due il blocco del core c'e' gia' ed e' migliore del nostro
 * sarebbe mai stato: il separatore sa allinearsi, colorarsi e spaziarsi;
 * l'elenco e' un <ul> vero, con <li> dentro, che un lettore di schermo
 * annuncia come elenco. Mancava solo l'aspetto.
 *
 * Quindi qui non si costruisce niente: si aggiunge un aspetto a quello che
 * c'e'. E' l'altra faccia del principio 7 del progetto — un blocco nostro
 * deve dare piu' di quello del core, e se non lo da', non si fa.
 *
 * Il CSS di ogni aspetto viaggia con l'aspetto stesso (inline_style), quindi
 * WordPress lo scrive in pagina **solo dove quell'aspetto e' usato davvero**.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registra gli aspetti aggiuntivi sui blocchi di WordPress.
 */
final class BlockStyles {

	/**
	 * Gli aspetti: blocco, nome e file del foglio.
	 *
	 * L'etichetta NON sta qui dentro. Ci stava, e passava da
	 * `__( $stile['etichetta'] )`, cioe' da una variabile: cosi' nessuno
	 * strumento di traduzione la trova — ne' gettext ne' le nostre prove — e
	 * restava in italiano per sempre senza che niente lo segnalasse. Le
	 * etichette stanno quindi scritte per esteso in `etichetta()`, una per
	 * una, che e' l'unico modo perche' finiscano nel catalogo.
	 *
	 * @var array<int, array<string, string>>
	 */
	private const STILI = array(
		array(
			'blocco' => 'core/separator',
			'nome'   => 'emme-sfumato',
			'file'   => 'separatore-sfumato.css',
		),
		array(
			'blocco' => 'core/list',
			'nome'   => 'emme-spunta',
			'file'   => 'elenco-spunta.css',
		),
		array(
			'blocco' => 'core/list',
			'nome'   => 'emme-freccia',
			'file'   => 'elenco-freccia.css',
		),
	);

	/**
	 * L'etichetta di un aspetto, come la legge chi usa l'editor.
	 *
	 * @param string $nome Nome dell'aspetto.
	 * @return string L'etichetta tradotta.
	 */
	private static function etichetta( string $nome ): string {
		switch ( $nome ) {
			case 'emme-sfumato':
				return __( 'Faded at the edges', 'emme-blocks' );
			case 'emme-spunta':
				return __( 'Check marks', 'emme-blocks' );
			case 'emme-freccia':
				return __( 'Arrows', 'emme-blocks' );
		}

		return $nome;
	}

	/**
	 * Aggancia la registrazione. Si chiama al caricamento del plugin.
	 */
	public static function init(): void {
		add_action( 'init', array( self::class, 'registra' ) );
	}

	/**
	 * Registra ogni aspetto con il suo foglio di stile.
	 */
	public static function registra(): void {
		foreach ( self::STILI as $stile ) {
			$css = self::foglio( $stile['file'] );

			if ( '' === $css ) {
				continue;
			}

			register_block_style(
				$stile['blocco'],
				array(
					'name'         => $stile['nome'],
					'label'        => self::etichetta( $stile['nome'] ),
					'inline_style' => $css,
				)
			);
		}
	}

	/**
	 * Legge un foglio e lo alleggerisce.
	 *
	 * Sono file nostri, scritti a mano: non c'e' niente da filtrare, solo
	 * commenti e spazi da togliere perche' finiscono dentro la pagina.
	 *
	 * @param string $nome Nome del file dentro shared/stili/.
	 * @return string Il CSS, oppure la stringa vuota.
	 */
	private static function foglio( string $nome ): string {
		$file = dirname( __DIR__ ) . '/shared/stili/' . $nome;

		if ( ! is_readable( $file ) ) {
			return '';
		}

		$css = (string) file_get_contents( $file );

		// Attenzione: qui non si tolgono tutti gli spazi come nel generatore,
		// perche' dentro c'e' un indirizzo data: con un disegno SVG, e in
		// quello gli spazi contano.
		$css = (string) preg_replace( '#/\*.*?\*/#s', '', $css );

		return trim( (string) preg_replace( '/\n\s*/', ' ', $css ) );
	}
}
