<?php
/**
 * Gli aspetti di un titolo, dal lato del sito.
 *
 * Legge la stessa `shared/titoli.json` che legge l'editor: una fonte sola,
 * quindi quello che si sceglie nel pannello e quello che il sito disegna non
 * possono diventare due cose diverse.
 *
 * Qui dentro c'e' solo il controllo di quello che arriva. Il disegno lo fa il
 * foglio di stile del blocco, con le variabili che il tema dichiara.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Quello che un titolo puo' essere.
 */
final class Titoli {

	/**
	 * La libreria, letta una volta sola.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $libreria = null;

	/**
	 * Legge shared/titoli.json.
	 *
	 * @return array<string, mixed> La libreria, vuota se il file manca.
	 */
	private static function libreria(): array {
		if ( null === self::$libreria ) {
			$percorso = dirname( __DIR__ ) . '/shared/titoli.json';
			$grezzo   = is_readable( $percorso ) ? (string) file_get_contents( $percorso ) : '';
			$letto    = json_decode( $grezzo, true );

			self::$libreria = is_array( $letto ) ? $letto : array();
		}

		return self::$libreria;
	}

	/**
	 * Gli aspetti dichiarati.
	 *
	 * @return array<string, array<string, mixed>> chiave => descrizione.
	 */
	public static function aspetti(): array {
		$aspetti = self::libreria()['aspetti'] ?? array();

		return is_array( $aspetti ) ? $aspetti : array();
	}

	/**
	 * I livelli ammessi.
	 *
	 * @return string[] Gli elementi HTML.
	 */
	public static function livelli(): array {
		$livelli = self::libreria()['livelli'] ?? array();

		return is_array( $livelli ) ? $livelli : array();
	}

	/**
	 * L'aspetto, se e' uno di quelli dichiarati.
	 *
	 * Un aspetto che non esiste non si disegna a caso e non si rifiuta: si
	 * ripiega su «sezione», che e' la forma piu' comune. Una pagina scritta
	 * con una versione futura del plugin, aperta con una vecchia, deve
	 * restare leggibile.
	 *
	 * @param string $aspetto Quello che c'e' scritto nel blocco.
	 * @return string Un aspetto valido.
	 */
	public static function aspetto( string $aspetto ): string {
		return isset( self::aspetti()[ $aspetto ] ) ? $aspetto : 'sezione';
	}

	/**
	 * Il livello, se e' uno di quelli ammessi.
	 *
	 * @param string $livello Quello che c'e' scritto nel blocco.
	 * @return string Un elemento HTML valido.
	 */
	public static function livello( string $livello ): string {
		return in_array( $livello, self::livelli(), true ) ? $livello : 'h2';
	}

	/**
	 * Il peso, se e' uno di quelli ammessi.
	 *
	 * @param string $peso Quello che c'e' scritto nel blocco.
	 * @return string Il peso, oppure la stringa vuota per «come l'aspetto».
	 */
	public static function peso( string $peso ): string {
		$pesi = self::libreria()['pesi'] ?? array();

		return in_array( $peso, is_array( $pesi ) ? $pesi : array(), true ) ? $peso : '';
	}
}
