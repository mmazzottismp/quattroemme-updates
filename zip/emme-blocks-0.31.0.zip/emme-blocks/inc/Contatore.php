<?php
/**
 * Come si scrive un numero, in un posto solo.
 *
 * PERCHE' ESISTE
 *
 * Il numero finale lo scrive il PHP dentro alla pagina - cosi' chi arriva
 * senza JavaScript vede il dato giusto - e quelli in mezzo li scrive lo
 * script mentre il contatore sale. Sono due meta' della stessa cosa: se non
 * scrivono il numero allo stesso modo, l'ultimo passo del conteggio si vede
 * come uno scatto, e si vede **solo sul sito**.
 *
 * Qui sta la meta' in PHP. La gemella e' `scrivi()` in
 * `shared/contatore.js`, e una prova confronta le due su una manciata di
 * numeri.
 *
 * I separatori non si decidono qui: sono quelli della lingua del sito, e
 * viaggiano fino allo script come attributi.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Scrive i numeri di un contatore.
 */
final class Contatore {

	/**
	 * Quante cifre dopo la virgola si possono chiedere.
	 *
	 * Oltre le tre, un numero smette di essere leggibile a colpo d'occhio, e
	 * un contatore esiste proprio per essere letto a colpo d'occhio.
	 */
	public const DECIMALI_MASSIMI = 3;

	/**
	 * I separatori della lingua del sito.
	 *
	 * In italiano il punto divide le migliaia e la virgola i decimali; in
	 * inglese e' il contrario. Non e' una preferenza: e' come si leggono i
	 * numeri, e sbagliarlo cambia il significato di quello che si scrive.
	 *
	 * @return array{0: string, 1: string} Migliaia e decimali.
	 */
	public static function separatori(): array {
		global $wp_locale;

		$migliaia = $wp_locale->number_format['thousands_sep'] ?? '.';
		$virgola  = $wp_locale->number_format['decimal_point'] ?? ',';

		return array( (string) $migliaia, (string) $virgola );
	}

	/**
	 * Scrive un numero.
	 *
	 * Gemella di `scrivi()` in shared/contatore.js.
	 *
	 * @param float  $valore   Il numero.
	 * @param int    $decimali Quante cifre dopo la virgola.
	 * @param string $migliaia Separatore delle migliaia.
	 * @param string $virgola  Separatore dei decimali.
	 * @return string Il numero scritto.
	 */
	public static function scrivi( float $valore, int $decimali, string $migliaia, string $virgola ): string {
		$decimali = max( 0, min( self::DECIMALI_MASSIMI, $decimali ) );

		return number_format( $valore, $decimali, $virgola, $migliaia );
	}
}
