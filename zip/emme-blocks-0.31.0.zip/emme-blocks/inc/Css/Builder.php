<?php
/**
 * Generatore del CSS dei blocchi quattroemme.
 *
 * Prende le impostazioni salvate in un blocco (l'attributo emmeStyle) e le
 * trasforma in regole CSS, seguendo la tabella in shared/style-map.json.
 *
 * Questa classe non usa nessuna funzione di WordPress: cosi si puo provare da
 * sola, con il solo PHP, senza caricare un sito. L'innesto in WordPress sta in
 * Emme\Css\Output.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme\Css;

/**
 * Costruisce il foglio di stile dei blocchi presenti in pagina.
 */
final class Builder {

	/**
	 * Gli schermi previsti, dal piu largo al piu stretto.
	 *
	 * Il desktop e la base e non ha punto di rottura: tablet e telefono lo
	 * sovrascrivono con max-width.
	 *
	 * @var array<string, int|null>
	 */
	private static array $breakpoints = array(
		'desktop' => null,
		'tablet'  => 1024,
		'mobile'  => 767,
	);

	/**
	 * La tabella delle corrispondenze, letta una volta sola.
	 *
	 * @var array<string, array<string, mixed>>|null
	 */
	private static ?array $map = null;

	/**
	 * Le regole raccolte finora, raggruppate per schermo e per selettore.
	 *
	 * @var array<string, array<string, array<string, string>>>
	 */
	private static array $collected = array();

	/**
	 * Gli identificativi gia' passati, per non scrivere due volte lo stesso blocco.
	 *
	 * @var array<string, true>
	 */
	private static array $seen = array();

	/**
	 * Caratteri ammessi in un valore CSS.
	 *
	 * Volutamente stretta: niente punto e virgola, parentesi graffe, virgolette
	 * o barre rovesciate, che sono gli attrezzi con cui si esce da una regola e
	 * se ne inietta un'altra.
	 */
	private const VALORE_AMMESSO = '/^[A-Za-z0-9 _.,%#()\/+*:|-]+$/';

	/**
	 * Impronte vietate dentro un valore, anche se composte di caratteri ammessi.
	 *
	 * I due delimitatori di commento CSS ci sono perche' la barra e l'asterisco
	 * servono ai calcoli (calc(100% / 3), calc(2rem * 2)) e quindi restano fra i
	 * caratteri ammessi: senza questo controllo un valore potrebbe aprire un
	 * commento e spegnere tutte le regole scritte dopo di lui.
	 */
	private const VALORE_VIETATO = array( 'javascript:', 'expression(', 'url(', '</', '/*', '*/' );

	// ---------------------------------------------------------------- configurazione

	/**
	 * Legge i punti di rottura in uso.
	 *
	 * @return array<string, int|null>
	 */
	public static function breakpoints(): array {
		return self::$breakpoints;
	}

	/**
	 * Cambia i punti di rottura. Tablet e telefono devono restare numeri positivi.
	 *
	 * @param array<string, int|null> $breakpoints Nuovi valori.
	 */
	public static function set_breakpoints( array $breakpoints ): void {
		foreach ( array( 'tablet', 'mobile' ) as $screen ) {
			if ( isset( $breakpoints[ $screen ] ) && is_int( $breakpoints[ $screen ] ) && $breakpoints[ $screen ] > 0 ) {
				self::$breakpoints[ $screen ] = $breakpoints[ $screen ];
			}
		}
	}

	/**
	 * Carica la tabella delle corrispondenze.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function map(): array {
		if ( null === self::$map ) {
			$file = dirname( __DIR__, 2 ) . '/shared/style-map.json';
			$raw  = is_readable( $file ) ? file_get_contents( $file ) : false;
			$data = false === $raw ? null : json_decode( $raw, true );

			self::$map = array();

			if ( is_array( $data ) ) {
				foreach ( $data as $path => $rule ) {
					// Le chiavi che iniziano con l'underscore sono note, non regole.
					if ( ! str_starts_with( (string) $path, '_' ) && is_array( $rule ) ) {
						self::$map[ (string) $path ] = $rule;
					}
				}
			}
		}

		return self::$map;
	}

	// ---------------------------------------------------------------- raccolta

	/**
	 * Garantisce un identificativo a un blocco che non ce l'ha.
	 *
	 * Succede quando un blocco viene salvato prima che l'editor abbia fatto in
	 * tempo ad assegnarglielo: l'assegnazione avviene dopo il primo disegno del
	 * blocco, quindi chi inserisce e salva nello stesso istante lo salta. A mano
	 * e' raro, ma e' esattamente quello che fara' il generatore di siti della
	 * Fase 4, che i blocchi li scrive di getto.
	 *
	 * Il guasto sarebbe silenzioso: nessun errore, solo un blocco senza nessuno
	 * dei suoi stili. Quindi qui, se manca, se ne ricava uno dal contenuto delle
	 * impostazioni. E' stabile (le stesse impostazioni danno sempre lo stesso
	 * identificativo) e due blocchi impostati uguale finiscono per condividere
	 * la stessa regola, che e' un piccolo guadagno in piu'.
	 *
	 * @param string               $emme_id Identificativo salvato, eventualmente vuoto.
	 * @param array<string, mixed> $style   Contenuto di emmeStyle.
	 * @return string L'identificativo da usare.
	 */
	public static function ensure_id( string $emme_id, array $style ): string {
		$pulito = self::clean_id( $emme_id );

		if ( '' !== $pulito ) {
			return $pulito;
		}

		if ( array() === $style ) {
			return '';
		}

		// json_encode e non wp_json_encode: questa classe non usa nessuna
		// funzione di WordPress, cosi si prova da sola.
		return substr( md5( (string) json_encode( $style ) ), 0, 8 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode -- la classe e volutamente indipendente da WordPress.
	}

	/**
	 * Aggiunge un blocco al foglio di stile della pagina.
	 *
	 * @param string               $emme_id Identificativo del blocco.
	 * @param array<string, mixed> $style   Contenuto di emmeStyle.
	 */
	public static function add( string $emme_id, array $style ): void {
		$emme_id = self::clean_id( $emme_id );

		if ( '' === $emme_id || isset( self::$seen[ $emme_id ] ) || array() === $style ) {
			return;
		}

		self::$seen[ $emme_id ] = true;

		foreach ( self::rules_for( $emme_id, $style ) as $screen => $selectors ) {
			foreach ( $selectors as $selector => $declarations ) {
				if ( array() === $declarations ) {
					continue;
				}

				self::$collected[ $screen ][ $selector ] = array_merge(
					self::$collected[ $screen ][ $selector ] ?? array(),
					$declarations
				);
			}
		}
	}

	/**
	 * Svuota tutto. Serve alle prove e fra una richiesta e l'altra.
	 */
	public static function reset(): void {
		self::$collected = array();
		self::$seen      = array();
	}

	/**
	 * Dice se c'e' qualcosa da scrivere.
	 */
	public static function is_empty(): bool {
		return array() === self::$collected;
	}

	// ---------------------------------------------------------------- calcolo

	/**
	 * Calcola tutte le regole di un blocco, divise per schermo e selettore.
	 *
	 * @param string               $emme_id Identificativo del blocco.
	 * @param array<string, mixed> $style   Contenuto di emmeStyle.
	 * @return array<string, array<string, array<string, string>>>
	 */
	public static function rules_for( string $emme_id, array $style ): array {
		$emme_id = self::clean_id( $emme_id );

		if ( '' === $emme_id ) {
			return array();
		}

		/*
		 * IL SELETTORE PORTA LA CLASSE DUE VOLTE, e non e' un errore.
		 *
		 * WordPress, dentro un contenitore «vincolato», azzera il margine di
		 * sopra del PRIMO figlio e quello di sotto dell'ULTIMO, con questa
		 * regola negli stili globali:
		 *
		 *   :root :where(.is-layout-constrained) > :last-child { margin-block-end: 0 }
		 *
		 * che ha forza 0,2,0 - `:root` piu' `:last-child`. Una regola nostra
		 * con una classe sola ha forza 0,1,0 e perde: il risultato e' che lo
		 * Spazio esterno impostato dal pannello **non fa niente** sul primo e
		 * sull'ultimo blocco di un contenitore, e non lo dice a nessuno.
		 *
		 * Successo il 10/11/2026: Manuel ha impostato 50 px sotto all'ultima
		 * fascia del M.L.E.E. e non e' cambiato nulla.
		 *
		 * Ripetendo la classe la forza diventa 0,2,0: pareggia, e a parita'
		 * vince chi viene dopo nella pagina - il nostro foglio e' stampato
		 * dopo quelli di WordPress (misurato: posizione 15 contro 11 e 12).
		 *
		 * Le regole sui FIGLI restano a forza zero con `:where()`: li' il
		 * problema e' l'opposto, e sta scritto poco piu' sotto.
		 */
		$classe = '.emme-b-' . $emme_id;
		$base   = $classe . $classe;
		$result = array();

		foreach ( array_keys( self::$breakpoints ) as $screen ) {
			$declarations = self::declarations( $style, $screen );
			$overlay      = 'desktop' === $screen ? self::overlay_declarations( $style ) : array();

			if ( array() !== $declarations ) {
				$result[ $screen ][ $base ] = $declarations;

				/*
				 * In un contenitore a flex o a griglia lo spazio fra i figli lo
				 * decide `gap`, e basta.
				 *
				 * I margini che il browser mette da solo agli heading e ai
				 * paragrafi si SOMMANO al gap invece di sparire, perche' fra
				 * fratelli di un contenitore flex i margini non collassano mai.
				 * Misurato il 09/11/2026 sulla Home della Cantamessa: fra un h6 e
				 * un h2 c'erano 41,94 + 24 di gap + 29,05 = 95 px di aria dove ne
				 * servivano 24, e tre fasce su quattro venivano alte un terzo piu'
				 * del sito che stavamo rifacendo.
				 *
				 * Solo flex e grid: in un contenitore a blocco i margini sono
				 * l'unico spazio che c'e', e toglierli attaccherebbe i paragrafi.
				 * Tocca solo i margini verticali: `margin: auto` sui lati, che e'
				 * il modo in cui si centra una colonna, resta dov'e'.
				 */
				$display = $declarations['display'] ?? '';

				if ( 'flex' === $display || 'grid' === $display ) {
					// `:where()` porta la forza del selettore a zero, se no questo reset
					// batterebbe il margine che qualcuno imposta dal pannello Spazio
					// esterno su un blocco dentro: i figli si scrivono PRIMA del
					// genitore - WordPress rende il contenuto interno per primo - e a
					// parita' di forza vince l'ultimo. Succeso il 10/11/2026 sulla
					// scheda finale della Cantamessa, dove un margine di 120 px non
					// faceva niente.
					$result[ $screen ][ ':where(' . $classe . ') > *' ] = array( 'margin-block' => '0' );
				}
			}

			if ( array() !== $overlay ) {
				$result[ $screen ][ $base . '::before' ] = $overlay;
			}

			// Sfondo e ombra da ancorata: un selettore a parte, che vale solo
			// mentre la classe c'e'. La mette e la toglie il JavaScript.
			$ancorata = 'desktop' === $screen ? self::scroll_pinned_declarations( $style ) : array();

			if ( array() !== $ancorata ) {
				$result[ $screen ][ $base . '.is-ancorata' ] = $ancorata;
			}
		}

		// Il passaggio del mouse non e' responsive: sul telefono non esiste.
		$hover = self::declarations( $style, 'desktop', 'hover' );

		if ( array() !== $hover ) {
			$result['desktop'][ $base . ':hover' ] = $hover;
		}

		return $result;
	}

	/**
	 * Calcola le dichiarazioni del selettore principale per un solo schermo.
	 *
	 * Regola di fondo: il desktop e la base e riceve anche tutte le proprieta
	 * non responsive; tablet e telefono ricevono solo cio' che e' stato indicato
	 * esplicitamente per loro.
	 *
	 * @param array<string, mixed> $style  Contenuto di emmeStyle.
	 * @param string               $screen desktop, tablet o mobile.
	 * @return array<string, string>
	 */
	public static function declarations( array $style, string $screen, string $state = '' ): array {
		$out = array();

		foreach ( self::map() as $path => $rule ) {
			// Ogni voce appartiene a uno stato: quello normale, oppure il
			// passaggio del mouse. Si mescolano solo se si chiede lo stesso.
			if ( ( isset( $rule['stato'] ) ? (string) $rule['stato'] : '' ) !== $state ) {
				continue;
			}

			$value = self::value_at( $style, $path );

			if ( null === $value ) {
				continue;
			}

			if ( self::is_responsive( $value ) ) {
				if ( ! array_key_exists( $screen, $value ) ) {
					continue;
				}
				$value = $value[ $screen ];
			} elseif ( 'desktop' !== $screen ) {
				continue;
			}

			$out = array_merge( $out, self::declarations_from_rule( $rule, $value ) );
		}

		// Casi particolari, che non stanno nella tabella.
		if ( 'hover' === $state ) {
			$out = array_merge( $out, self::hover_transform( $style ) );
			$out = array_merge( $out, self::hover_filter_declarations( $style ) );

			return $out;
		}

		// L'interruttore dello scorrimento e' responsive: una testata ancorata
		// su telefono mangia schermo, e spesso si spegne.
		$out = array_merge( $out, self::scroll_switch( $style, $screen ) );

		if ( 'desktop' === $screen ) {
			$out = array_merge( $out, self::scroll_declarations( $style ) );
			$out = array_merge( $out, self::image_declarations( $style ) );
			$out = array_merge( $out, self::filter_declarations( $style['filters'] ?? null ) );
			$out = array_merge( $out, self::animation_defaults( $style ) );
			$out = array_merge( $out, self::hover_transition( $style ) );
		}

		// La visibilita' va per ultima: scritta in fondo, vince sulle regole di sopra.
		if ( self::hidden_on( $style, $screen ) ) {
			$out['display'] = 'none';
		}

		return $out;
	}

	/**
	 * Durata e ritardo dell'animazione, scritti sempre quando c'e' un'animazione.
	 *
	 * Perche' sempre: sono variabili CSS, e le variabili CSS si ereditano. Un
	 * contenitore animato dentro un altro contenitore animato, senza una durata
	 * propria, si prenderebbe quella del padre invece della predefinita.
	 * Scrivendole sempre, l'eredita' non puo' sporcare niente.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return array<string, string>
	 */
	private static function animation_defaults( array $style ): array {
		$tipo = $style['animation']['type'] ?? '';

		if ( ! is_string( $tipo ) || '' === $tipo || 'none' === $tipo ) {
			return array();
		}

		// I limiti sono quelli della tabella, non ricopiati qui: questo metodo
		// scrive le stesse due proprieta' del giro automatico, e scrivendole
		// dopo le sovrascrive. Senza rileggere i limiti, un valore fuori scala
		// rientrerebbe proprio da questa porta - e un'animazione da cento
		// secondi tiene il contenuto invisibile per cento secondi.
		return array(
			'--emme-anim-durata'  => self::nei_limiti( 'animation.duration', $style['animation']['duration'] ?? null, 800 ) . 'ms',
			'--emme-anim-ritardo' => self::nei_limiti( 'animation.delay', $style['animation']['delay'] ?? null, 0 ) . 'ms',
		);
	}

	/**
	 * Un numero riportato dentro i limiti che la tabella dichiara.
	 *
	 * Fuori scala si torna al valore predefinito invece di tagliare al
	 * minimo o al massimo: un valore assurdo e' quasi sempre un errore o un
	 * tentativo, e in nessuno dei due casi si vuole indovinare cosa
	 * intendesse.
	 *
	 * @param string $percorso     Chiave della tabella.
	 * @param mixed  $valore       Valore grezzo.
	 * @param int    $predefinito  Valore da usare se non va bene.
	 * @return int Il numero da scrivere.
	 */
	private static function nei_limiti( string $percorso, mixed $valore, int $predefinito ): int {
		$regola = self::map()[ $percorso ] ?? array();

		if ( null === $valore || ! self::value_allowed( $regola, $valore ) ) {
			return $predefinito;
		}

		return (int) $valore;
	}

	/**
	 * I filtri grafici: bianco e nero, luminosita', saturazione, sfocatura.
	 *
	 * Sono quattro impostazioni distinte nell'editor ma una sola proprieta'
	 * CSS, che prende un elenco: filter: grayscale(100%) brightness(80%).
	 * Quindi vanno composte qui e non nella tabella, come il transform.
	 *
	 * L'ordine e' fisso. Non perche' il risultato cambi molto, ma perche' il
	 * CSS deve venire identico in PHP e in JavaScript, carattere per carattere.
	 *
	 * I valori neutri non si scrivono: il bianco e nero a zero e la luminosita'
	 * al cento per cento non fanno niente, e una dichiarazione che non fa
	 * niente e' solo peso in piu' su ogni pagina.
	 *
	 * @param mixed $filtri Il gruppo dei filtri, se c'e'.
	 * @return array<string, string>
	 */
	private static function filter_declarations( mixed $filtri ): array {
		if ( ! is_array( $filtri ) || array() === $filtri ) {
			return array();
		}

		// chiave => array( funzione CSS, unita', valore che non fa niente )
		$previsti = array(
			'grayscale'  => array( 'grayscale', '%', 0 ),
			'brightness' => array( 'brightness', '%', 100 ),
			'contrast'   => array( 'contrast', '%', 100 ),
			'saturate'   => array( 'saturate', '%', 100 ),
			'blur'       => array( 'blur', 'px', 0 ),
		);

		$pezzi = array();

		foreach ( $previsti as $chiave => $come ) {
			if ( ! isset( $filtri[ $chiave ] ) || ! is_numeric( $filtri[ $chiave ] ) ) {
				continue;
			}

			$valore = (float) $filtri[ $chiave ];

			if ( $valore === (float) $come[2] ) {
				continue;
			}

			// Niente zeri inutili in coda: 80 e non 80.000.
			$scritto = rtrim( rtrim( number_format( $valore, 2, '.', '' ), '0' ), '.' );

			$pezzi[] = $come[0] . '(' . $scritto . $come[1] . ')';
		}

		return array() === $pezzi ? array() : array( 'filter' => implode( ' ', $pezzi ) );
	}

	/**
	 * I filtri al passaggio del mouse.
	 *
	 * Non basta leggere il gruppo "hover": sul passaggio del mouse un valore
	 * neutro non vuol dire "non fare niente", vuol dire "annulla quello che
	 * c'era". La foto in bianco e nero che torna a colori e' esattamente
	 * questo: bianco e nero 100 normalmente, 0 al passaggio. Scartando gli
	 * zeri, come si fa nello stato normale, la regola non verrebbe scritta e
	 * l'effetto non si vedrebbe.
	 *
	 * Quindi si parte dai filtri normali e ci si scrivono sopra quelli del
	 * mouse. Un filtro che il mouse non nomina resta com'era: chi mette una
	 * sfocatura e poi toglie solo il bianco e nero si aspetta che la sfocatura
	 * rimanga.
	 *
	 * E se dopo la fusione non resta niente da applicare, si scrive
	 * "filter: none": senza, resterebbe in vigore quello dello stato normale.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return array<string, string>
	 */
	private static function hover_filter_declarations( array $style ): array {
		$sopra = $style['hover']['filters'] ?? null;

		if ( ! is_array( $sopra ) || array() === $sopra ) {
			return array();
		}

		$sotto  = is_array( $style['filters'] ?? null ) ? $style['filters'] : array();
		$uniti  = array_merge( $sotto, $sopra );
		$uscita = self::filter_declarations( $uniti );

		if ( array() !== $uscita ) {
			return $uscita;
		}

		// Niente da applicare: serve comunque annullare quello di sotto.
		return array() === self::filter_declarations( $sotto ) ? array() : array( 'filter' => 'none' );
	}

	/**
	 * Sollevamento e ingrandimento al passaggio del mouse.
	 *
	 * Sono due impostazioni distinte nell'editor ma una sola proprieta' CSS,
	 * quindi vanno composte qui invece che nella tabella.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return array<string, string>
	 */
	private static function hover_transform( array $style ): array {
		$pezzi = array();

		$lift = $style['hover']['lift'] ?? null;

		if ( null !== $lift ) {
			$clean = self::clean_value( $lift );

			if ( null !== $clean ) {
				$pezzi[] = 'translateY(-' . $clean . ')';
			}
		}

		$scale = $style['hover']['scale'] ?? null;

		if ( is_numeric( $scale ) ) {
			$pezzi[] = 'scale(' . self::numero( $scale ) . ')';
		}

		// La rotazione piatta: un paio di gradi bastano, e sulle fotografie
		// danno l'idea della stampa appoggiata storta che si raddrizza.
		$rotate = $style['hover']['rotate'] ?? null;

		if ( is_numeric( $rotate ) && 0.0 !== (float) $rotate ) {
			$pezzi[] = 'rotate(' . self::numero( $rotate ) . 'deg)';
		}

		// L'inclinazione nello spazio. La prospettiva va messa per prima
		// nell'elenco, altrimenti non si applica alle rotazioni che seguono:
		// l'ordine dentro transform conta, e si legge da destra a sinistra.
		$tilt = $style['hover']['tilt'] ?? null;

		if ( is_numeric( $tilt ) && 0.0 !== (float) $tilt ) {
			array_unshift( $pezzi, 'perspective(800px)' );
			$pezzi[] = 'rotateX(' . self::numero( $tilt ) . 'deg)';
		}

		return array() === $pezzi ? array() : array( 'transform' => implode( ' ', $pezzi ) );
	}

	/**
	 * Un numero scritto senza zeri inutili in coda: 1.04 e non 1.040.
	 *
	 * @param mixed $valore Numero grezzo.
	 * @return string Il numero scritto.
	 */
	private static function numero( mixed $valore ): string {
		return rtrim( rtrim( number_format( (float) $valore, 3, '.', '' ), '0' ), '.' );
	}

	/**
	 * La transizione che rende morbido il passaggio del mouse.
	 *
	 * Si elencano solo le proprieta' che cambiano davvero: "transition: all"
	 * farebbe lavorare il browser anche su cose che non si muovono.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return array<string, string>
	 */
	private static function hover_transition( array $style ): array {
		$hover = $style['hover'] ?? null;

		if ( ! is_array( $hover ) || array() === $hover ) {
			return array();
		}

		$proprieta = array(
			'background'  => 'background-color',
			'color'       => 'color',
			'borderColor' => 'border-color',
			'shadow'      => 'box-shadow',
			'opacity'     => 'opacity',
			'lift'        => 'transform',
			'scale'       => 'transform',
			'rotate'      => 'transform',
			'tilt'        => 'transform',
			'filters'     => 'filter',
		);

		$elenco = array();

		foreach ( $proprieta as $chiave => $css ) {
			if ( isset( $hover[ $chiave ] ) && ! in_array( $css, $elenco, true ) ) {
				$elenco[] = $css;
			}
		}

		if ( array() === $elenco ) {
			return array();
		}

		/*
		 * LA CURVA DEL TEMPO.
		 *
		 * Era inchiodata a `ease`. Non e' un dettaglio: a parita' di durata
		 * una curva che parte svelta e rallenta si legge piu' rapida di una
		 * simmetrica, ed e' la stessa cosa che si puo' gia' scegliere per le
		 * comparse. Le voci offerte dal pannello sono le stesse quattro, per
		 * non far imparare due vocabolari.
		 *
		 * Si ripulisce come ogni altro valore: questa proprieta' non passa
		 * dalla tabella, quindi il controllo va fatto qui.
		 */
		$curva = isset( $hover['easing'] ) ? self::clean_value( (string) $hover['easing'] ) : null;

		// Nessun bisogno di aggiungere qui le proprieta' dell'animazione di
		// comparsa: da quando la comparsa usa un'animazione invece di una
		// transizione, le due cose non si toccano piu'.
		return array(
			'transition-property'        => implode( ',', $elenco ),
			'transition-duration'        => 'var(--emme-hover-durata, 300ms)',
			'transition-timing-function' => null === $curva ? 'ease' : $curva,
		);
	}

	/**
	 * Controlla che un valore sia fra quelli che la tabella dichiara ammessi.
	 *
	 * Lo schema dichiara chiuse sedici proprieta' — quali disposizioni
	 * esistono, quali stili di bordo, quanto puo' valere uno z-index — ma lo
	 * schema e' un documento: non viene letto mentre si costruisce la pagina.
	 * Finche' il controllo stava solo li', chiunque potesse salvare il
	 * contenuto di una pagina poteva scrivere nel blocco un valore fuori
	 * elenco e vederselo uscire in CSS.
	 *
	 * Non si trattava di inserire CSS arbitrario: clean_value() rifiuta gia'
	 * il punto e virgola, le graffe e le virgolette, quindi non si puo' uscire
	 * dalla dichiarazione. Si trattava di abusare delle proprieta' dichiarate:
	 * con "position: fixed", una distanza zero e uno z-index altissimo si
	 * copre tutta la pagina con un pannello trasparente, e un utente con pochi
	 * permessi puo' metterlo davanti a quello che vedono gli altri.
	 *
	 * Da qui in poi l'elenco vive nella tabella, accanto alla regola, e vale
	 * davvero. Una prova controlla che resti uguale a quello dello schema.
	 *
	 * @param array<string, mixed> $rule  Voce della tabella.
	 * @param mixed                $value Valore gia' scelto per lo schermo.
	 * @return bool Vero se il valore puo' passare.
	 */
	private static function value_allowed( array $rule, mixed $value ): bool {
		if ( isset( $rule['valori'] ) && is_array( $rule['valori'] ) ) {
			// Il confronto e' su stringa perche' dal contenuto della pagina un
			// numero puo' arrivare sia come 400 sia come "400".
			return in_array( (string) $value, array_map( 'strval', $rule['valori'] ), true );
		}

		if ( isset( $rule['minimo'] ) || isset( $rule['massimo'] ) ) {
			if ( ! is_numeric( $value ) ) {
				return false;
			}

			$numero = (float) $value;

			if ( isset( $rule['minimo'] ) && $numero < (float) $rule['minimo'] ) {
				return false;
			}

			if ( isset( $rule['massimo'] ) && $numero > (float) $rule['massimo'] ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Trasforma una singola voce della tabella nelle sue dichiarazioni.
	 *
	 * @param array<string, mixed> $rule  Voce della tabella.
	 * @param mixed                $value Valore gia' scelto per lo schermo.
	 * @return array<string, string>
	 */
	private static function declarations_from_rule( array $rule, mixed $value ): array {
		// Prima di tutto: il valore e' fra quelli ammessi? Vedi value_allowed().
		// I valori composti (quattro lati, quattro angoli) non hanno elenchi:
		// il controllo scatta solo dove la tabella ne dichiara uno.
		if ( ! is_array( $value ) && ! self::value_allowed( $rule, $value ) ) {
			return array();
		}

		// Proprieta' a quattro angoli: un valore solo vale per tutti, un oggetto
		// permette di arrotondarne alcuni e lasciarne altri squadrati.
		if ( isset( $rule['corners'] ) && is_array( $value ) ) {
			$angoli = array(
				'topLeft'     => 'top-left',
				'topRight'    => 'top-right',
				'bottomRight' => 'bottom-right',
				'bottomLeft'  => 'bottom-left',
			);

			$out = array();

			foreach ( $angoli as $chiave => $css ) {
				if ( ! isset( $value[ $chiave ] ) ) {
					continue;
				}

				$clean = self::clean_value( $value[ $chiave ] );

				if ( null !== $clean ) {
					$out[ str_replace( '{corner}', $css, (string) $rule['corners'] ) ] = $clean;
				}
			}

			return $out;
		}

		// Proprieta' a quattro lati: produce una dichiarazione per ogni lato indicato.
		if ( isset( $rule['box'] ) && is_array( $value ) ) {
			$out = array();

			foreach ( array( 'top', 'right', 'bottom', 'left' ) as $side ) {
				if ( ! isset( $value[ $side ] ) ) {
					continue;
				}

				$clean = self::clean_value( $value[ $side ] );

				if ( null !== $clean ) {
					$out[ str_replace( '{side}', $side, (string) $rule['box'] ) ] = $clean;
				}
			}

			return $out;
		}

		if ( ! isset( $rule['css'] ) || is_array( $value ) ) {
			return array();
		}

		$raw = is_bool( $value ) ? ( $value ? 'true' : 'false' ) : (string) $value;

		// Traduzione dei valori, dove il nome dell'editor non e' quello del CSS.
		$translated = isset( $rule['map'] ) && is_array( $rule['map'] ) && isset( $rule['map'][ $raw ] )
			? (string) $rule['map'][ $raw ]
			: $raw;

		if ( isset( $rule['format'] ) ) {
			$translated = str_replace( '{v}', $translated, (string) $rule['format'] );
		}

		$clean = self::clean_value( $translated );

		if ( null === $clean ) {
			return array();
		}

		$out = array( (string) $rule['css'] => $clean );

		// Regole aggiuntive legate a un valore preciso, per esempio la griglia a 12 colonne.
		if ( isset( $rule['extra'][ $raw ] ) && is_array( $rule['extra'][ $raw ] ) ) {
			foreach ( $rule['extra'][ $raw ] as $property => $extra_value ) {
				$extra_clean = self::clean_value( $extra_value );

				if ( null !== $extra_clean ) {
					$out[ (string) $property ] = $extra_clean;
				}
			}
		}

		return $out;
	}

	/**
	 * Sfondo immagine: da un oggetto solo nascono piu' proprieta'.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return array<string, string>
	 */
	private static function image_declarations( array $style ): array {
		$image = $style['background']['image'] ?? null;

		if ( ! is_array( $image ) || empty( $image['url'] ) ) {
			return array();
		}

		$url = self::clean_url( (string) $image['url'] );

		if ( null === $url ) {
			return array();
		}

		$out = array( 'background-image' => 'url(' . $url . ')' );

		$semplici = array(
			'size'       => 'background-size',
			'position'   => 'background-position',
			'repeat'     => 'background-repeat',
			'attachment' => 'background-attachment',
		);

		foreach ( $semplici as $key => $property ) {
			if ( ! isset( $image[ $key ] ) ) {
				continue;
			}

			$clean = self::clean_value( $image[ $key ] );

			if ( null !== $clean ) {
				$out[ $property ] = $clean;
			}
		}

		return $out;
	}

	/**
	 * Velo colorato sopra lo sfondo: vive su uno pseudo-elemento.
	 *
	 * La struttura (posizione, dimensioni) sta nel foglio di stile del blocco:
	 * qui nascono solo colore e trasparenza, che cambiano da blocco a blocco.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return array<string, string>
	 */
	/**
	 * L'interruttore dello scorrimento, uno per schermo.
	 *
	 * Il JavaScript legge questa variabile per sapere se su questo schermo
	 * deve ancorare o no: e' l'unica proprieta responsive del gruppo, perche
	 * una testata ancorata su telefono mangia meta dello spazio utile.
	 *
	 * @param array<string, mixed> $style  Contenuto di emmeStyle.
	 * @param string               $screen desktop, tablet o mobile.
	 * @return array<string, string>
	 */
	private static function scroll_switch( array $style, string $screen ): array {
		$pin = $style['scroll']['pin'] ?? null;

		if ( ! is_array( $pin ) || ! array_key_exists( $screen, $pin ) ) {
			return array();
		}

		return array( '--emme-anc-on' => $pin[ $screen ] ? '1' : '0' );
	}

	/**
	 * Le misure dello scorrimento, scritte come variabili.
	 *
	 * Qui nascono solo i NUMERI: dove si ferma mentre si riduce, quanto resta
	 * del contenuto, quanto sta sopra al resto. Il comportamento - cioe quando
	 * ancorare e di quanto ridurre - lo fa `shared/testata-ancorata.js`, che
	 * aggiorna una sola variabile mentre si scorre.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return array<string, string>
	 */
	private static function scroll_declarations( array $style ): array {
		$scroll = $style['scroll'] ?? null;

		if ( ! is_array( $scroll ) ) {
			return array();
		}

		$out = array();

		foreach ( array( 'minHeight' => '--emme-anc-hmin', 'top' => '--emme-anc-top', 'threshold' => '--emme-anc-soglia' ) as $chiave => $variabile ) {
			if ( ! isset( $scroll[ $chiave ] ) ) {
				continue;
			}

			$pulito = self::clean_value( $scroll[ $chiave ] );

			if ( null !== $pulito ) {
				$out[ $variabile ] = $pulito;
			}
		}

		// Quanto resta del contenuto: un numero fra 0,1 e 1, non una misura.
		if ( isset( $scroll['contentMin'] ) && is_numeric( $scroll['contentMin'] ) ) {
			$quota = max( 0.1, min( 1.0, (float) $scroll['contentMin'] ) );
			$out['--emme-anc-pmin'] = rtrim( rtrim( number_format( $quota, 2, '.', '' ), '0' ), '.' ) ?: '0';
		}

		if ( isset( $scroll['zIndex'] ) && is_numeric( $scroll['zIndex'] ) ) {
			$out['--emme-anc-z'] = (string) max( 0, min( 999, (int) $scroll['zIndex'] ) );
		}

		return $out;
	}

	/**
	 * Sfondo e ombra della barra mentre e ancorata.
	 *
	 * Vanno su un selettore a parte perche valgono solo mentre la classe
	 * `is-ancorata` c'e'. Una testata puo essere trasparente a riposo e
	 * diventare piena quando si stacca: e il caso piu chiesto, e senza uno
	 * sfondo pieno il contenuto le scorre sotto e si legge attraverso.
	 *
	 * @param array<string, mixed> $style Contenuto di emmeStyle.
	 * @return array<string, string>
	 */
	private static function scroll_pinned_declarations( array $style ): array {
		$scroll = $style['scroll'] ?? null;

		if ( ! is_array( $scroll ) ) {
			return array();
		}

		$out = array();

		if ( isset( $scroll['background'] ) ) {
			$pulito = self::clean_value( $scroll['background'] );

			if ( null !== $pulito ) {
				$out['background-color'] = $pulito;
			}
		}

		if ( isset( $scroll['shadow'] ) ) {
			$pulito = self::clean_value( $scroll['shadow'] );

			if ( null !== $pulito ) {
				$out['box-shadow'] = $pulito;
			}
		}

		return $out;
	}

	private static function overlay_declarations( array $style ): array {
		$overlay = $style['background']['overlay'] ?? null;

		if ( ! is_array( $overlay ) ) {
			return array();
		}

		$out = array();

		if ( isset( $overlay['color'] ) ) {
			$clean = self::clean_value( $overlay['color'] );

			if ( null !== $clean ) {
				$out['background-color'] = $clean;
			}
		}

		if ( isset( $overlay['opacity'] ) && is_numeric( $overlay['opacity'] ) ) {
			$opacity = max( 0.0, min( 1.0, (float) $overlay['opacity'] ) );
			$out['opacity'] = rtrim( rtrim( number_format( $opacity, 2, '.', '' ), '0' ), '.' ) ?: '0';
		}

		return $out;
	}

	/**
	 * Dice se il blocco va nascosto su questo schermo.
	 *
	 * @param array<string, mixed> $style  Contenuto di emmeStyle.
	 * @param string               $screen desktop, tablet o mobile.
	 */
	private static function hidden_on( array $style, string $screen ): bool {
		$hide = $style['visibility']['hideOn'] ?? null;

		return is_array( $hide ) && in_array( $screen, $hide, true );
	}

	// ---------------------------------------------------------------- scrittura

	/**
	 * Scrive il foglio di stile di tutti i blocchi raccolti.
	 *
	 * Prima il desktop, poi i punti di rottura dal piu' largo al piu' stretto:
	 * cosi' le regole piu' specifiche vengono dopo e vincono.
	 */
	public static function stylesheet(): string {
		return self::assemble( self::$collected );
	}

	/**
	 * Il foglio di stile di un blocco solo.
	 *
	 * E' il gemello esatto di foglioBlocco() in src/lib/css.js, ed e' quello
	 * che l'editor usa per mostrare l'anteprima. Esiste anche qui perche' le
	 * prove possano confrontare carattere per carattere quello che producono i
	 * due generatori: se divergono, l'anteprima mente e il gate della Fase 1
	 * non e' superato.
	 *
	 * @param string               $emme_id Identificativo del blocco.
	 * @param array<string, mixed> $style   Contenuto di emmeStyle.
	 */
	public static function block_stylesheet( string $emme_id, array $style ): string {
		return self::assemble( self::rules_for( $emme_id, $style ) );
	}

	/**
	 * Mette in fila desktop e punti di rottura.
	 *
	 * @param array<string, array<string, array<string, string>>> $per_screen Regole per schermo.
	 */
	private static function assemble( array $per_screen ): string {
		$css = self::block_from( $per_screen['desktop'] ?? array() );

		foreach ( array( 'tablet', 'mobile' ) as $screen ) {
			$inner = self::block_from( $per_screen[ $screen ] ?? array() );

			if ( '' !== $inner ) {
				$css .= '@media (max-width:' . (int) self::$breakpoints[ $screen ] . 'px){' . $inner . '}';
			}
		}

		return $css;
	}

	/**
	 * Mette in fila i selettori di un gruppo.
	 *
	 * @param array<string, array<string, string>> $selectors Selettori e dichiarazioni.
	 */
	private static function block_from( array $selectors ): string {
		$css = '';

		foreach ( $selectors as $selector => $declarations ) {
			if ( array() === $declarations ) {
				continue;
			}

			$body = '';

			foreach ( $declarations as $property => $value ) {
				$body .= $property . ':' . $value . ';';
			}

			$css .= $selector . '{' . $body . '}';
		}

		return $css;
	}

	// ---------------------------------------------------------------- utilita'

	/**
	 * Pesca un valore annidato seguendo un percorso puntato.
	 *
	 * @param array<string, mixed> $data Struttura da cui pescare.
	 * @param string               $path Percorso, per esempio "spacing.padding".
	 */
	private static function value_at( array $data, string $path ): mixed {
		$current = $data;

		foreach ( explode( '.', $path ) as $key ) {
			if ( ! is_array( $current ) || ! array_key_exists( $key, $current ) ) {
				return null;
			}

			$current = $current[ $key ];
		}

		return $current;
	}

	/**
	 * Dice se un valore e' responsive, cioe' se parla per schermo.
	 *
	 * @param mixed $value Valore da esaminare.
	 */
	private static function is_responsive( mixed $value ): bool {
		if ( ! is_array( $value ) ) {
			return false;
		}

		foreach ( array( 'desktop', 'tablet', 'mobile' ) as $screen ) {
			if ( array_key_exists( $screen, $value ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Ripulisce un identificativo di blocco.
	 */
	private static function clean_id( string $emme_id ): string {
		return (string) preg_replace( '/[^a-z0-9]/', '', strtolower( $emme_id ) );
	}

	/**
	 * Controlla un valore CSS e lo converte se e' un riferimento a un preset.
	 *
	 * Restituisce null se il valore non e' accettabile: meglio non scrivere
	 * niente che scrivere una regola di cui non ci fidiamo.
	 *
	 * @param mixed $value Valore grezzo.
	 */
	public static function clean_value( mixed $value ): ?string {
		if ( is_int( $value ) || is_float( $value ) ) {
			$value = (string) $value;
		}

		if ( ! is_string( $value ) || '' === trim( $value ) ) {
			return null;
		}

		$value = trim( $value );

		if ( strlen( $value ) > 200 ) {
			return null;
		}

		foreach ( self::VALORE_VIETATO as $vietato ) {
			if ( false !== stripos( $value, $vietato ) ) {
				return null;
			}
		}

		if ( ! preg_match( self::VALORE_AMMESSO, $value ) ) {
			return null;
		}

		if ( ! self::parentheses_balanced( $value ) ) {
			return null;
		}

		return self::resolve_preset( $value );
	}

	/**
	 * Controlla che le parentesi tonde siano in pari.
	 *
	 * Una parentesi lasciata aperta, o una chiusa di troppo, significa che il
	 * valore sta provando a uscire dalla funzione in cui dovrebbe stare.
	 */
	private static function parentheses_balanced( string $value ): bool {
		$depth = 0;

		for ( $i = 0, $len = strlen( $value ); $i < $len; $i++ ) {
			if ( '(' === $value[ $i ] ) {
				++$depth;
			} elseif ( ')' === $value[ $i ] ) {
				--$depth;

				if ( $depth < 0 ) {
					return false;
				}
			}
		}

		return 0 === $depth;
	}

	/**
	 * Trasforma var:preset|color|primary in var(--wp--preset--color--primary).
	 *
	 * E' la stessa regola che applica WordPress: togliere "var:", sostituire
	 * ogni "|" con "--", avvolgere in var(--wp--...).
	 */
	public static function resolve_preset( string $value ): string {
		if ( ! str_starts_with( $value, 'var:' ) ) {
			return $value;
		}

		return 'var(--wp--' . str_replace( '|', '--', substr( $value, 4 ) ) . ')';
	}

	/**
	 * Controlla un indirizzo di immagine.
	 *
	 * Ammette solo indirizzi http, https o relativi alla radice del sito.
	 */
	private static function clean_url( string $url ): ?string {
		$url = trim( $url );

		if ( '' === $url || strlen( $url ) > 600 ) {
			return null;
		}

		// Delimitatore ~ e non #, perche' il cancelletto compare fra i caratteri ammessi.
		if ( ! preg_match( '~^(https?://|/)[A-Za-z0-9_.,%#()/+:?&=-]+$~', $url ) ) {
			return null;
		}

		return $url;
	}
}
