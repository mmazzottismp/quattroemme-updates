<?php
/**
 * Carica le traduzioni del plugin.
 *
 * Le stringhe sorgente sono in inglese, che e' la convenzione di gettext e di
 * WordPress, e l'italiano e' una traduzione come le altre. Chi lavora in un
 * sito italiano vede italiano, chi lo mette in tedesco vede inglese finche'
 * il tedesco non esiste. La lingua la sceglie WordPress, da Impostazioni >
 * Generali per il sito e da Utenti > Profilo per la singola persona: non
 * serve nessun pannello nostro, e farne uno litigherebbe con il suo.
 *
 * PERCHE' SERVE QUESTA CLASSE
 *
 * Un plugin pubblicato su wordpress.org non ha bisogno di niente: WordPress
 * scarica le traduzioni da solo. Il nostro no, sta su uno scaffale nostro,
 * quindi le traduzioni viaggiano dentro il pacchetto e vanno indicate a mano.
 * Due volte, perche' il PHP e il JavaScript hanno due strade diverse:
 *
 * 1. Il PHP: `load_plugin_textdomain`, che indica la cartella languages/.
 *
 * 2. Il JavaScript: quando registra un blocco, il core chiama da solo
 *    `wp_set_script_translations` ma SENZA dirgli dove cercare
 *    (wp-includes/blocks.php, riga 322 nella 7.1), quindi cerca solo in
 *    wp-content/languages/plugins/ — dove i nostri file non ci sono mai.
 *    Va richiamata indicando la nostra cartella.
 *
 * I nomi dei file li decide WordPress, non noi: per il PHP
 * `emme-blocks-it_IT.l10n.php`, per ogni script
 * `emme-blocks-it_IT-<md5 del percorso dentro il plugin>.json`. Li produce
 * `npm run traduzioni`.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

use WP_Block_Type_Registry;

/**
 * Dice a WordPress dove sono le traduzioni di questo plugin.
 */
final class Traduzioni {

	/**
	 * Cartella delle traduzioni, dentro il plugin.
	 */
	public const CARTELLA = 'languages';

	/**
	 * Dominio con cui sono marcate tutte le stringhe.
	 */
	public const DOMINIO = 'emme-blocks';

	/**
	 * Aggancia le due chiamate.
	 *
	 * Tutte e due su `init`, e quella sugli script dopo la registrazione dei
	 * blocchi: prima che i blocchi esistano non c'e' niente da ripuntare.
	 */
	public static function init(): void {
		add_action( 'init', array( self::class, 'carica_php' ) );
		add_action( 'init', array( self::class, 'carica_javascript' ), 20 );
	}

	/**
	 * Le traduzioni del PHP.
	 */
	public static function carica_php(): void {
		load_plugin_textdomain(
			self::DOMINIO,
			false,
			dirname( plugin_basename( EMME_BLOCKS_PATH . 'emme-blocks.php' ) ) . '/' . self::CARTELLA
		);
	}

	/**
	 * Le traduzioni del JavaScript, una per ogni script dei nostri blocchi.
	 */
	public static function carica_javascript(): void {
		$cartella = EMME_BLOCKS_PATH . self::CARTELLA;

		if ( ! is_dir( $cartella ) ) {
			return;
		}

		foreach ( self::handle_degli_script() as $handle ) {
			wp_set_script_translations( $handle, self::DOMINIO, $cartella );
		}
	}

	/**
	 * Gli handle degli script dei nostri blocchi.
	 *
	 * Si leggono dal registro invece di ricostruirli dal nome del blocco: il
	 * modo in cui il core li compone e' affar suo e puo' cambiare, mentre
	 * `editor_script_handles` e' una proprieta' pubblica di WP_Block_Type.
	 *
	 * @return string[] Gli handle, senza ripetizioni.
	 */
	private static function handle_degli_script(): array {
		$handle = array();

		foreach ( WP_Block_Type_Registry::get_instance()->get_all_registered() as $nome => $tipo ) {
			if ( ! str_starts_with( $nome, 'emme/' ) ) {
				continue;
			}

			foreach ( array( 'editor_script_handles', 'script_handles', 'view_script_handles' ) as $proprieta ) {
				foreach ( (array) ( $tipo->$proprieta ?? array() ) as $uno ) {
					$handle[ $uno ] = true;
				}
			}
		}

		return array_keys( $handle );
	}
}
