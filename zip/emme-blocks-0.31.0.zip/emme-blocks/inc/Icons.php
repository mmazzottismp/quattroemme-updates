<?php
/**
 * La libreria di icone di quattroemme.
 *
 * Le icone stanno in shared/icone.json: ogni voce contiene gia' il disegno,
 * cioe' quello che sta dentro il tag <svg> di Lucide. Qui si legge quel file e
 * si costruisce il tag completo, che viene scritto direttamente nella pagina.
 *
 * Perche' scriverle nella pagina invece di caricare un file o un font:
 *
 * - nessuna richiesta in piu' al server, quindi nessuna attesa;
 * - l'icona prende il colore del testo che la circonda, da sola;
 * - niente dipende da servizi esterni, come vuole il progetto.
 *
 * Come il generatore CSS, questa classe non usa nessuna funzione di
 * WordPress: cosi' si puo' provare da sola. Le prove stanno in
 * tests/prove-icone.php.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Legge la libreria di icone e ne costruisce il disegno.
 */
final class Icons {

	/**
	 * Il contenuto del file, letto una volta sola.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $data = null;

	/**
	 * Caratteri ammessi in una classe CSS passata da fuori.
	 */
	private const CLASSE_AMMESSA = '/^[A-Za-z0-9 _-]*$/';

	/**
	 * Gli spessori di tratto previsti.
	 *
	 * Lucide disegna a 2. Sotto il 2 l'icona si alleggerisce e sta meglio
	 * accanto a un testo elegante; sopra regge meglio quando e' piccola.
	 */
	private const SPESSORI = array( '1', '1.25', '1.5', '1.75', '2', '2.5', '3' );

	/**
	 * Attributi fissi del tag svg, nell'ordine in cui vengono scritti.
	 *
	 * Sono quelli di Lucide: riquadro 24 per 24, nessun riempimento, tratto
	 * del colore del testo. La larghezza e l'altezza non stanno qui perche'
	 * le decide il foglio di stile, in modo che l'icona cresca insieme al
	 * testo accanto a cui sta.
	 *
	 * @var array<string, string>
	 */
	private const ATTRIBUTI = array(
		'xmlns'            => 'http://www.w3.org/2000/svg',
		'viewBox'          => '0 0 24 24',
		'fill'             => 'none',
		'stroke'           => 'currentColor',
		'stroke-width'     => '2',
		'stroke-linecap'   => 'round',
		'stroke-linejoin'  => 'round',
		'aria-hidden'      => 'true',
		'focusable'        => 'false',
	);

	/**
	 * Tutte le icone, con nome e gruppo.
	 *
	 * @return array<string, array<string, string>> Chiave: il nome breve dell'icona.
	 */
	public static function all(): array {
		$dati = self::load();

		return isset( $dati['icone'] ) && is_array( $dati['icone'] ) ? $dati['icone'] : array();
	}

	/**
	 * I gruppi in cui sono divise, nell'ordine in cui vanno mostrati.
	 *
	 * @return array<string, string> Chiave: nome breve del gruppo; valore: etichetta.
	 */
	public static function groups(): array {
		$dati = self::load();

		return isset( $dati['_gruppi'] ) && is_array( $dati['_gruppi'] ) ? $dati['_gruppi'] : array();
	}

	/**
	 * Dice se un'icona esiste nella libreria.
	 *
	 * @param string $slug Nome breve dell'icona.
	 * @return bool Vero se c'e'.
	 */
	public static function exists( string $slug ): bool {
		return isset( self::all()[ $slug ] );
	}

	/**
	 * Costruisce il disegno di un'icona, pronto da scrivere nella pagina.
	 *
	 * Restituisce la stringa vuota se l'icona non esiste: un nome sbagliato
	 * non deve mai diventare un buco nella pagina o, peggio, un pezzo di
	 * codice arrivato da fuori.
	 *
	 * @param string $slug     Nome breve dell'icona.
	 * @param string $classe   Classi CSS da mettere sul tag svg.
	 * @param string $spessore Spessore del tratto. Vuoto significa quello di Lucide.
	 * @return string Il tag svg completo, oppure la stringa vuota.
	 */
	public static function svg( string $slug, string $classe = '', string $spessore = '' ): string {
		$icone = self::all();

		if ( ! isset( $icone[ $slug ]['corpo'] ) || ! is_string( $icone[ $slug ]['corpo'] ) ) {
			return '';
		}

		$attributi = self::ATTRIBUTI;

		if ( '' !== $classe && 1 === preg_match( self::CLASSE_AMMESSA, $classe ) ) {
			$attributi['class'] = $classe;
		}

		// Lo spessore si accetta solo fra quelli previsti: finisce dentro un
		// attributo, e un attributo che arriva da fuori non si scrive mai come
		// arriva.
		if ( in_array( $spessore, self::SPESSORI, true ) ) {
			$attributi['stroke-width'] = $spessore;
		}

		$scritti = '';

		foreach ( $attributi as $nome => $valore ) {
			$scritti .= ' ' . $nome . '="' . $valore . '"';
		}

		return '<svg' . $scritti . '>' . $icone[ $slug ]['corpo'] . '</svg>';
	}

	/**
	 * Legge il file, una volta sola per richiesta.
	 *
	 * @return array<string, mixed> Il contenuto, oppure un array vuoto.
	 */
	private static function load(): array {
		if ( null !== self::$data ) {
			return self::$data;
		}

		self::$data = array();

		$file = dirname( __DIR__ ) . '/shared/icone.json';

		if ( ! is_readable( $file ) ) {
			return self::$data;
		}

		$letto = json_decode( (string) file_get_contents( $file ), true );

		if ( is_array( $letto ) ) {
			self::$data = $letto;
		}

		return self::$data;
	}
}
