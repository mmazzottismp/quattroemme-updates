<?php
/**
 * Il contrasto fra due colori, calcolato.
 *
 * Il contrasto non si giudica a occhio: due grigi che allo schermo sembrano
 * diversissimi possono stare sotto la soglia, e un giallo acceso su bianco —
 * che sembra squillante — e' praticamente illeggibile.
 *
 * La formula e' quella delle WCAG 2.1: si converte ogni canale dal valore
 * dello schermo alla luce che emette davvero (la "luminanza relativa"), si
 * pesano i tre canali — il verde conta sette volte il blu, perche' l'occhio
 * e' fatto cosi' — e si confrontano le due luminanze.
 *
 *   https://www.w3.org/TR/WCAG21/#dfn-relative-luminance
 *   https://www.w3.org/TR/WCAG21/#dfn-contrast-ratio
 *
 * Il risultato va da 1 (due colori identici) a 21 (nero su bianco). La soglia
 * di legge per il testo normale e' 4,5.
 *
 * Il gemello in JavaScript e' src/lib/contrasto.js, e una prova controlla che
 * i due diano lo stesso numero: stessa regola dei due generatori di CSS.
 *
 * Come Sfondi e Animazioni, questa classe non usa nessuna funzione di
 * WordPress, cosi' si prova da sola.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Calcola il contrasto e lo confronta con le soglie.
 */
final class Contrasto {

	/**
	 * Il contenuto di coppie-colore.json, letto una volta sola.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $data = null;

	/**
	 * Da un colore scritto in esadecimale ai suoi tre canali, da 0 a 255.
	 *
	 * Accetta `#rgb` e `#rrggbb`, con o senza cancelletto. Se il colore non e'
	 * in una di queste due forme restituisce null: non si inventa un valore,
	 * perche' un contrasto calcolato su un colore frainteso e' peggio di un
	 * contrasto non calcolato.
	 *
	 * @param string $colore Il colore.
	 * @return array{0: int, 1: int, 2: int}|null I tre canali, oppure null.
	 */
	public static function canali( string $colore ): ?array {
		$pulito = strtolower( ltrim( trim( $colore ), '#' ) );

		if ( 3 === strlen( $pulito ) && ctype_xdigit( $pulito ) ) {
			// #abc vale #aabbcc: ogni cifra si raddoppia.
			$pulito = $pulito[0] . $pulito[0] . $pulito[1] . $pulito[1] . $pulito[2] . $pulito[2];
		}

		if ( 6 !== strlen( $pulito ) || ! ctype_xdigit( $pulito ) ) {
			return null;
		}

		return array(
			(int) hexdec( substr( $pulito, 0, 2 ) ),
			(int) hexdec( substr( $pulito, 2, 2 ) ),
			(int) hexdec( substr( $pulito, 4, 2 ) ),
		);
	}

	/**
	 * La luminanza relativa: quanta luce manda davvero quel colore.
	 *
	 * @param string $colore Il colore in esadecimale.
	 * @return float|null Da 0 (nero) a 1 (bianco), oppure null se il colore non si capisce.
	 */
	public static function luminanza( string $colore ): ?float {
		$canali = self::canali( $colore );

		if ( null === $canali ) {
			return null;
		}

		$lineari = array();

		foreach ( $canali as $canale ) {
			$frazione = $canale / 255;

			// Lo schermo non e' lineare: questa curva annulla la correzione
			// che gli schermi applicano, e riporta il valore alla luce vera.
			$lineari[] = $frazione <= 0.03928
				? $frazione / 12.92
				: ( ( $frazione + 0.055 ) / 1.055 ) ** 2.4;
		}

		return 0.2126 * $lineari[0] + 0.7152 * $lineari[1] + 0.0722 * $lineari[2];
	}

	/**
	 * Il rapporto di contrasto fra due colori.
	 *
	 * Non conta quale dei due sia il testo: il rapporto e' lo stesso.
	 *
	 * @param string $uno    Primo colore.
	 * @param string $altro  Secondo colore.
	 * @return float|null Da 1 a 21, oppure null se uno dei due non si capisce.
	 */
	public static function rapporto( string $uno, string $altro ): ?float {
		$a = self::luminanza( $uno );
		$b = self::luminanza( $altro );

		if ( null === $a || null === $b ) {
			return null;
		}

		$chiaro = max( $a, $b );
		$scuro  = min( $a, $b );

		return ( $chiaro + 0.05 ) / ( $scuro + 0.05 );
	}

	/**
	 * Le soglie dichiarate in coppie-colore.json.
	 *
	 * @return array<string, float>
	 */
	public static function soglie(): array {
		$dati = self::load();

		return array_map( 'floatval', $dati['soglie'] ?? array() );
	}

	/**
	 * Le coppie di colori che il tema usa davvero.
	 *
	 * @return array<int, array<string, string>>
	 */
	public static function coppie(): array {
		$dati = self::load();

		return isset( $dati['coppie'] ) && is_array( $dati['coppie'] ) ? $dati['coppie'] : array();
	}

	/**
	 * Legge il file condiviso, una volta sola.
	 *
	 * @return array<string, mixed>
	 */
	private static function load(): array {
		if ( null !== self::$data ) {
			return self::$data;
		}

		$file = dirname( __DIR__ ) . '/shared/coppie-colore.json';
		$dati = is_readable( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : null;

		self::$data = is_array( $dati ) ? $dati : array();

		return self::$data;
	}
}
