<?php
/**
 * Il plugin ha bisogno del tema quattroemme.
 *
 * I blocchi non portano colori propri: li chiedono al tema, scrivendo nel CSS
 * `var(--wp--preset--color--primary)`. Su un tema che non ha un colore
 * chiamato `primary` quella variabile non esiste, la riga di CSS viene
 * scartata, e lo sfondo diventa trasparente. Stessa storia per le spaziature,
 * i corpi del testo e i caratteri.
 *
 * Il guasto quindi non da' nessun errore: da' una pagina sbiadita, e chi la
 * guarda pensa di aver sbagliato a configurare qualcosa.
 *
 * Qui dentro c'e' l'avviso che lo dice a chiare lettere.
 *
 * PERCHE' AVVISA E NON IMPEDISCE
 *
 * WordPress non ha nessuna intestazione del tipo "questo plugin richiede quel
 * tema": `Requires Plugins`, dalla 6.5, vale solo fra plugin
 * (developer.wordpress.org, "Header Requirements"). Si potrebbe bloccare
 * l'attivazione a mano, ma sarebbe peggio del male: su un sito che usa gia' i
 * nostri blocchi, disattivarli fa sparire il contenuto da ogni pagina e
 * l'editor mostra "questo blocco non esiste". Meglio una pagina scolorita e
 * recuperabile che una pagina vuota.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Controlla che il tema giusto sia attivo e, se non lo e', lo dice.
 */
final class TemaRichiesto {

	/**
	 * Cartella del tema richiesto. E' lo slug, non il titolo.
	 */
	public const TEMA = 'emme-theme';

	/**
	 * Aggancia l'avviso alle pagine di amministrazione.
	 */
	public static function init(): void {
		add_action( 'admin_notices', array( self::class, 'avviso' ) );
	}

	/**
	 * Decide se l'avviso serve, dato il tema attivo.
	 *
	 * E' separata dal resto di proposito: cosi' la decisione si puo' provare
	 * senza avere WordPress acceso.
	 *
	 * @param string $tema_attivo Slug del tema attivo (quello padre, se c'e' un tema figlio).
	 * @return bool Vero se il tema richiesto non c'e'.
	 */
	public static function serve_avviso( string $tema_attivo ): bool {
		return self::TEMA !== $tema_attivo;
	}

	/**
	 * Stampa l'avviso, se serve.
	 *
	 * `get_template()` restituisce il tema padre: un tema figlio di
	 * quattroemme Theme eredita i preset, quindi va bene e non deve avvisare.
	 */
	public static function avviso(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		if ( ! self::serve_avviso( (string) wp_get_theme()->get_template() ) ) {
			return;
		}

		printf(
			'<div class="notice notice-error"><p><strong>%1$s</strong><br>%2$s</p></div>',
			esc_html__( 'quattroemme Blocks needs the quattroemme Theme.', 'emme-blocks' ),
			esc_html__(
				'The active theme is a different one. The blocks can still be inserted, but they take colours, fonts and spacing from the theme: without quattroemme Theme they end up with no background and no colour, and the page looks washed out. Activate quattroemme Theme, or a child theme of it.',
				'emme-blocks'
			)
		);
	}
}
