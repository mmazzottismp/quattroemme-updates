<?php
/**
 * Gli sfondi animati: l'elenco, in un posto solo.
 *
 * Stessa impalcatura di Animazioni, e per la stessa ragione: l'elenco serve
 * al menu dell'editor, al render.php del contenitore e allo schema, e tenerlo
 * in tre posti vuol dire sbagliarlo in tre posti. La fonte e'
 * shared/sfondi.json, e una prova controlla che ogni tipo dichiarato li'
 * abbia davvero il suo disegno in sfondo-animato.js.
 *
 * Come il generatore CSS e la libreria di icone, questa classe non usa
 * nessuna funzione di WordPress: si prova da sola.
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

namespace Emme;

/**
 * Legge l'elenco degli sfondi animati.
 */
final class Sfondi {

	/**
	 * Il contenuto del file, letto una volta sola.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $data = null;

	/**
	 * Tutti i tipi, con nome e gruppo.
	 *
	 * @return array<string, array<string, string>>
	 */
	public static function tipi(): array {
		$dati = self::load();

		return isset( $dati['tipi'] ) && is_array( $dati['tipi'] ) ? $dati['tipi'] : array();
	}

	/**
	 * I gruppi in cui sono divisi, nell'ordine in cui vanno mostrati.
	 *
	 * @return array<string, string>
	 */
	public static function gruppi(): array {
		$dati = self::load();

		return isset( $dati['gruppi'] ) && is_array( $dati['gruppi'] ) ? $dati['gruppi'] : array();
	}

	/**
	 * Dice se un valore e' un tipo di sfondo che conosciamo.
	 *
	 * Quello che arriva qui viene dal contenuto della pagina, cioe' da fuori:
	 * finisce dentro un attributo HTML e non si scrive mai come arriva.
	 *
	 * @param mixed $tipo Valore grezzo.
	 * @return bool Vero se si puo' scrivere in pagina.
	 */
	public static function valida( mixed $tipo ): bool {
		return is_string( $tipo ) && '' !== $tipo && isset( self::tipi()[ $tipo ] );
	}

	/**
	 * Legge il file, una volta sola per richiesta.
	 *
	 * @return array<string, mixed>
	 */
	private static function load(): array {
		if ( null !== self::$data ) {
			return self::$data;
		}

		self::$data = array();

		$file = dirname( __DIR__ ) . '/shared/sfondi.json';

		if ( ! is_readable( $file ) ) {
			return self::$data;
		}

		$letto = json_decode( (string) file_get_contents( $file ), true );

		if ( is_array( $letto ) ) {
			self::$data = $letto;
		}

		return self::$data;
	}
}
