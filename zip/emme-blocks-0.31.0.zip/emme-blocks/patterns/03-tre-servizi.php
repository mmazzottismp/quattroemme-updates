<?php
/**
 * Title: Three services with icons
 * Slug: emme-blocks/tre-servizi
 * Categories: quattroemme, services, columns
 * Keywords: services, cards, columns, icons, offer
 * Description: Three cards side by side: icon, heading, two lines and a link. They lift slightly under the mouse, and on a phone they stack.
 * Viewport Width: 1280
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"sv03ab","emmeStyle":{"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|70","right":"var:preset|spacing|40","bottom":"var:preset|spacing|70","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|50","right":"var:preset|spacing|30","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30"}}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|50"}}}} -->
<!-- wp:heading {"textAlign":"center","level":2} -->
<h2 class="wp-block-heading has-text-align-center"><?php echo esc_html__( 'What I do', 'emme-blocks' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:emme/container {"emmeId":"sv03cd","emmeStyle":{"size":{"width":{"desktop":"100%"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"row","mobile":"column"},"align":{"desktop":"stretch"},"gap":{"desktop":"var:preset|spacing|30"}}}} -->
<!-- wp:emme/container {"emmeId":"sv03ef","emmeStyle":{"background":{"color":"var:preset|color|base-2"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"width":{"desktop":"33.33%","mobile":"100%"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|20"}},"hover":{"shadow":"var:preset|shadow|media","duration":300}}} -->
<!-- wp:emme/icon {"icona":"users","dimensione":"40px","emmeId":"sv03gh","emmeStyle":{"typography":{"color":"var:preset|color|primary"}}} /-->

<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size"><?php echo esc_html__( 'First service', 'emme-blocks' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color"><?php echo esc_html__( 'Two lines on who this is for and what changes for them. Not what you do: what they get.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="#primo"><?php echo esc_html__( 'Details', 'emme-blocks' ); ?></a></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"sv03ij","emmeStyle":{"background":{"color":"var:preset|color|base-2"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"width":{"desktop":"33.33%","mobile":"100%"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|20"}},"hover":{"shadow":"var:preset|shadow|media","duration":300}}} -->
<!-- wp:emme/icon {"icona":"heart","dimensione":"40px","emmeId":"sv03kl","emmeStyle":{"typography":{"color":"var:preset|color|primary"}}} /-->

<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size"><?php echo esc_html__( 'Second service', 'emme-blocks' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color"><?php echo esc_html__( 'Keep the three descriptions roughly the same length: uneven cards look like a mistake even when they are not.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="#secondo"><?php echo esc_html__( 'Details', 'emme-blocks' ); ?></a></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"sv03mn","emmeStyle":{"background":{"color":"var:preset|color|base-2"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"width":{"desktop":"33.33%","mobile":"100%"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|20"}},"hover":{"shadow":"var:preset|shadow|media","duration":300}}} -->
<!-- wp:emme/icon {"icona":"graduation-cap","dimensione":"40px","emmeId":"sv03op","emmeStyle":{"typography":{"color":"var:preset|color|primary"}}} /-->

<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size"><?php echo esc_html__( 'Third service', 'emme-blocks' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color"><?php echo esc_html__( 'Three is the number that works: two look thin, four stop being readable at a glance.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="#terzo"><?php echo esc_html__( 'Details', 'emme-blocks' ); ?></a></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
