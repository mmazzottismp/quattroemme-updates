<?php
/**
 * Title: Three numbers that climb
 * Slug: emme-blocks/contatori-tre
 * Categories: quattroemme, text, columns
 * Keywords: numbers, statistics, figures, results, counter, count
 * Description: Three figures on a coloured band, each with its own caption underneath. The numbers climb when the band comes into view, one after another.
 * Viewport Width: 1280
 *
 * E' il gemello di «Numbers that count», con una differenza sola: li' i
 * numeri sono scritti e stanno fermi, qui salgono quando la fascia entra
 * nello schermo.
 *
 * La didascalia sotto al numero e' un paragrafo e non un pezzo del
 * contatore, ed e' voluto: «prima» e «dopo» del contatore stanno sulla
 * stessa riga del numero - servono al simbolo di valuta e al segno di
 * percentuale - mentre qui serve una riga a parte, che si possa scrivere,
 * tradurre e colorare per conto suo.
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"ct11aa","emmeStyle":{"background":{"color":"var:preset|color|primary"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|60","right":"var:preset|spacing|40","bottom":"var:preset|spacing|60","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|50","right":"var:preset|spacing|30","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30"}}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"row","mobile":"column"},"justify":{"desktop":"space-around"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|40","mobile":"var:preset|spacing|40"}}}} -->
<!-- wp:emme/container {"emmeId":"ct11bb","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|10"}},"animation":{"type":"fade-up","duration":600}}} -->
<!-- wp:emme/contatore {"a":20,"durata":1400,"emmeId":"ct11cc","emmeStyle":{"typography":{"fontSize":{"desktop":"var:preset|font-size|xxx-large"},"fontFamily":"var:preset|font-family|display","color":"var:preset|color|base","textAlign":{"desktop":"center"},"lineHeight":{"desktop":"1.1"}}}} /-->

<!-- wp:paragraph {"align":"center","textColor":"base","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-text-align-center has-base-color has-text-color has-small-font-size" style="text-transform:uppercase;letter-spacing:0.08em"><?php echo esc_html__( 'Years of work', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"ct11dd","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|10"}},"animation":{"type":"fade-up","duration":600,"delay":150}}} -->
<!-- wp:emme/contatore {"a":400,"dopo":"+","durata":1800,"emmeId":"ct11ee","emmeStyle":{"typography":{"fontSize":{"desktop":"var:preset|font-size|xxx-large"},"fontFamily":"var:preset|font-family|display","color":"var:preset|color|base","textAlign":{"desktop":"center"},"lineHeight":{"desktop":"1.1"}}}} /-->

<!-- wp:paragraph {"align":"center","textColor":"base","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-text-align-center has-base-color has-text-color has-small-font-size" style="text-transform:uppercase;letter-spacing:0.08em"><?php echo esc_html__( 'People helped', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"ct11ff","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|10"}},"animation":{"type":"fade-up","duration":600,"delay":300}}} -->
<!-- wp:emme/contatore {"a":98,"dopo":"%","durata":1600,"emmeId":"ct11gg","emmeStyle":{"typography":{"fontSize":{"desktop":"var:preset|font-size|xxx-large"},"fontFamily":"var:preset|font-family|display","color":"var:preset|color|base","textAlign":{"desktop":"center"},"lineHeight":{"desktop":"1.1"}}}} /-->

<!-- wp:paragraph {"align":"center","textColor":"base","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-text-align-center has-base-color has-text-color has-small-font-size" style="text-transform:uppercase;letter-spacing:0.08em"><?php echo esc_html__( 'Would come back', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
