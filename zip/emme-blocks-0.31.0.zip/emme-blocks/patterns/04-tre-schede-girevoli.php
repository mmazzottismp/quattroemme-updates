<?php
/**
 * Title: Three cards that turn
 * Slug: emme-blocks/tre-schede-girevoli
 * Categories: quattroemme, services, columns
 * Keywords: flip, cards, services, turn, reveal
 * Description: Three two sided cards: the heading on the front, the explanation on the back. The three turn in different directions, which reads better than three identical ones.
 * Viewport Width: 1280
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"fl04ab","emmeStyle":{"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|70","right":"var:preset|spacing|40","bottom":"var:preset|spacing|70","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|50","right":"var:preset|spacing|30","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30"}}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|50"}}}} -->
<!-- wp:heading {"textAlign":"center","level":2} -->
<h2 class="wp-block-heading has-text-align-center"><?php echo esc_html__( 'Hover over them', 'emme-blocks' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","textColor":"contrast-2"} -->
<p class="has-text-align-center has-contrast-2-color has-text-color"><?php echo esc_html__( 'On a phone there is no mouse: there they turn on touch. With the keyboard, the tab key reaches them and the back face stays open while the focus is inside.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:emme/container {"emmeId":"fl04cd","emmeStyle":{"size":{"width":{"desktop":"100%"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"row","mobile":"column"},"align":{"desktop":"stretch"},"gap":{"desktop":"var:preset|spacing|30"}}}} -->
<!-- wp:emme/flip {"verso":"destra","etichetta":"First card, turn for details","emmeId":"fl04ef","emmeStyle":{"size":{"width":{"desktop":"33.33%","mobile":"100%"}}}} -->
<!-- wp:emme/container {"emmeId":"fl04gh","emmeStyle":{"background":{"color":"var:preset|color|primary"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"minHeight":{"desktop":"260px"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:emme/icon {"icona":"lightbulb","dimensione":"44px","emmeId":"fl04ij","emmeStyle":{"typography":{"color":"var:preset|color|base"}}} /-->

<!-- wp:heading {"textAlign":"center","level":3,"textColor":"base","fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-base-color has-text-color has-large-font-size"><?php echo esc_html__( 'The front says what', 'emme-blocks' ); ?></h3>
<!-- /wp:heading -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"fl04kl","emmeStyle":{"background":{"color":"var:preset|color|secondary"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"minHeight":{"desktop":"260px"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:paragraph {"align":"center","textColor":"base"} -->
<p class="has-text-align-center has-base-color has-text-color"><?php echo esc_html__( 'The back says how, and holds the button. Keep it short: nobody reads a turned card for long.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->
<!-- /wp:emme/flip -->

<!-- wp:emme/flip {"verso":"sinistra","etichetta":"Second card, turn for details","emmeId":"fl04mn","emmeStyle":{"size":{"width":{"desktop":"33.33%","mobile":"100%"}}}} -->
<!-- wp:emme/container {"emmeId":"fl04op","emmeStyle":{"background":{"color":"var:preset|color|accent"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"minHeight":{"desktop":"260px"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:emme/icon {"icona":"target","dimensione":"44px","emmeId":"fl04qr","emmeStyle":{"typography":{"color":"var:preset|color|base"}}} /-->

<!-- wp:heading {"textAlign":"center","level":3,"textColor":"base","fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-base-color has-text-color has-large-font-size"><?php echo esc_html__( 'This one turns the other way', 'emme-blocks' ); ?></h3>
<!-- /wp:heading -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"fl04st","emmeStyle":{"background":{"color":"var:preset|color|secondary"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"minHeight":{"desktop":"260px"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:paragraph {"align":"center","textColor":"base"} -->
<p class="has-text-align-center has-base-color has-text-color"><?php echo esc_html__( 'The name of the direction says which edge comes forward, towards the person looking. Opposite directions side by side look better than three the same.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->
<!-- /wp:emme/flip -->

<!-- wp:emme/flip {"verso":"alto","etichetta":"Third card, turn for details","emmeId":"fl04uv","emmeStyle":{"size":{"width":{"desktop":"33.33%","mobile":"100%"}}}} -->
<!-- wp:emme/container {"emmeId":"fl04wx","emmeStyle":{"background":{"color":"var:preset|color|primary"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"minHeight":{"desktop":"260px"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:emme/icon {"icona":"shield-check","dimensione":"44px","emmeId":"fl04yz","emmeStyle":{"typography":{"color":"var:preset|color|base"}}} /-->

<!-- wp:heading {"textAlign":"center","level":3,"textColor":"base","fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-base-color has-text-color has-large-font-size"><?php echo esc_html__( 'And this one lifts', 'emme-blocks' ); ?></h3>
<!-- /wp:heading -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"fl0412","emmeStyle":{"background":{"color":"var:preset|color|secondary"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"minHeight":{"desktop":"260px"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:paragraph {"align":"center","textColor":"base"} -->
<p class="has-text-align-center has-base-color has-text-color"><?php echo esc_html__( 'Each face is a container, so it has every panel: background, spacing, border, even the animated background.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->
<!-- /wp:emme/flip -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
