<?php
/**
 * Title: Opening with animated background
 * Slug: emme-blocks/apertura-sfondo-animato
 * Categories: quattroemme, banner, featured
 * Keywords: hero, opening, webgl, animated, movement
 * Description: A full width opening with the WebGL background moving behind the text. The coloured veil keeps the writing readable while the pattern moves.
 * Viewport Width: 1280
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"ap02ab","emmeStyle":{"background":{"animato":{"tipo":"aurora","colore1":"var:preset|color|primary","colore2":"var:preset|color|secondary","colore3":"var:preset|color|accent"},"overlay":{"color":"var:preset|color|contrast","opacity":0.45}},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|80","right":"var:preset|spacing|40","bottom":"var:preset|spacing|80","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|60","right":"var:preset|spacing|30","bottom":"var:preset|spacing|60","left":"var:preset|spacing|30"}}},"size":{"minHeight":{"desktop":"70vh","mobile":"60vh"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|30"}}}} -->
<!-- wp:heading {"textAlign":"center","level":1,"textColor":"base","fontSize":"xxx-large"} -->
<h1 class="wp-block-heading has-text-align-center has-base-color has-text-color has-xxx-large-font-size"><?php echo esc_html__( 'Say the one thing that matters', 'emme-blocks' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","textColor":"base","fontSize":"large"} -->
<p class="has-text-align-center has-base-color has-text-color has-large-font-size"><?php echo esc_html__( 'The background is drawn by the graphics card: a few kilobytes, no library, and the colours come from the palette of the site, so it changes along with the style.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:emme/button {"testo":"Start here","url":"#inizio","icona":"arrow-right","posizioneIcona":"dopo","emmeId":"ap02cd","emmeStyle":{"background":{"color":"var:preset|color|base"},"typography":{"color":"var:preset|color|contrast"}}} /-->
<!-- /wp:emme/container -->
