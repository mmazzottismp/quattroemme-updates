<?php
/**
 * Title: Numbers that count
 * Slug: emme-blocks/numeri
 * Categories: quattroemme, text, columns
 * Keywords: numbers, statistics, figures, results
 * Description: Three figures on a coloured band. Each one arrives with a small delay, so they appear one after another instead of all at once.
 * Viewport Width: 1280
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"nm08ab","emmeStyle":{"background":{"color":"var:preset|color|primary"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|60","right":"var:preset|spacing|40","bottom":"var:preset|spacing|60","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|50","right":"var:preset|spacing|30","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30"}}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"row","mobile":"column"},"justify":{"desktop":"space-around"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|40"}}}} -->
<!-- wp:emme/container {"emmeId":"nm08cd","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|10"}},"animation":{"type":"fade-up","duration":600}}} -->
<!-- wp:paragraph {"align":"center","textColor":"base","fontSize":"xxx-large","fontFamily":"display"} -->
<p class="has-text-align-center has-base-color has-text-color has-display-font-family has-xxx-large-font-size">20</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","textColor":"base","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-text-align-center has-base-color has-text-color has-small-font-size" style="text-transform:uppercase;letter-spacing:0.08em"><?php echo esc_html__( 'Years of work', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"nm08ef","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|10"}},"animation":{"type":"fade-up","duration":600,"delay":150}}} -->
<!-- wp:paragraph {"align":"center","textColor":"base","fontSize":"xxx-large","fontFamily":"display"} -->
<p class="has-text-align-center has-base-color has-text-color has-display-font-family has-xxx-large-font-size">400</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","textColor":"base","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-text-align-center has-base-color has-text-color has-small-font-size" style="text-transform:uppercase;letter-spacing:0.08em"><?php echo esc_html__( 'People helped', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"nm08gh","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|10"}},"animation":{"type":"fade-up","duration":600,"delay":300}}} -->
<!-- wp:paragraph {"align":"center","textColor":"base","fontSize":"xxx-large","fontFamily":"display"} -->
<p class="has-text-align-center has-base-color has-text-color has-display-font-family has-xxx-large-font-size">3</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","textColor":"base","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-text-align-center has-base-color has-text-color has-small-font-size" style="text-transform:uppercase;letter-spacing:0.08em"><?php echo esc_html__( 'Places to find me', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
