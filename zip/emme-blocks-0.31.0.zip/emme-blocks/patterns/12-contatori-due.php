<?php
/**
 * Title: Two numbers that climb
 * Slug: emme-blocks/contatori-due
 * Categories: quattroemme, text, columns
 * Keywords: numbers, statistics, figures, results, counter, count
 * Description: Two figures side by side with their captions, on a quiet band. Fewer numbers, each one bigger: it works where there are only two things worth saying.
 * Viewport Width: 1280
 *
 * Due numeri non sono tre numeri meno uno: sono una composizione diversa.
 * Con due, ognuno puo' essere piu' grande e la fascia puo' restare chiara,
 * perche' non c'e' una fila da tenere insieme con il colore.
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"ct12aa","emmeStyle":{"background":{"color":"var:preset|color|base-2"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|60","right":"var:preset|spacing|40","bottom":"var:preset|spacing|60","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|50","right":"var:preset|spacing|30","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30"}}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"row","mobile":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|70","mobile":"var:preset|spacing|50"}}}} -->
<!-- wp:emme/container {"emmeId":"ct12bb","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|10"}},"animation":{"type":"fade-up","duration":600}}} -->
<!-- wp:emme/contatore {"a":1200,"dopo":"+","durata":1800,"emmeId":"ct12cc","emmeStyle":{"typography":{"fontSize":{"desktop":"var:preset|font-size|xxx-large"},"fontFamily":"var:preset|font-family|display","color":"var:preset|color|primary","textAlign":{"desktop":"center"},"lineHeight":{"desktop":"1.1"}}}} /-->

<!-- wp:paragraph {"align":"center","textColor":"contrast-2","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-text-align-center has-contrast-2-color has-text-color has-small-font-size" style="text-transform:uppercase;letter-spacing:0.08em"><?php echo esc_html__( 'Jobs delivered', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"ct12dd","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|10"}},"animation":{"type":"fade-up","duration":600,"delay":150}}} -->
<!-- wp:emme/contatore {"a":15,"durata":1400,"emmeId":"ct12ee","emmeStyle":{"typography":{"fontSize":{"desktop":"var:preset|font-size|xxx-large"},"fontFamily":"var:preset|font-family|display","color":"var:preset|color|primary","textAlign":{"desktop":"center"},"lineHeight":{"desktop":"1.1"}}}} /-->

<!-- wp:paragraph {"align":"center","textColor":"contrast-2","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-text-align-center has-contrast-2-color has-text-color has-small-font-size" style="text-transform:uppercase;letter-spacing:0.08em"><?php echo esc_html__( 'Years doing it', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
