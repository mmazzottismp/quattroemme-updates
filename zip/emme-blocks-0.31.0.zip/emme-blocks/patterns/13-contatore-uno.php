<?php
/**
 * Title: One number that climbs
 * Slug: emme-blocks/contatore-uno
 * Categories: quattroemme, text, banner
 * Keywords: number, statistic, figure, result, counter, count
 * Description: One figure, as big as it gets, with a caption under it and a line of explanation. For the number that matters more than all the others.
 * Viewport Width: 1280
 *
 * Un numero solo non e' una fila di numeri accorciata: e' il contrario di
 * una fila. Qui il numero sta al centro e non ha niente accanto, e sotto
 * c'e' spazio per una riga che dica cosa vuol dire - quella riga, con tre
 * numeri in fila, non ci starebbe.
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"ct13aa","emmeStyle":{"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|70","right":"var:preset|spacing|40","bottom":"var:preset|spacing|70","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|50","right":"var:preset|spacing|30","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30"}}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|20"}},"animation":{"type":"fade-up","duration":700}}} -->
<!-- wp:emme/contatore {"a":1000000,"durata":2200,"emmeId":"ct13bb","emmeStyle":{"typography":{"fontSize":{"desktop":"7rem","tablet":"5rem","mobile":"3.5rem"},"fontFamily":"var:preset|font-family|display","color":"var:preset|color|accent","textAlign":{"desktop":"center"},"lineHeight":{"desktop":"1"}}}} /-->

<!-- wp:paragraph {"align":"center","textColor":"contrast","fontSize":"medium","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.1em"}}} -->
<p class="has-text-align-center has-contrast-color has-text-color has-medium-font-size" style="text-transform:uppercase;letter-spacing:0.1em"><?php echo esc_html__( 'Cups of coffee', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:emme/container {"emmeId":"ct13cc","emmeStyle":{"size":{"maxWidth":{"desktop":"34rem"}}}} -->
<!-- wp:paragraph {"align":"center","textColor":"contrast-2"} -->
<p class="has-text-align-center has-contrast-2-color has-text-color"><?php echo esc_html__( 'A line that says what the number means, and why it is worth putting it this big.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
