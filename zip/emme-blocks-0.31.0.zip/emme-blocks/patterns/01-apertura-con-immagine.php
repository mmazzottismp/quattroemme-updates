<?php
/**
 * Title: Opening with portrait
 * Slug: emme-blocks/apertura-con-immagine
 * Categories: quattroemme, banner, featured
 * Keywords: hero, opening, intro, header
 * Description: The top of a page: who you are, what you do, two things to click, and a photograph beside it.
 * Viewport Width: 1280
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"ap01ab","emmeStyle":{"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|80","right":"var:preset|spacing|40","bottom":"var:preset|spacing|80","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|60","right":"var:preset|spacing|30","bottom":"var:preset|spacing|60","left":"var:preset|spacing|30"}}},"background":{"color":"var:preset|color|base-2"}}} -->
<!-- wp:emme/container {"emmeId":"ap01cd","emmeStyle":{"layout":{"display":{"desktop":"flex","mobile":"flex"},"direction":{"desktop":"row","mobile":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|60","mobile":"var:preset|spacing|40"}}}} -->
<!-- wp:emme/container {"emmeId":"ap01ef","emmeStyle":{"size":{"width":{"desktop":"55%","mobile":"100%"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|30"}}}} -->
<!-- wp:heading {"level":1,"fontSize":"xxx-large"} -->
<h1 class="wp-block-heading has-xxx-large-font-size"><?php echo esc_html__( 'Care of body, mind and spirit', 'emme-blocks' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large","textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color has-large-font-size"><?php echo esc_html__( 'Two lines saying who you are and where you work. The first thing a person reads: no slogans, just the plain facts.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:emme/container {"emmeId":"ap01gh","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"row","mobile":"column"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:emme/button {"testo":"Call me now","url":"tel:+390000000000","icona":"phone","emmeId":"ap01ij"} /-->

<!-- wp:emme/button {"testo":"Write to me","url":"#contatti","icona":"mail","posizioneIcona":"dopo","emmeId":"ap01kl","emmeStyle":{"background":{"color":"var:preset|color|base"},"typography":{"color":"var:preset|color|primary"},"border":{"width":"1px","style":"solid","color":"var:preset|color|primary"}}} /-->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"ap01mn","emmeStyle":{"size":{"width":{"desktop":"45%","mobile":"100%"}}}} -->
<!-- wp:emme/image {"alt":"","emmeId":"ap01op","emmeStyle":{"size":{"aspectRatio":"4/5","objectFit":"cover"},"border":{"radius":"var:custom|raggio|grande"}}} /-->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
