<?php
/**
 * Title: Closing call to action
 * Slug: emme-blocks/chiamata-finale
 * Categories: quattroemme, call-to-action
 * Keywords: call to action, contact, cta, closing, button
 * Description: The band that closes a page: one heading, one line, one button. One button, not two: two make a person choose instead of act.
 * Viewport Width: 1280
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"cf10ab","emmeStyle":{"background":{"color":"var:preset|color|secondary"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|70","right":"var:preset|spacing|40","bottom":"var:preset|spacing|70","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|50","right":"var:preset|spacing|30","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30"}}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|30"}}}} -->
<!-- wp:heading {"textAlign":"center","level":2,"textColor":"base","fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-text-align-center has-base-color has-text-color has-xx-large-font-size"><?php echo esc_html__( 'Shall we start?', 'emme-blocks' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","textColor":"base","fontSize":"large"} -->
<p class="has-text-align-center has-base-color has-text-color has-large-font-size"><?php echo esc_html__( 'One line saying what happens after the click. A person clicks more readily when they know what is on the other side.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:emme/button {"testo":"Write to me","url":"#contatti","icona":"send","posizioneIcona":"dopo","emmeId":"cf10cd","emmeStyle":{"background":{"color":"var:preset|color|base"},"typography":{"color":"var:preset|color|contrast"}}} /-->
<!-- /wp:emme/container -->
