<?php
/**
 * Title: Quote with attribution
 * Slug: emme-blocks/citazione
 * Categories: quattroemme, text
 * Keywords: quote, citation, phrase, author
 * Description: One quotation, large, alone on a band of its own. It works because there is nothing else to look at.
 * Viewport Width: 1280
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"ct06ab","emmeStyle":{"background":{"color":"var:preset|color|base-2"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|70","right":"var:preset|spacing|40","bottom":"var:preset|spacing|70","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|50","right":"var:preset|spacing|30","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30"}}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|30"}}}} -->
<!-- wp:emme/icon {"icona":"quote","dimensione":"36px","emmeId":"ct06cd","emmeStyle":{"typography":{"color":"var:preset|color|accent"}}} /-->

<!-- wp:paragraph {"align":"center","fontSize":"xx-large","style":{"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.35"}},"fontFamily":"display"} -->
<p class="has-text-align-center has-display-font-family has-xx-large-font-size" style="font-style:normal;font-weight:400;line-height:1.35"><?php echo esc_html__( 'A sentence someone else said, that says better than you could what you are for.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","textColor":"contrast-2","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-text-align-center has-contrast-2-color has-text-color has-small-font-size" style="text-transform:uppercase;letter-spacing:0.08em"><?php echo esc_html__( 'Who said it', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->
