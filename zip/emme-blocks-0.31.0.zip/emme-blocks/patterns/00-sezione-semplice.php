<?php
/**
 * Title: Plain section with heading and text
 * Slug: emme-blocks/sezione-semplice
 * Categories: quattroemme, text, call-to-action
 * Keywords: section, heading, text, button, simple
 * Description: The plain workhorse: heading, two lines, one button. Built from WordPress blocks only, so it keeps working even where the quattroemme blocks are not available.
 * Viewport Width: 1280
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"base-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
<!-- wp:heading {"textAlign":"center","level":2} -->
<h2 class="wp-block-heading has-text-align-center"><?php echo esc_html__( 'A heading that says what you do', 'emme-blocks' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"><?php echo esc_html__( 'Two lines explaining the most important thing, without going around it.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button"><?php echo esc_html__( 'Get in touch', 'emme-blocks' ); ?></a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
