<?php
/**
 * Title: Text and image side by side
 * Slug: emme-blocks/testo-e-immagine
 * Categories: quattroemme, about, text
 * Keywords: about, story, biography, image, two columns
 * Description: The story section: a photograph on one side, the account on the other. On a phone the image goes above the text.
 * Viewport Width: 1280
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"st05ab","emmeStyle":{"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|70","right":"var:preset|spacing|40","bottom":"var:preset|spacing|70","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|50","right":"var:preset|spacing|30","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30"}}}}} -->
<!-- wp:emme/container {"emmeId":"st05cd","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"row","mobile":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|60","mobile":"var:preset|spacing|40"}}}} -->
<!-- wp:emme/container {"emmeId":"st05ef","emmeStyle":{"size":{"width":{"desktop":"42%","mobile":"100%"}}}} -->
<!-- wp:emme/image {"alt":"","emmeId":"st05gh","emmeStyle":{"size":{"aspectRatio":"1/1","objectFit":"cover"},"border":{"radius":"var:custom|raggio|grande"},"animation":{"type":"fade-right","duration":700}}} /-->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"st05ij","emmeStyle":{"size":{"width":{"desktop":"58%","mobile":"100%"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'My story', 'emme-blocks' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large","textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color has-large-font-size"><?php echo esc_html__( 'One line that sets the tone, bigger than the rest.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php echo esc_html__( 'Then the account itself, in two or three short paragraphs. Where you come from, what made you choose this work, and what you have learned that a person coming to you can use.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php echo esc_html__( 'Write in the first person. A biography in the third person, on your own site, reads as though someone else wrote it for you.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
