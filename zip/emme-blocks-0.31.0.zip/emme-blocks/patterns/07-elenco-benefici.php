<?php
/**
 * Title: What it is for, as a list
 * Slug: emme-blocks/elenco-benefici
 * Categories: quattroemme, text, about
 * Keywords: list, benefits, check marks, advantages
 * Description: A heading, a paragraph and a list with check marks. The check mark list is one of the quattroemme styles on the WordPress list block, so it stays a plain list for anyone reading without styles.
 * Viewport Width: 1280
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"bn07ab","emmeStyle":{"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|70","right":"var:preset|spacing|40","bottom":"var:preset|spacing|70","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|50","right":"var:preset|spacing|30","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30"}}}}} -->
<!-- wp:emme/container {"emmeId":"bn07cd","emmeStyle":{"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"row","mobile":"column"},"gap":{"desktop":"var:preset|spacing|60","mobile":"var:preset|spacing|30"}}}} -->
<!-- wp:emme/container {"emmeId":"bn07ef","emmeStyle":{"size":{"width":{"desktop":"45%","mobile":"100%"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'What changes for you', 'emme-blocks' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color"><?php echo esc_html__( 'Two lines of introduction, then the list. The heading on the left and the list on the right read faster than a heading above a column of items.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"bn07gh","emmeStyle":{"size":{"width":{"desktop":"55%","mobile":"100%"}}}} -->
<!-- wp:list {"className":"is-style-emme-spunta","fontSize":"medium"} -->
<ul class="wp-block-list is-style-emme-spunta has-medium-font-size">
<!-- wp:list-item -->
<li><?php echo esc_html__( 'The first thing that changes, said from their side', 'emme-blocks' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php echo esc_html__( 'The second, shorter than the first', 'emme-blocks' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php echo esc_html__( 'The third, which is usually the one that convinces', 'emme-blocks' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php echo esc_html__( 'A fourth, only if it is as strong as the others', 'emme-blocks' ); ?></li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
<!-- /wp:emme/container -->
