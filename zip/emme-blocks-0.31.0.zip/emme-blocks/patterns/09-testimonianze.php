<?php
/**
 * Title: What people say, as a carousel
 * Slug: emme-blocks/testimonianze
 * Categories: quattroemme, testimonials
 * Keywords: testimonials, reviews, carousel, clients, words
 * Description: Three accounts in a carousel set shallow, so the ones at the side are only a hint. Clicking a side slide brings it to the centre; the centre one does not react, because that is where the content is.
 * Viewport Width: 1280
 *
 * @package EmmeBlocks
 */

?>
<!-- wp:emme/container {"align":"full","emmeId":"ts09ab","emmeStyle":{"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|70","right":"var:preset|spacing|40","bottom":"var:preset|spacing|70","left":"var:preset|spacing|40"},"mobile":{"top":"var:preset|spacing|50","right":"var:preset|spacing|20","bottom":"var:preset|spacing|50","left":"var:preset|spacing|20"}}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|40"}}}} -->
<!-- wp:heading {"textAlign":"center","level":2} -->
<h2 class="wp-block-heading has-text-align-center"><?php echo esc_html__( 'What people say', 'emme-blocks' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:emme/carosello {"larghezza":70,"passo":74,"profondita":90,"giro":12,"visibili":1,"etichetta":"What people say","emmeId":"ts09cd","emmeStyle":{"size":{"width":{"desktop":"100%"}}}} -->
<!-- wp:emme/container {"emmeId":"ts09ef","emmeStyle":{"background":{"color":"var:preset|color|base-2"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|50","right":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"minHeight":{"desktop":"240px"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:paragraph {"align":"center","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"><?php echo esc_html__( 'The words of a real person, kept as they were said. A tidied up testimonial sounds written by you, and everybody can tell.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","textColor":"contrast-2","fontSize":"small"} -->
<p class="has-text-align-center has-contrast-2-color has-text-color has-small-font-size"><?php echo esc_html__( 'Name, and what they do', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"ts09gh","emmeStyle":{"background":{"color":"var:preset|color|base-2"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|50","right":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"minHeight":{"desktop":"240px"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:paragraph {"align":"center","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"><?php echo esc_html__( 'Three are enough. A carousel of twelve says that none of them is worth much.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","textColor":"contrast-2","fontSize":"small"} -->
<p class="has-text-align-center has-contrast-2-color has-text-color has-small-font-size"><?php echo esc_html__( 'Name, and what they do', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->

<!-- wp:emme/container {"emmeId":"ts09ij","emmeStyle":{"background":{"color":"var:preset|color|base-2"},"spacing":{"padding":{"desktop":{"top":"var:preset|spacing|50","right":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50"}}},"border":{"radius":"var:custom|raggio|medio"},"size":{"minHeight":{"desktop":"240px"}},"layout":{"display":{"desktop":"flex"},"direction":{"desktop":"column"},"justify":{"desktop":"center"},"align":{"desktop":"center"},"gap":{"desktop":"var:preset|spacing|20"}}}} -->
<!-- wp:paragraph {"align":"center","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"><?php echo esc_html__( 'Without JavaScript this stays a readable stack: nothing disappears, it simply does not turn.', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","textColor":"contrast-2","fontSize":"small"} -->
<p class="has-text-align-center has-contrast-2-color has-text-color has-small-font-size"><?php echo esc_html__( 'Name, and what they do', 'emme-blocks' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:emme/container -->
<!-- /wp:emme/carosello -->
<!-- /wp:emme/container -->
