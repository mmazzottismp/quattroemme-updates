/*
 * Il contatore quattroemme: un numero che sale quando entra nello schermo.
 *
 * TRE COSE CHE CONTANO, E SONO TUTTE E TRE SUL «COSA SUCCEDE SE NON PARTO».
 *
 * 1. Il numero finale e' **gia' scritto in pagina** dal PHP. Se questo file
 *    non arriva, se il browser non sa fare le cose che usa, se qualcuno ha
 *    spento il JavaScript: si vede il dato giusto, fermo. Nessun buco,
 *    nessuno zero, nessun «0» che resta li' a mentire.
 * 2. Chi ha chiesto meno movimento non vede niente salire: il numero sta
 *    dov'e'.
 * 3. Si conta **una volta sola**, e solo quando il blocco si vede davvero.
 *    Un numero che riparte ogni volta che si scorre avanti e indietro non e'
 *    un effetto, e' un tic.
 *
 * I separatori delle migliaia e dei decimali arrivano dal PHP negli
 * attributi: sono quelli della lingua del sito, e ricalcolarli qui vorrebbe
 * dire avere due regole diverse per lo stesso numero.
 */
( function () {
	'use strict';

	/**
	 * Legge un numero da un attributo.
	 *
	 * @param {Element} elemento Il contatore.
	 * @param {string}  nome     Nome dell'attributo.
	 * @param {number}  riserva  Valore se manca o non e' un numero.
	 * @return {number} Il numero.
	 */
	function numeroDa( elemento, nome, riserva ) {
		var grezzo = parseFloat( elemento.getAttribute( nome ) );

		return isFinite( grezzo ) ? grezzo : riserva;
	}

	/**
	 * Scrive un numero come lo scrive il PHP.
	 *
	 * Gemello di `Emme\Contatore::scrivi()`. Le due meta' devono dire la
	 * stessa cosa: il numero finale lo scrive il PHP, quelli in mezzo questo
	 * file, e se i separatori non coincidono l'ultimo passo del conteggio si
	 * vede come uno scatto.
	 *
	 * @param {number} valore    Il numero.
	 * @param {number} decimali  Quante cifre dopo la virgola.
	 * @param {string} migliaia  Separatore delle migliaia.
	 * @param {string} virgola   Separatore dei decimali.
	 * @return {string} Il numero scritto.
	 */
	function scrivi( valore, decimali, migliaia, virgola ) {
		var fisso = Math.abs( valore ).toFixed( decimali );
		var pezzi = fisso.split( '.' );
		var interi = pezzi[ 0 ];
		var fuori = '';

		while ( interi.length > 3 ) {
			fuori = migliaia + interi.slice( -3 ) + fuori;
			interi = interi.slice( 0, -3 );
		}

		fuori = interi + fuori;

		if ( pezzi.length > 1 ) {
			fuori += virgola + pezzi[ 1 ];
		}

		return ( valore < 0 ? '-' : '' ) + fuori;
	}

	/**
	 * La curva: parte svelta e rallenta in fondo.
	 *
	 * E' la stessa di una comparsa, e per la stessa ragione: un numero che
	 * rallenta mentre si avvicina al suo valore sembra arrivarci, uno che va
	 * a velocita' costante sembra tagliato.
	 *
	 * @param {number} quota Da 0 a 1.
	 * @return {number} Da 0 a 1.
	 */
	function curva( quota ) {
		return 1 - Math.pow( 1 - quota, 3 );
	}

	/**
	 * Fa salire un contatore.
	 *
	 * @param {Element} elemento Il contatore.
	 */
	function conta( elemento ) {
		var dove = elemento.querySelector( '.emme-cont__numero' );

		if ( ! dove ) {
			return;
		}

		var da = numeroDa( elemento, 'data-emme-cont-da', 0 );
		var a = numeroDa( elemento, 'data-emme-cont-a', 0 );
		var durata = numeroDa( elemento, 'data-emme-cont-durata', 1200 );
		var decimali = numeroDa( elemento, 'data-emme-cont-dec', 0 );
		var migliaia = elemento.getAttribute( 'data-emme-cont-mille' ) || '';
		var virgola = elemento.getAttribute( 'data-emme-cont-virgola' ) || ',';

		if ( durata <= 0 || da === a ) {
			return;
		}

		var inizio = 0;

		function passo( adesso ) {
			if ( ! inizio ) {
				inizio = adesso;
			}

			var quota = Math.min( ( adesso - inizio ) / durata, 1 );

			dove.textContent = scrivi( da + ( a - da ) * curva( quota ), decimali, migliaia, virgola );

			if ( quota < 1 ) {
				window.requestAnimationFrame( passo );
			}
		}

		// Si parte scrivendo il numero di partenza: se no il primo fotogramma
		// mostrerebbe ancora quello finale e si vedrebbe un salto all'indietro.
		dove.textContent = scrivi( da, decimali, migliaia, virgola );

		window.requestAnimationFrame( passo );
	}

	function avvia() {
		var contatori = document.querySelectorAll( '[data-emme-cont]' );

		if ( ! contatori.length ) {
			return;
		}

		// Chi ha chiesto meno movimento tiene il numero finale, che e' gia'
		// quello scritto in pagina: non c'e' niente da fare.
		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			return;
		}

		// Senza l'osservatore si conta subito: meglio un conteggio che parte
		// fuori dallo schermo che un numero che non sale mai.
		if ( typeof window.IntersectionObserver !== 'function' ) {
			Array.prototype.forEach.call( contatori, conta );
			return;
		}

		var osservatore = new IntersectionObserver(
			function ( voci ) {
				voci.forEach( function ( voce ) {
					if ( ! voce.isIntersecting ) {
						return;
					}

					// Una volta sola: si smette di guardarlo appena ha contato.
					osservatore.unobserve( voce.target );
					conta( voce.target );
				} );
			},
			{ threshold: 0.4 }
		);

		Array.prototype.forEach.call( contatori, function ( elemento ) {
			osservatore.observe( elemento );
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', avvia );
	} else {
		avvia();
	}
} )();
