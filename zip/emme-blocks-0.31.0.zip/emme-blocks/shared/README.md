# I due file condivisi

Questa cartella contiene le **due fonti uniche** del sistema di controlli. Non sono codice: sono dati, letti da tre parti diverse del progetto.

| File | Che cosa dice | Chi lo legge |
|---|---|---|
| `emme-style.schema.json` | quali proprietà esistono, che valori sono ammessi, quali sono responsive | l'editor, il PHP che valida, il generatore di siti della Fase 4 |
| `style-map.json` | quale regola CSS produce ogni proprietà | il PHP che genera la pagina, il JavaScript che disegna l'anteprima |

Stanno qui, fuori da `src/` e fuori da `build/`, perché devono finire nel pacchetto così come sono: non vanno compilati, e il PHP deve poterli leggere a ogni visita.

## Perché una fonte sola

Se l'editor e il sito calcolassero il CSS ciascuno per conto proprio, prima o poi divergerebbero: una proprietà aggiunta da una parte e non dall'altra, un valore tradotto diversamente, e l'anteprima smette di assomigliare al risultato. Con una tabella sola, un errore si vede subito in entrambi i posti e si corregge in un punto.

Lo stesso vale per lo schema: è il disegno quotato con le tolleranze. Chi genera un blocco — una persona o un'intelligenza artificiale — non può inventarsi una proprietà che non sia dichiarata lì, perché la validazione la respinge.

## Le regole di modifica

- **Si aggiunge una proprietà in tutti e due i file, o in nessuno.** Una proprietà nello schema ma non nella tabella non produce CSS; nella tabella ma non nello schema viene scartata dalla validazione.
- **Non si rinomina una proprietà già usata da un sito vivo** senza una migrazione: i blocchi già salvati contengono il vecchio nome.
- **Lo schema è chiuso** (`additionalProperties: false`): qualunque proprietà non dichiarata fa fallire la validazione. È voluto.

## I valori preset

Dove possibile i valori non sono misure fisse ma riferimenti ai preset del tema, nella forma che usa WordPress stesso:

```
var:preset|spacing|40      →  var(--wp--preset--spacing--40)
var:preset|color|primary   →  var(--wp--preset--color--primary)
var:preset|shadow|media    →  var(--wp--preset--shadow--media)
```

La conversione è: togliere `var:`, sostituire ogni `|` con `--`, avvolgere in `var(--wp--…)`. È la stessa regola applicata dal core di WordPress in `WP_Theme_JSON`, verificata nel codice della 7.1.4.

Il vantaggio pratico: un blocco che usa `var:preset|color|primary` cambia colore da solo quando si cambia la variante di stile del cliente, senza toccare le pagine.
