/**
 * La lightbox di quattroemme.
 *
 * Si aggancia a tutti i pulsanti che portano data-emme-lightbox e apre
 * l'immagine grande dentro un <dialog>. Niente librerie: il browser sa gia'
 * fare la parte difficile.
 *
 * Cosa regala il <dialog> nativo, e che quasi tutte le lightbox in giro
 * sbagliano:
 *
 * - showModal() chiude il fuoco della tastiera dentro il riquadro, quindi
 *   premendo Tab non si finisce a navigare la pagina di sotto;
 * - Esc chiude senza che si debba scrivere niente;
 * - il resto della pagina viene marcato come inerte, quindi un lettore di
 *   schermo non lo legge mentre la foto e' aperta;
 * - alla chiusura il fuoco torna da solo al pulsante da cui si era partiti.
 *
 * Le immagini con lo stesso gruppo si sfogliano con le frecce. Il gruppo lo
 * decide chi compone la pagina, scrivendo lo stesso nome su piu' immagini.
 *
 * Il file viene caricato solo nelle pagine che hanno almeno un'immagine
 * ingrandibile.
 */

( function () {
	'use strict';

	var finestra = null;
	var immagine = null;
	var didascalia = null;
	var precedente = null;
	var successiva = null;

	/** I pulsanti del gruppo che si sta sfogliando, e dove siamo arrivati. */
	var gruppo = [];
	var indice = 0;

	/**
	 * Costruisce il riquadro, una volta sola e solo quando serve davvero.
	 *
	 * @return {HTMLElement|null} Il riquadro, o niente se il browser e' troppo vecchio.
	 */
	function costruisci() {
		if ( finestra ) {
			return finestra;
		}

		finestra = document.createElement( 'dialog' );
		finestra.className = 'emme-lightbox-finestra';

		// Senza showModal non c'e' gabbia del fuoco: meglio non aprire niente
		// e lasciare che il collegamento faccia il suo mestiere.
		if ( typeof finestra.showModal !== 'function' ) {
			finestra = null;
			return null;
		}

		var chiudi = bottone( 'emme-lightbox-chiudi', '×', 'Chiudi' );
		precedente = bottone( 'emme-lightbox-prec', '‹', 'Immagine precedente' );
		successiva = bottone( 'emme-lightbox-succ', '›', 'Immagine successiva' );

		immagine = document.createElement( 'img' );
		didascalia = document.createElement( 'p' );
		didascalia.className = 'emme-lightbox-didascalia';

		finestra.appendChild( chiudi );
		finestra.appendChild( precedente );
		finestra.appendChild( immagine );
		finestra.appendChild( successiva );
		finestra.appendChild( didascalia );

		chiudi.addEventListener( 'click', function () {
			finestra.close();
		} );

		precedente.addEventListener( 'click', function () {
			vaiA( indice - 1 );
		} );

		successiva.addEventListener( 'click', function () {
			vaiA( indice + 1 );
		} );

		// Un clic fuori dalla foto chiude: e' quello che la gente si aspetta.
		// Si controlla il bersaglio perche' il clic sulla foto non deve chiudere.
		finestra.addEventListener( 'click', function ( evento ) {
			if ( evento.target === finestra ) {
				finestra.close();
			}
		} );

		finestra.addEventListener( 'keydown', function ( evento ) {
			if ( gruppo.length < 2 ) {
				return;
			}

			if ( evento.key === 'ArrowLeft' ) {
				evento.preventDefault();
				vaiA( indice - 1 );
			} else if ( evento.key === 'ArrowRight' ) {
				evento.preventDefault();
				vaiA( indice + 1 );
			}
		} );

		document.body.appendChild( finestra );

		return finestra;
	}

	/**
	 * Un pulsante tondo dei comandi.
	 *
	 * @param {string} classe  Classe CSS.
	 * @param {string} segno   Il simbolo da mostrare.
	 * @param {string} nome    Come lo legge un lettore di schermo.
	 * @return {HTMLElement} Il pulsante.
	 */
	function bottone( classe, segno, nome ) {
		var b = document.createElement( 'button' );

		b.type = 'button';
		b.className = classe;
		b.setAttribute( 'aria-label', nome );
		b.textContent = segno;

		return b;
	}

	/**
	 * Mostra l'immagine che sta in una certa posizione del gruppo.
	 *
	 * Il giro si chiude: dopo l'ultima si torna alla prima.
	 *
	 * @param {number} dove Posizione nel gruppo.
	 */
	function vaiA( dove ) {
		if ( ! gruppo.length ) {
			return;
		}

		indice = ( dove + gruppo.length ) % gruppo.length;

		var pulsante = gruppo[ indice ];

		immagine.src = pulsante.getAttribute( 'data-emme-lightbox' ) || '';
		immagine.alt = pulsante.getAttribute( 'data-emme-lightbox-alt' ) || '';
		didascalia.textContent = pulsante.getAttribute( 'data-emme-lightbox-testo' ) || '';

		var sfoglia = gruppo.length > 1;

		precedente.hidden = ! sfoglia;
		successiva.hidden = ! sfoglia;

		finestra.setAttribute(
			'aria-label',
			sfoglia
				? 'Immagine ' + ( indice + 1 ) + ' di ' + gruppo.length
				: 'Immagine ingrandita'
		);
	}

	/**
	 * Apre la lightbox partendo da un pulsante.
	 *
	 * @param {HTMLElement} pulsante Il pulsante cliccato.
	 */
	function apri( pulsante ) {
		if ( ! costruisci() ) {
			return;
		}

		var nome = pulsante.getAttribute( 'data-emme-lightbox-gruppo' ) || '';

		gruppo = nome
			? Array.prototype.slice.call(
					document.querySelectorAll(
						'[data-emme-lightbox-gruppo="' + nome.replace( /"/g, '' ) + '"]'
					)
			  )
			: [ pulsante ];

		var posizione = gruppo.indexOf( pulsante );

		vaiA( posizione === -1 ? 0 : posizione );
		finestra.showModal();
	}

	// Un solo ascoltatore su tutta la pagina invece di uno per immagine: cosi'
	// funziona anche con le immagini che arrivano dopo, caricate da altro.
	document.addEventListener( 'click', function ( evento ) {
		var pulsante = evento.target.closest
			? evento.target.closest( '[data-emme-lightbox]' )
			: null;

		if ( ! pulsante ) {
			return;
		}

		evento.preventDefault();
		apri( pulsante );
	} );
} )();
