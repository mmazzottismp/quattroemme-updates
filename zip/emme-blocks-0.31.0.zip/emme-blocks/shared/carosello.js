/*
 * Carosello in profondita' dei blocchi quattroemme.
 *
 * Le diapositive stanno tutte nello stesso posto e vengono spostate con una
 * trasformazione: quella al centro e' davanti e dritta, le altre scalano
 * indietro e si girano verso il centro. Niente libreria.
 *
 *
 * SENZA JAVASCRIPT LA PAGINA RESTA LEGGIBILE
 *
 * Il foglio di stile impila le diapositive una sotto l'altra, normalmente.
 * Solo quando questo script parte aggiunge la classe emme-car-pronto, ed e'
 * li' dentro che vive tutto il 3D. Un carosello che senza JavaScript diventa
 * un mucchio di riquadri sovrapposti e illeggibili e' il difetto piu' comune
 * di questo genere di blocchi: qui non puo' succedere.
 *
 * Per la stessa ragione i comandi — frecce e pallini — li costruisce lo
 * script e non il PHP: comandi che non fanno niente sono peggio di nessun
 * comando. Le loro scritte arrivano pero' dal PHP, con gli attributi data,
 * cosi' restano traducibili.
 *
 *
 * QUELLO CHE UN CAROSELLO SBAGLIA QUASI SEMPRE
 *
 * - Parte da solo. Qui l'avvio automatico e' SPENTO di sua natura, e quando
 *   lo si accende si ferma al passaggio del mouse, con il fuoco dentro, fuori
 *   dallo schermo, e non parte affatto per chi ha chiesto meno movimento.
 * - Non si usa con la tastiera. Qui le frecce sono pulsanti veri e le frecce
 *   della tastiera funzionano.
 * - Dice il falso a chi non vede. Qui ogni diapositiva dichiara la sua
 *   posizione, e il contenitore annuncia i cambi senza interrompere.
 */
( function () {
	'use strict';

	var PRONTO = 'emme-car-pronto';

	/*
	 * Quanto si accetta che una diapositiva esca dalla pista, in pixel.
	 *
	 * Mezzo pixel sta sotto la soglia di quello che si vede e sotto
	 * l'arrotondamento che il browser fa sulle misure: chiedere lo zero esatto
	 * vorrebbe dire inseguire un numero che non sta fermo.
	 */
	var TOLLERANZA = 0.5;

	/*
	 * QUANDO LA DIAPOSITIVA PASSA DAVANTI ALL'ALTRA
	 *
	 * L'ordine di sovrapposizione e' z-index, e z-index non si interpola: il
	 * browser lo porta a destinazione al primo fotogramma. Provato il
	 * 09/11/2026 su una diapositiva vera, campionando ogni 200 ms: parte da 90
	 * e a 50 ms e' gia' a 500. Non serve nemmeno metterlo fra le transizioni.
	 *
	 * Conseguenza: cambiandolo insieme alla posizione, la scheda che arriva
	 * sbuca DAVANTI a quella che se ne va gia' prima di muoversi, e il
	 * movimento si legge come uno scatto. Manuel l'ha chiamato «antipatico», e
	 * quello che si aspettava e' uno scavalco: la scheda che arriva viene
	 * avanti da dietro e prende il davanti nel punto in cui si incrociano.
	 *
	 * L'incrocio e' calcolabile. Le due schede partono da scarti opposti (una
	 * da 1 verso 0, l'altra da 0 verso 1) e si muovono con la stessa curva,
	 * quindi sono alla stessa profondita' quando l'avanzamento vale 0,5. Con la
	 * curva che usiamo, cubic-bezier(0.4, 0, 0.2, 1), l'avanzamento vale 0,5
	 * al 35% del tempo:
	 *
	 *   y(t) = 3t^2 - 2t^3 = 0,5  ->  t = 0,5
	 *   x(0,5) = 3(0,25)(0,5)(0,4) + 3(0,5)(0,25)(0,2) + 0,125 = 0,35
	 *
	 * Se un giorno cambia la curva nel foglio di stile, cambia anche questo
	 * numero: una prova tiene insieme le due cose.
	 */
	var QUANDO_SCAVALCA = 0.35;

	var menoMovimento =
		window.matchMedia && window.matchMedia( '( prefers-reduced-motion: reduce )' ).matches;

	/**
	 * Legge un numero da un attributo data, dentro i limiti.
	 *
	 * @param {Element} radice       Il carosello.
	 * @param {string}  nome         Nome dell'attributo, senza data-emme-car-.
	 * @param {number}  predefinito  Valore da usare se manca o e' fuori scala.
	 * @param {number}  minimo       Limite inferiore.
	 * @param {number}  massimo      Limite superiore.
	 * @return {number} Il numero.
	 */
	function numero( radice, nome, predefinito, minimo, massimo ) {
		var letto = parseFloat( radice.getAttribute( 'data-emme-car-' + nome ) );

		if ( ! isFinite( letto ) || letto < minimo || letto > massimo ) {
			return predefinito;
		}

		return letto;
	}

	function scritta( radice, nome, predefinita ) {
		return radice.getAttribute( 'data-emme-car-' + nome ) || predefinita;
	}

	// --- un carosello -------------------------------------------------------

	function Carosello( radice ) {
		this.radice = radice;
		this.pista = radice.querySelector( '.emme-car-pista' );
		this.diapositive = this.pista ? Array.prototype.slice.call( this.pista.children ) : [];
		this.quante = this.diapositive.length;
		this.corrente = 0;

		// Posizione continua: durante il trascinamento vale anche 1,4.
		this.posizione = 0;

		this.inVista = true;
		this.fermo = false;
		this.timer = 0;
	}

	Carosello.prototype.avvia = function () {
		if ( this.quante < 2 ) {
			return false;
		}

		this.passo = numero( this.radice, 'passo', 62, 0, 200 );
		this.profondita = numero( this.radice, 'profondita', 180, 0, 600 );
		this.giro = numero( this.radice, 'giro', 25, 0, 60 );
		this.visibili = numero( this.radice, 'visibili', 2, 1, 4 );
		this.durata = numero( this.radice, 'durata', 500, 150, 1500 );
		this.intervallo = numero( this.radice, 'intervallo', 5000, 2000, 12000 );

		this.adatta = this.radice.getAttribute( 'data-emme-car-adatta' ) === '1';
		this.passoScelto = this.passo;

		this.anello = this.radice.getAttribute( 'data-emme-car-anello' ) !== '0';
		this.automatico =
			this.radice.getAttribute( 'data-emme-car-automatico' ) === '1' && ! menoMovimento;

		this.radice.style.setProperty( '--emme-car-durata', this.durata + 'ms' );

		this.preparaDiapositive();
		this.costruisciComandi();
		this.ascolta();

		this.radice.classList.add( PRONTO );
		this.posiziona();
		this.adattaAllaLarghezza();
		this.guardaLaLarghezza();

		if ( this.automatico ) {
			this.guardaSeSiVede();
			this.riparti();
		}

		return true;
	};

	/**
	 * Ogni diapositiva dichiara chi e'.
	 *
	 * aria-roledescription dice "diapositiva" invece di "gruppo", e
	 * l'etichetta dice a che punto si e'. Senza, chi usa un lettore di schermo
	 * sente una sequenza di gruppi senza sapere quanti sono ne' dove si trova.
	 */
	Carosello.prototype.preparaDiapositive = function () {
		var modello = scritta( this.radice, 'posizione', '%1 di %2' );
		var nome = scritta( this.radice, 'diapositiva', 'Diapositiva' );

		this.diapositive.forEach( function ( diapositiva, i ) {
			diapositiva.classList.add( 'emme-car-diapositiva' );
			diapositiva.setAttribute( 'role', 'group' );
			diapositiva.setAttribute( 'aria-roledescription', nome );
			diapositiva.setAttribute(
				'aria-label',
				modello.replace( '%1', i + 1 ).replace( '%2', this.diapositive.length )
			);
		}, this );
	};

	Carosello.prototype.costruisciComandi = function () {
		var c = this;

		// Il disegno si costruisce con i nodi e non con innerHTML. Qui il
		// contenuto sarebbe una costante nostra e quindi innocuo, ma un
		// innerHTML in un file condiviso e' una domanda che si ripresenta a
		// ogni revisione: meglio non lasciarla aperta.
		var SVG = 'http://www.w3.org/2000/svg';

		function freccia( verso, etichetta, segno ) {
			var pulsante = document.createElement( 'button' );
			pulsante.type = 'button';
			pulsante.className = 'emme-car-freccia emme-car-freccia--' + verso;
			pulsante.setAttribute( 'aria-label', etichetta );

			var disegno = document.createElementNS( SVG, 'svg' );
			disegno.setAttribute( 'viewBox', '0 0 24 24' );
			disegno.setAttribute( 'width', '24' );
			disegno.setAttribute( 'height', '24' );
			disegno.setAttribute( 'fill', 'none' );
			disegno.setAttribute( 'stroke', 'currentColor' );
			disegno.setAttribute( 'stroke-width', '2' );
			disegno.setAttribute( 'stroke-linecap', 'round' );
			disegno.setAttribute( 'stroke-linejoin', 'round' );
			disegno.setAttribute( 'aria-hidden', 'true' );

			var tratto = document.createElementNS( SVG, 'path' );
			tratto.setAttribute( 'd', segno );

			disegno.appendChild( tratto );
			pulsante.appendChild( disegno );

			return pulsante;
		}

		this.prima = freccia( 'prima', scritta( this.radice, 'prima', 'Precedente' ), 'M15 18l-6-6 6-6' );
		this.dopo = freccia( 'dopo', scritta( this.radice, 'dopo', 'Successiva' ), 'M9 18l6-6-6-6' );

		this.prima.addEventListener( 'click', function () {
			c.vaiA( c.corrente - 1, true );
		} );
		this.dopo.addEventListener( 'click', function () {
			c.vaiA( c.corrente + 1, true );
		} );

		/*
		 * I comandi stanno SOTTO, in fila con i pallini, e non appoggiati
		 * sopra le diapositive.
		 *
		 * Appoggiate ai lati stavano esattamente sopra l'unico pezzo di
		 * diapositiva laterale che si puo' cliccare. Misurato l'08/11/2026:
		 * della diapositiva accanto al centro, larga 385 punti sullo schermo,
		 * solo 80 ricevevano il clic — e la freccia ne copriva 68, proprio in
		 * mezzo. Manuel cliccava dove la vedeva e prendeva la freccia o la
		 * diapositiva centrale.
		 */
		this.comandi = document.createElement( 'div' );
		this.comandi.className = 'emme-car-comandi';

		// I pallini. Sono pulsanti veri, non puntini decorativi: ci si arriva
		// con il tabulatore e si capisce quale e' quello attivo.
		this.punti = document.createElement( 'div' );
		this.punti.className = 'emme-car-punti';

		var modello = scritta( this.radice, 'vaialla', 'Vai alla %1' );

		this.bottoncini = this.diapositive.map( function ( diapositiva, i ) {
			var punto = document.createElement( 'button' );
			punto.type = 'button';
			punto.className = 'emme-car-punto';
			punto.setAttribute( 'aria-label', modello.replace( '%1', i + 1 ) );
			punto.addEventListener( 'click', function () {
				c.vaiA( i, true );
			} );
			c.punti.appendChild( punto );

			return punto;
		} );

		this.comandi.appendChild( this.prima );
		this.comandi.appendChild( this.punti );
		this.comandi.appendChild( this.dopo );
		this.radice.appendChild( this.comandi );
	};

	Carosello.prototype.ascolta = function () {
		var c = this;

		// Le frecce della tastiera, quando il fuoco e' dentro al carosello.
		this.radice.addEventListener( 'keydown', function ( evento ) {
			if ( evento.key === 'ArrowLeft' ) {
				evento.preventDefault();
				c.vaiA( c.corrente - 1, true );
			} else if ( evento.key === 'ArrowRight' ) {
				evento.preventDefault();
				c.vaiA( c.corrente + 1, true );
			}
		} );

		// Un clic su una diapositiva di lato la porta al centro. E' il gesto
		// che la gente prova per primo, e quasi nessun carosello lo prevede.
		this.diapositive.forEach( function ( diapositiva, i ) {
			diapositiva.addEventListener( 'click', function ( evento ) {
				if ( i === c.corrente || c.haTrascinato ) {
					return;
				}

				// Un collegamento su una diapositiva di lato non deve aprirsi
				// al primo clic: quel clic serve a portarla al centro.
				if ( evento.target.closest && evento.target.closest( 'a, button' ) ) {
					evento.preventDefault();
				}

				c.vaiA( i, true );
			} );
		} );

		this.trascinamento();

		// L'avvio automatico si ferma dove un essere umano sta guardando.
		[ 'mouseenter', 'focusin' ].forEach( function ( quando ) {
			c.radice.addEventListener( quando, function () {
				c.fermo = true;
				c.riparti();
			} );
		} );

		[ 'mouseleave', 'focusout' ].forEach( function ( quando ) {
			c.radice.addEventListener( quando, function () {
				c.fermo = false;
				c.riparti();
			} );
		} );
	};

	/**
	 * Trascinamento con il dito o con il mouse.
	 *
	 * Si usano gli eventi "pointer", che sono gli stessi per dito, mouse e
	 * penna: un solo pezzo di codice invece di tre.
	 *
	 *
	 * PERCHE' LA CATTURA DEL PUNTATORE ARRIVA TARDI
	 *
	 * setPointerCapture serve a non perdere il trascinamento quando il dito
	 * esce dal riquadro. Ma finche' la cattura e' attiva il browser **dirotta
	 * anche il click** sull'elemento che cattura: non arriva piu' alla
	 * diapositiva ne' a quello che c'e' dentro.
	 *
	 * Chiedendola subito, su pointerdown, il danno era doppio e Manuel ha
	 * visto il piu' piccolo dei due: il clic su una diapositiva di lato non la
	 * portava al centro. Il piu' grosso era che **i collegamenti e i pulsanti
	 * dentro le diapositive non funzionavano affatto**, nemmeno al centro —
	 * un carosello in cui non si clicca niente.
	 *
	 * Quindi la cattura si chiede solo quando un trascinamento e' cominciato
	 * davvero, superata la soglia. Un clic normale non la attiva mai e segue
	 * la sua strada.
	 */
	Carosello.prototype.trascinamento = function () {
		var c = this;
		var partenza = 0;
		var attivo = false;
		var catturato = false;

		/*
		 * LA ZONA MORTA, E PERCHE' NON DEVE ESISTERE
		 *
		 * Questa soglia e' in PIXEL e non in frazioni di diapositiva. Prima
		 * era 0,04 diapositive, cioe' una ventina di punti su uno schermo
		 * grande e meno su uno piccolo: la stessa mano otteneva risposte
		 * diverse a seconda dello schermo.
		 *
		 * Ma il guaio vero stava dopo. Finito il trascinamento si andava alla
		 * diapositiva PIU' VICINA, con un arrotondamento. Spostandosi di
		 * meno di mezza diapositiva si tornava quindi da dove si era partiti:
		 * fra i 21 e i 264 punti, misurati, non succedeva NIENTE. Ed e'
		 * esattamente l'ampiezza con cui una mano vera clicca una cosa
		 * muovendosi un po'. Manuel l'ha segnalato tre volte e aveva ragione
		 * tutte e tre.
		 *
		 * Adesso: sotto la soglia e' un clic e il clic fa il suo mestiere;
		 * sopra la soglia e' un trascinamento, e un trascinamento sposta
		 * SEMPRE di almeno un posto, nel verso in cui e' andata la mano. Non
		 * esiste piu' un gesto che non produce niente.
		 */
		var SOGLIA_PUNTI = 15;

		this.pista.addEventListener( 'pointerdown', function ( evento ) {
			if ( evento.button !== undefined && evento.button !== 0 ) {
				return;
			}

			attivo = true;
			catturato = false;
			c.haTrascinato = false;
			partenza = evento.clientX;
		} );

		this.pista.addEventListener( 'pointermove', function ( evento ) {
			if ( ! attivo ) {
				return;
			}

			var scostamento = partenza - evento.clientX;

			if ( ! c.haTrascinato ) {
				if ( Math.abs( scostamento ) < SOGLIA_PUNTI ) {
					return;
				}

				c.haTrascinato = true;
				c.pista.classList.add( 'emme-car-in-mano' );

				// Il testo che il dito ha sfiorato prima della soglia poteva
				// essersi selezionato: si toglie, altrimenti resta evidenziato
				// a trascinamento finito.
				if ( window.getSelection ) {
					window.getSelection().removeAllRanges();
				}

				try {
					c.pista.setPointerCapture( evento.pointerId );
					catturato = true;
				} catch {
					// Nessun puntatore da catturare: si trascina lo stesso,
					// solo senza la rete di sicurezza fuori dal riquadro.
				}
			}

			// Il metro e' la diapositiva al centro: trascinare di mezza
			// diapositiva sposta di mezzo posto.
			var larghezza = c.diapositive[ c.corrente ].getBoundingClientRect().width || 1;

			c.posizione = c.corrente + scostamento / larghezza;
			c.posiziona( true );
		} );

		function mollato( evento ) {
			if ( ! attivo ) {
				return;
			}

			attivo = false;
			c.pista.classList.remove( 'emme-car-in-mano' );

			if ( catturato ) {
				try {
					c.pista.releasePointerCapture( evento.pointerId );
				} catch {
					// Il puntatore poteva gia' essere stato rilasciato.
				}

				catturato = false;
			}

			// Senza trascinamento non si tocca niente: era un clic, e deve
			// poter arrivare dove e' diretto.
			if ( ! c.haTrascinato ) {
				return;
			}

			// Un trascinamento sposta SEMPRE di almeno un posto, nel verso in
			// cui e' andata la mano. Arrotondando alla diapositiva piu' vicina
			// si tornava da dove si era partiti, e il gesto non produceva
			// niente: vedi la nota sulla zona morta, qui sopra.
			var spostamento = c.posizione - c.corrente;
			var passi = Math.max( 1, Math.round( Math.abs( spostamento ) ) );

			c.vaiA( c.corrente + ( spostamento < 0 ? -passi : passi ), false );
		}

		this.pista.addEventListener( 'pointerup', mollato );
		this.pista.addEventListener( 'pointercancel', mollato );
	};

	/**
	 * Porta la diapositiva n al centro.
	 *
	 * @param {number}  n       Indice voluto, anche fuori scala.
	 * @param {boolean} umano   Vero se l'ha chiesto una persona: allora
	 *                          l'avvio automatico riparte da capo invece di
	 *                          scattare subito dopo.
	 */
	Carosello.prototype.vaiA = function ( n, umano ) {
		if ( this.anello ) {
			n = ( ( n % this.quante ) + this.quante ) % this.quante;
		} else {
			n = Math.max( 0, Math.min( this.quante - 1, n ) );
		}

		this.corrente = n;
		this.posizione = n;
		this.posiziona();

		if ( umano ) {
			this.riparti();
		}
	};

	/**
	 * Lo scarto fra una diapositiva e il centro.
	 *
	 * Con l'anello si prende la strada piu' corta: in un carosello di cinque,
	 * la quinta non sta a quattro posti dalla prima ma a uno, dall'altra
	 * parte. Senza questo conto l'anello farebbe un giro all'indietro di tutte
	 * le diapositive ogni volta che si passa dall'ultima alla prima.
	 *
	 * @param {number} i Indice della diapositiva.
	 * @return {number} Lo scarto, anche frazionario.
	 */
	Carosello.prototype.scarto = function ( i ) {
		var d = i - this.posizione;

		if ( ! this.anello ) {
			return d;
		}

		while ( d > this.quante / 2 ) {
			d -= this.quante;
		}

		while ( d < -this.quante / 2 ) {
			d += this.quante;
		}

		return d;
	};

	/**
	 * Stringe la distanza finche' le diapositive di lato non sono piu'
	 * tagliate.
	 *
	 * NON si calcola, si MISURA. Una formula dovrebbe tenere conto, insieme,
	 * del riempimento della scheda (che si somma fuori dalla larghezza in
	 * percentuale), della prospettiva (che rimpicciolisce le lontane e quindi
	 * le avvicina al centro) e del bordo. Tre cose che si moltiplicano, ed e'
	 * il motivo per cui a mano non si indovina: vedi la tabella nella sezione
	 * 10 del documento di progetto, che esisteva proprio perche' il blocco
	 * questo conto non lo faceva.
	 *
	 * `getBoundingClientRect` invece restituisce il riquadro **dopo** le
	 * trasformazioni, prospettiva compresa: e' esattamente quello che si vede.
	 *
	 * Si stringe in proporzione a quanto si sborda e si rimisura, perche' la
	 * posizione non e' lineare nella distanza - c'e' di mezzo la prospettiva -
	 * e una correzione sola non basterebbe. Converge in due o tre giri; il
	 * limite a sei e' solo per non girare a vuoto se qualcosa va storto.
	 */
	Carosello.prototype.adattaAllaLarghezza = function () {
		if ( ! this.adatta || this.quante < 2 ) {
			return;
		}

		var pista = this.pista.getBoundingClientRect();

		// Una pista di larghezza zero vuol dire che il blocco non e' ancora
		// disegnato - sta dentro a una scheda chiusa, o la pagina sta ancora
		// montando. Non si misura il nulla: si riprovera' al prossimo giro.
		if ( pista.width < 1 ) {
			return;
		}

		// Il passo scelto va gia' bene: non si stringe niente. E' il caso di
		// chi ha trovato i suoi numeri a mano e non vuole che glieli si tocchi.
		this.passo = this.passoScelto;
		this.posiziona( true );

		if ( this.quantoSborda( pista ) <= TOLLERANZA ) {
			this.pista.classList.remove( 'emme-car-senza-tempo' );
			this.posiziona();
			return;
		}

		/*
		 * SI CERCA PER BISEZIONE, non stringendo a occhio.
		 *
		 * Il primo tentativo stringeva il passo in proporzione a quanto
		 * sbordava e rimisurava, sei giri. Sembrava ragionevole e non lo era:
		 * con i numeri del pattern delle testimonianze - larghezza 70, passo
		 * 74 - dopo sei giri restavano **5,1 px** di sbordo, e il ciclo si
		 * arrendeva in silenzio. Misurato il 12/11/2026, dopo che Manuel ha
		 * segnalato che tagliava ancora.
		 *
		 * La bisezione invece **non puo'** sbagliare, perche' si appoggia a
		 * una cosa certa: piu' il passo e' grande, piu' la diapositiva di lato
		 * va in fuori. Quindi si tiene un valore che si sa buono e uno che si
		 * sa cattivo e si dimezza l'intervallo fra i due. Dodici giri portano
		 * l'incertezza a meno di un centesimo del passo scelto, e alla fine si
		 * prende SEMPRE il valore buono: non quello che si sta provando.
		 */
		var buono = 0;
		var cattivo = this.passoScelto;

		for ( var giro = 0; giro < 12; giro++ ) {
			var mezzo = ( buono + cattivo ) / 2;

			this.passo = mezzo;
			this.posiziona( true );

			if ( this.quantoSborda( pista ) > TOLLERANZA ) {
				cattivo = mezzo;
			} else {
				buono = mezzo;
			}
		}

		this.passo = buono;

		this.pista.classList.remove( 'emme-car-senza-tempo' );
		this.posiziona();
	};

	/**
	 * Di quanto la diapositiva piu' esterna esce dalla pista, in pixel.
	 *
	 * Si guardano tutte e si tiene la peggiore da una parte e dall'altra: con
	 * un numero pari di diapositive le due estremita' non sono simmetriche.
	 *
	 * @param {DOMRect} pista Il riquadro della pista.
	 * @return {number} Quanti pixel escono, zero se non ne esce nessuno.
	 */
	Carosello.prototype.quantoSborda = function ( pista ) {
		var peggio = 0;

		this.diapositive.forEach( function ( diapositiva ) {
			if ( diapositiva.classList.contains( 'emme-car-fuori' ) ) {
				return;
			}

			var r = diapositiva.getBoundingClientRect();

			peggio = Math.max( peggio, pista.left - r.left, r.right - pista.right );
		} );

		return peggio;
	};

	/**
	 * Rifa' il conto quando la pista cambia larghezza.
	 *
	 * Serve davvero: la larghezza della diapositiva e' una percentuale, quindi
	 * restringendo la finestra la scheda si stringe ma il riempimento interno
	 * no, e la proporzione fra i due cambia. Un valore buono su un portatile
	 * taglia su un tablet.
	 *
	 * `ResizeObserver` guarda la pista e non la finestra: cosi' funziona anche
	 * quando a cambiare e' la colonna attorno - una barra laterale che si
	 * apre, l'editor che cambia anteprima - e non la finestra.
	 */
	Carosello.prototype.guardaLaLarghezza = function () {
		var c = this;

		if ( ! this.adatta || typeof ResizeObserver !== 'function' ) {
			return;
		}

		var larga = 0;

		this.occhio = new ResizeObserver( function () {
			var ora = Math.round( c.pista.getBoundingClientRect().width );

			// Si rifa' il conto solo se la larghezza e' cambiata davvero: un
			// ResizeObserver scatta anche per un pixel di arrotondamento, e
			// rifare il conto rifa' anche il posizionamento.
			if ( ora === larga ) {
				return;
			}

			larga = ora;
			c.adattaAllaLarghezza();
		} );

		this.occhio.observe( this.pista );
	};

	Carosello.prototype.posiziona = function ( inMano ) {
		var c = this;

		this.pista.classList.toggle( 'emme-car-senza-tempo', !! inMano );

		var piani = [];

		this.diapositive.forEach( function ( diapositiva, i ) {
			var d = c.scarto( i );
			var lontananza = Math.abs( d );
			var fuori = lontananza > c.visibili + 0.5;

			diapositiva.style.setProperty( '--emme-car-x', d * c.passo + '%' );
			diapositiva.style.setProperty( '--emme-car-z', -lontananza * c.profondita + 'px' );
			diapositiva.style.setProperty( '--emme-car-r', d * c.giro + 'deg' );
			/*
			 * L'OPACITA' AMMORBIDISCE LO SCAVALCO.
			 *
			 * Chi sta davanti lo decide `z-index`, che e' un interruttore: in
			 * un fotogramma la scheda e' dietro, in quello dopo e' davanti, e
			 * nel pezzo dove le due si sovrappongono quel cambio si vede
			 * come uno scatto. Manuel l'ha segnalato due volte il 09/11/2026:
			 * «sembra un bug».
			 *
			 * Spostare il momento del cambio non basta, perche' il problema
			 * non e' quando scatta ma che scatta. Lo spazio 3D vero
			 * (`preserve-3d`), che toglierebbe l'interruttore, e' stato
			 * provato e scartato: all'incrocio i piani delle due schede si
			 * intersecano e compare una cucitura. Vedi il foglio di stile.
			 *
			 * Allora la scheda che arriva non e' del tutto opaca mentre
			 * arriva: al centro vale 1, un posto piu' in la' 0,82. Siccome
			 * l'opacita' SI interpola - al contrario di z-index - nel momento
			 * dello scavalco quella davanti e' intorno a 0,85, quindi lascia
			 * trasparire quella dietro e il cambio si legge come una
			 * dissolvenza invece che come un taglio. In piu' e' un indizio di
			 * profondita' in piu': quello che e' lontano e' anche meno nitido.
			 *
			 * Il valore scende con continuita' anche sotto il dito, perche'
			 * `lontananza` durante il trascinamento e' frazionaria.
			 */
			diapositiva.style.setProperty(
				'--emme-car-o',
				fuori ? 0 : Math.max( 0.55, 1 - lontananza * 0.18 ).toFixed( 3 )
			);

			// Chi e' piu' vicino al centro sta davanti. Quando NON si sta
			// trascinando, questo cambio aspetta meta' movimento: vedi
			// QUANDO_SCAVALCA in cima al file.
			piani.push( [ diapositiva, Math.round( 100 - lontananza * 10 ) ] );

			// Sulla centrale il puntatore dice "si trascina", sulle altre dice
			// "si clicca": e' il solo segnale che indica dove sta la striscia
			// buona, visto che il resto della diapositiva laterale e' dietro.
			diapositiva.classList.toggle( 'emme-car-al-centro', lontananza < 0.5 );

			// Una diapositiva che non si vede non deve nemmeno essere
			// raggiungibile con il tabulatore: il fuoco finirebbe su qualcosa
			// di invisibile e la pagina sembrerebbe rotta.
			diapositiva.classList.toggle( 'emme-car-fuori', fuori );

			if ( fuori ) {
				diapositiva.setAttribute( 'inert', '' );
			} else {
				diapositiva.removeAttribute( 'inert' );
			}
		} );

		this.applicaPiani( piani, inMano );

		if ( this.bottoncini ) {
			this.bottoncini.forEach( function ( punto, i ) {
				var attivo = i === c.corrente;
				punto.classList.toggle( 'emme-car-punto--attivo', attivo );
				punto.setAttribute( 'aria-current', attivo ? 'true' : 'false' );
			} );
		}

		if ( ! this.anello && this.prima ) {
			this.prima.disabled = this.corrente === 0;
			this.dopo.disabled = this.corrente === this.quante - 1;
		}
	};

	/**
	 * Scrive l'ordine di sovrapposizione, al momento giusto.
	 *
	 * Subito quando non c'e' niente da animare - il primo posizionamento, il
	 * trascinamento (dove la posizione e' gia' continua e l'ordine la segue da
	 * solo) e con «riduci animazioni». A meta' movimento in tutti gli altri
	 * casi, che e' quello che si vede come scavalco.
	 *
	 * Un attesa in corso viene annullata: due clic di fila non devono lasciare
	 * l'ordine di un giro vecchio a cadere dentro quello nuovo.
	 *
	 * @param {Array}   piani  Coppie [diapositiva, piano].
	 * @param {boolean} inMano Se si sta trascinando.
	 */
	Carosello.prototype.applicaPiani = function ( piani, inMano ) {
		var scrivi = function () {
			piani.forEach( function ( coppia ) {
				coppia[ 0 ].style.setProperty( '--emme-car-piano', coppia[ 1 ] );
			} );
		};

		if ( this.attesaPiani ) {
			clearTimeout( this.attesaPiani );
			this.attesaPiani = 0;
		}

		if ( inMano || menoMovimento || ! this.partito ) {
			this.partito = true;
			scrivi();

			return;
		}

		var c = this;

		this.attesaPiani = setTimeout( function () {
			c.attesaPiani = 0;
			scrivi();
		}, Math.round( c.durata * QUANDO_SCAVALCA ) );
	};

	// --- l'avvio automatico --------------------------------------------------

	Carosello.prototype.riparti = function () {
		var c = this;

		if ( this.timer ) {
			clearInterval( this.timer );
			this.timer = 0;
		}

		if ( ! this.automatico || this.fermo || ! this.inVista ) {
			return;
		}

		this.timer = setInterval( function () {
			if ( document.hidden ) {
				return;
			}

			c.vaiA( c.corrente + 1, false );
		}, this.intervallo );
	};

	Carosello.prototype.guardaSeSiVede = function () {
		var c = this;

		if ( typeof window.IntersectionObserver !== 'function' ) {
			return;
		}

		new IntersectionObserver( function ( voci ) {
			voci.forEach( function ( voce ) {
				c.inVista = voce.isIntersecting;
				c.riparti();
			} );
		} ).observe( this.radice );
	};

	// --- avvio ---------------------------------------------------------------

	function avvia() {
		var caroselli = document.querySelectorAll( '.emme-car' );

		for ( var i = 0; i < caroselli.length; i++ ) {
			new Carosello( caroselli[ i ] ).avvia();
		}
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', avvia );
	} else {
		avvia();
	}
} )();
