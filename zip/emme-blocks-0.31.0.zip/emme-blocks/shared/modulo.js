/**
 * Il pulsante di invio resta spento finche' il consenso non e' spuntato.
 *
 * Due cose da sapere, perche' sono scelte e non dimenticanze.
 *
 * **Il modulo parte spento solo se c'e' JavaScript.** La pagina arriva con il
 * pulsante acceso; e' questo script, quando parte davvero, a spegnerlo. Il
 * contrario - scriverlo spento nell'HTML - vorrebbe dire che su un browser
 * senza JavaScript il modulo non si puo' mandare affatto: un cliente perso
 * senza che nessuno lo sappia. E' lo stesso schema di `emme-anim-attive` e di
 * `emme-flip-guidata`: il ripiego funziona dove il titolare non c'e'.
 *
 * **Il pulsante non prende l'attributo `disabled` ma `aria-disabled`.** Un
 * pulsante con `disabled` sparisce dal giro del tabulatore e i lettori di
 * schermo lo saltano: chi arriva con la tastiera trova il modulo che finisce
 * nel nulla, senza nessuno che gli dica perche'. Con `aria-disabled` il
 * pulsante resta raggiungibile e viene annunciato come non disponibile, e
 * premendolo e' **il browser stesso** a dire cosa manca - la casella e'
 * `required`, quindi la validazione nativa apre il suo messaggio proprio
 * sulla spunta. Per questo qui non si blocca niente: si cambia solo l'aspetto.
 *
 * Fa la guardia una prova in tests/prove-moduli.php.
 */

( function () {
	'use strict';

	/**
	 * Le spunte obbligatorie di un modulo.
	 *
	 * Solo le caselle singole: in un gruppo di caselle l'obbligatorieta'
	 * riguarda il gruppo intero, e il controllo lo fa il server.
	 *
	 * @param {HTMLFormElement} modulo Il modulo.
	 * @return {HTMLInputElement[]} Le caselle.
	 */
	function spunteObbligatorie( modulo ) {
		return Array.prototype.slice.call(
			modulo.querySelectorAll( 'input[type="checkbox"][required]' )
		);
	}

	/**
	 * Accende o spegne il pulsante di invio di un modulo.
	 *
	 * @param {HTMLFormElement} modulo   Il modulo.
	 * @param {Element}         pulsante Il pulsante di invio.
	 * @param {Array}           spunte   Le caselle obbligatorie.
	 */
	function aggiorna( modulo, pulsante, spunte ) {
		var manca = spunte.some( function ( casella ) {
			return ! casella.checked;
		} );

		pulsante.classList.toggle( 'emme-button--spento', manca );

		if ( manca ) {
			pulsante.setAttribute( 'aria-disabled', 'true' );
		} else {
			pulsante.removeAttribute( 'aria-disabled' );
		}
	}

	/**
	 * Prepara un modulo.
	 *
	 * @param {HTMLFormElement} modulo Il modulo.
	 */
	function prepara( modulo ) {
		var pulsante = modulo.querySelector( 'button[type="submit"], input[type="submit"]' );
		var spunte = spunteObbligatorie( modulo );

		// Niente pulsante o nessuna spunta obbligatoria: non c'e' niente da
		// spegnere, e un pulsante spento senza una ragione visibile sarebbe
		// solo un modulo che non funziona.
		if ( ! pulsante || ! spunte.length ) {
			return;
		}

		var cambiato = function () {
			aggiorna( modulo, pulsante, spunte );
		};

		spunte.forEach( function ( casella ) {
			casella.addEventListener( 'change', cambiato );
		} );

		// Anche al ritorno indietro del browser, che ripristina le caselle
		// come erano senza far scattare nessun evento.
		window.addEventListener( 'pageshow', cambiato );

		cambiato();
	}

	/**
	 * Cerca i moduli e li prepara.
	 */
	function avvia() {
		var moduli = document.querySelectorAll( 'form[data-emme-blocca]' );

		Array.prototype.forEach.call( moduli, prepara );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', avvia );
	} else {
		avvia();
	}
} )();
