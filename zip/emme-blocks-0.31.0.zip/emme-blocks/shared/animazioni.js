/*
 * Fa partire le animazioni di comparsa dei blocchi quattroemme.
 *
 * Usa IntersectionObserver, che e' il meccanismo del browser per sapere quando
 * un elemento entra nello schermo: costa molto meno che stare in ascolto dello
 * scorrimento. Nessuna libreria esterna, nessuna dipendenza.
 *
 * Il file viene caricato solo se nella pagina c'e' almeno un blocco animato.
 */
( function () {
	'use strict';

	// Dice alla riga messa in testa alla pagina che lo script e' arrivato: senza
	// questo, dopo qualche secondo lei toglie da sola le regole che nascondono.
	window.emmeAnimazioniAvviate = true;

	// Se il browser e' vecchio, i blocchi restano semplicemente visibili.
	if ( typeof window.IntersectionObserver !== 'function' ) {
		document.documentElement.classList.remove( 'emme-anim-attive' );
		return;
	}

	// Stesso rispetto che si ha nel CSS: se l'utente ha chiesto meno movimento,
	// non si osserva nemmeno.
	var menoMovimento =
		window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	if ( menoMovimento ) {
		return;
	}

	var osservatore = new IntersectionObserver(
		function ( voci ) {
			voci.forEach( function ( voce ) {
				var elemento = voce.target;
				var unaVoltaSola = elemento.dataset.emmeAnimOnce !== '0';

				if ( voce.isIntersecting ) {
					elemento.classList.add( 'emme-anim-visibile' );

					if ( unaVoltaSola ) {
						osservatore.unobserve( elemento );
					}
				} else if ( ! unaVoltaSola ) {
					elemento.classList.remove( 'emme-anim-visibile' );
				}
			} );
		},
		{
			// Soglia zero, non una percentuale. Una percentuale sembra piu'
			// furba ma e' sbagliata: un blocco piu' alto dello schermo non puo'
			// mai raggiungerla. Con uno schermo da 650 pixel e una sezione da
			// 6500, la parte visibile al massimo e' un decimo del blocco: con
			// una soglia del 15% quella sezione non comparirebbe mai.
			//
			// Si scatta quindi appena entra, e si usa il margine qui sotto per
			// far scattare un filo dopo, cosi' l'animazione si vede.
			threshold: 0,
			rootMargin: '0px 0px -80px 0px',
		}
	);

	function avvia() {
		document.querySelectorAll( '[data-emme-anim]' ).forEach( function ( elemento ) {
			osservatore.observe( elemento );
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', avvia );
	} else {
		avvia();
	}
} )();
