/*
 * Il mazzo di carte quattroemme: chiuderlo dove uno se lo aspetta.
 *
 * PERCHE' ESISTE QUESTO FILE
 *
 * Ad aprire il mazzo basta il browser: la casella di spunta nascosta sotto
 * alla carta centrale, il passaggio del mouse, il fuoco. A **chiuderlo**
 * no, e la differenza e' tutta qui: una casella accesa resta accesa finche'
 * qualcuno non la riclicca. Cliccare da un'altra parte non la spegne, e
 * nemmeno il tasto di uscita.
 *
 * Manuel, 12/11/2026: «il mazzo di carte non si richiude cliccando fuori,
 * ma sempre occorre ricliccare sulla carta e poi cliccare fuori per farlo
 * chiudere». E' la **seconda volta nella stessa giornata** che si presenta
 * questo difetto, con la stessa frase: la prima era il riquadro di aiuto
 * dell'ispettore, dove il fuoco restava sul pulsante che lo aveva aperto e
 * quindi `closeIfFocusOutside` non scattava mai.
 *
 * La regola che ne esce, e che vale per qualunque cosa si apra sopra il
 * resto: **aprire e chiudere sono due lavori diversi, e il secondo non
 * arriva mai gratis.** Si collauda con un clic vero da un'altra parte.
 *
 * PERCHE' DEL JAVASCRIPT, SU UN BLOCCO CHE SI VANTA DI NON AVERNE
 *
 * Perche' il principio del progetto non e' «niente JavaScript a ogni
 * costo»: e' «prima si guarda se il browser lo sa gia' fare». Aprire lo sa
 * fare, chiudere cliccando fuori no.
 *
 * In CSS puro ci sarebbe un modo - un velo invisibile a tutto schermo,
 * grande quanto la finestra, che quando il mazzo e' aperto sta sopra alla
 * pagina e intercetta il clic. Non si e' usato perche' quel velo **si
 * mangia il clic**: con un mazzo aperto, il primo clic su un collegamento
 * chiuderebbe il mazzo e il collegamento non si aprirebbe. Si scambia un
 * difetto con un altro.
 *
 * COSA SUCCEDE SE QUESTO FILE NON ARRIVA
 *
 * Il mazzo si apre e si chiude lo stesso, ricliccando la carta centrale.
 * Non si perde niente: si perde una comodita'.
 */
( function () {
	'use strict';

	var MAZZO = '.emme-mazzo';
	var CASELLA = '.emme-mazzo__scelta';

	/**
	 * Spegne le caselle accese, saltando quella del mazzo indicato.
	 *
	 * @param {Element|null} risparmia Il mazzo da lasciare aperto.
	 */
	function chiudi( risparmia ) {
		var caselle = document.querySelectorAll( CASELLA + ':checked' );
		var i;

		for ( i = 0; i < caselle.length; i++ ) {
			if ( risparmia && risparmia.contains( caselle[ i ] ) ) {
				continue;
			}

			caselle[ i ].checked = false;
		}
	}

	/*
	 * UN CLIC DA UN'ALTRA PARTE CHIUDE.
	 *
	 * L'ascolto e' uno solo, sul documento, e non uno per mazzo: i mazzi in
	 * una pagina possono essere tanti, e ogni ascolto in piu' e' lavoro che
	 * il browser fa a ogni clic.
	 *
	 * Si ascolta la **risalita** del clic e non la discesa: la discesa
	 * arriva prima che il browser abbia cambiato la casella, e si
	 * chiuderebbe il mazzo nello stesso gesto che lo apre.
	 *
	 * Il mazzo che contiene il bersaglio si risparmia - se no cliccare la
	 * carta centrale lo aprirebbe e lo chiuderebbe insieme - ma gli altri
	 * si chiudono: due mazzi aperti nella stessa pagina sono due cose che si
	 * contendono lo spazio.
	 */
	document.addEventListener( 'click', function ( evento ) {
		var dentro = evento.target.closest ? evento.target.closest( MAZZO ) : null;

		chiudi( dentro );
	} );

	/*
	 * IL TASTO DI USCITA CHIUDE TUTTO.
	 *
	 * E' quello che ci si aspetta da qualunque cosa si apra sopra il resto,
	 * ed e' anche l'unico modo di chiudere per chi sta girando la pagina con
	 * la tastiera e non ha un posto «fuori» da cliccare.
	 *
	 * Dopo aver spento la casella si riporta il fuoco sulla casella del
	 * mazzo che era aperto: se restasse dentro a una carta che ora e'
	 * tornata sotto il mucchio, il mazzo si riaprirebbe da solo, perche' il
	 * fuoco dentro al mazzo lo tiene aperto.
	 */
	document.addEventListener( 'keydown', function ( evento ) {
		var attivo;
		var mazzo;

		if ( 'Escape' !== evento.key && 'Esc' !== evento.key ) {
			return;
		}

		if ( ! document.querySelector( CASELLA + ':checked' ) ) {
			return;
		}

		attivo = document.activeElement;
		mazzo = attivo && attivo.closest ? attivo.closest( MAZZO ) : null;

		chiudi( null );

		if ( mazzo ) {
			mazzo.querySelector( CASELLA ).focus();
		}
	} );

	/*
	 * IL MOUSE CHE SE NE VA CHIUDE, DOVE IL MOUSE E' QUELLO CHE APRE.
	 *
	 * Senza questo, su un mazzo che si apre al passaggio succede la cosa
	 * che Manuel ha descritto: ci si passa sopra e si apre, si clicca e la
	 * casella si accende, si porta via il mouse e **resta aperto** - perche'
	 * adesso a tenerlo aperto e' la casella, non piu' il mouse. Per
	 * chiuderlo servono due gesti invece di uno.
	 *
	 * Vale solo dove il passaggio del mouse e' l'apertura dichiarata. Dove
	 * l'apertura e' il clic, il clic deve restare l'unica cosa che comanda:
	 * un mazzo che si chiude da solo passandoci sopra sarebbe peggio del
	 * difetto.
	 *
	 * Questo e' l'unico ascolto attaccato ai singoli mazzi, e non al
	 * documento: `mouseleave` scatta su **ogni** elemento che il puntatore
	 * lascia, quindi ascoltarlo da fuori vorrebbe dire ricevere un evento
	 * per ogni titolo e ogni riga che il mouse sfiora in tutta la pagina.
	 */
	function sorveglia() {
		var mazzi = document.querySelectorAll( MAZZO + '--passaggio' );
		var i;

		for ( i = 0; i < mazzi.length; i++ ) {
			mazzi[ i ].addEventListener( 'mouseleave', function ( evento ) {
				var casella = evento.currentTarget.querySelector( CASELLA );

				if ( casella ) {
					casella.checked = false;
				}
			} );
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', sorveglia );
	} else {
		sorveglia();
	}
}() );
