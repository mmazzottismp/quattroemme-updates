/*
 * Scheda a due facce: la parte che il CSS da solo non puo' fare.
 *
 * Il giro lo fa il foglio di stile. Qui dentro c'e' solo quello che richiede
 * di sapere cosa ha fatto l'utente:
 *
 * - il TOCCO su un telefono. Il passaggio del mouse li' non esiste, e dare
 *   il fuoco a un riquadro toccandolo non funziona allo stesso modo su tutti
 *   i browser: quindi il tocco lo si ascolta.
 * - il CLIC, quando la scheda e' impostata per girarsi al clic invece che al
 *   passaggio del mouse. Serve anche a rigirarla indietro: con il solo fuoco
 *   resterebbe girata finche' non si clicca da un'altra parte.
 *
 * Senza questo file la scheda funziona lo stesso: si gira al passaggio del
 * mouse e con il tabulatore. Si perde solo il tocco e il clic che rigira.
 *
 * Nessuna libreria. Il file viene caricato solo se nella pagina c'e' almeno
 * una scheda a due facce.
 */
( function () {
	'use strict';

	var GIRATA = 'emme-flip-girata';

	// Vero su un telefono o un tablet, cioe' dove il passaggio del mouse non
	// c'e'. Si chiede al browser invece di indovinare dal nome del dispositivo.
	function senzaMouse() {
		return window.matchMedia && window.matchMedia( '( hover: none )' ).matches;
	}

	/**
	 * Dice se il clic e' finito su qualcosa che ha gia' un suo compito.
	 *
	 * Un collegamento o un pulsante dentro una faccia deve funzionare come
	 * collegamento o pulsante: se girassimo la scheda, l'utente si
	 * ritroverebbe il contenuto cambiato sotto il dito nell'istante in cui
	 * sta toccando qualcos'altro.
	 *
	 * @param {EventTarget} bersaglio Dove e' arrivato il clic.
	 * @return {boolean} Vero se il clic non deve girare la scheda.
	 */
	function suQualcosaDiVivo( bersaglio ) {
		return !! ( bersaglio.closest && bersaglio.closest( 'a, button, input, select, textarea, summary, label' ) );
	}

	function avvia() {
		var schede = document.querySelectorAll( '.emme-flip' );

		if ( ! schede.length ) {
			return;
		}

		var niente = senzaMouse();

		schede.forEach( function ( scheda ) {
			// Da qui in poi il comando e' uno solo: la classe emme-flip-girata.
			// Questa marcatura spegne nel foglio di stile la regola che girava
			// la scheda al fuoco, che altrimenti continuerebbe a tenerla girata
			// dopo un clic e farebbe sembrare il secondo clic senza effetto.
			scheda.classList.add( 'emme-flip-guidata' );

			var alClic = scheda.classList.contains( 'emme-flip--clic' );

			// Il clic gira la scheda quando e' impostata cosi', e sempre dove
			// un mouse non c'e': sui telefoni e' l'unico modo di girarla.
			// Sulle schede a passaggio del mouse, su un computer, il clic non
			// deve fare niente: ci pensa gia' il CSS, e un clic che gira in
			// piu' lascerebbe la scheda girata dopo che il mouse se n'e'
			// andato.
			if ( alClic || niente ) {
				scheda.addEventListener( 'click', function ( evento ) {
					if ( suQualcosaDiVivo( evento.target ) ) {
						return;
					}

					scheda.classList.toggle( GIRATA );
				} );
			}

			// Con la tastiera: invio e barra spaziatrice, come su un pulsante.
			// Vale per tutte le schede, anche quelle a passaggio del mouse,
			// perche' con la sola tastiera un passaggio del mouse non esiste.
			scheda.addEventListener( 'keydown', function ( evento ) {
				if ( evento.target !== scheda ) {
					return;
				}

				if ( evento.key !== 'Enter' && evento.key !== ' ' ) {
					return;
				}

				evento.preventDefault();
				scheda.classList.toggle( GIRATA );
			} );
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', avvia );
	} else {
		avvia();
	}
} )();
