<?php
/**
 * Plugin Name:       quattroemme Blocks
 * Description:       I blocchi di layout e di componenti di quattroemme. Lavora insieme a quattroemme Theme, che fornisce i colori, i caratteri e le spaziature.
 * Version:           0.30.0
 * Requires at least: 6.6
 * Requires PHP:      8.1
 * Update URI:        https://mmazzottismp.github.io/quattroemme-updates/emme-blocks
 * Author:            quattroemme
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       emme-blocks
 * Domain Path:       /languages
 *
 * @package EmmeBlocks
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const EMME_BLOCKS_VERSION = '0.30.0';

define( 'EMME_BLOCKS_PATH', plugin_dir_path( __FILE__ ) );
define( 'EMME_BLOCKS_URL', plugin_dir_url( __FILE__ ) );

/**
 * Carica da solo le classi del namespace Emme\ dalla cartella inc/.
 *
 * Esempio: la classe Emme\Css\Builder viene cercata in inc/Css/Builder.php.
 * Serve a non scrivere un require per ogni file. Fa lo stesso lavoro di
 * Composer, ma senza dipendere da Composer in produzione.
 */
spl_autoload_register(
	static function ( string $class_name ): void {
		$prefix = 'Emme\\';

		if ( 0 !== strncmp( $prefix, $class_name, strlen( $prefix ) ) ) {
			return;
		}

		$relative_path = substr( $class_name, strlen( $prefix ) );
		$file          = EMME_BLOCKS_PATH . 'inc/' . str_replace( '\\', '/', $relative_path ) . '.php';

		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);

// Traduzioni: le stringhe sono in inglese e l'italiano e' una traduzione.
// Vedi inc/Traduzioni.php.
Emme\Traduzioni::init();

// Avvisa se manca il tema da cui i blocchi prendono colori e caratteri:
// vedi inc/TemaRichiesto.php.
Emme\TemaRichiesto::init();

// Controllo degli aggiornamenti: vedi inc/Updates/Checker.php.
Emme\Updates\Checker::init();

// Generatore del CSS dei blocchi: vedi inc/Css/Builder.php e inc/Css/Output.php.
Emme\Css\Output::init();

// La categoria «quattroemme» nell'elenco dei blocchi: vedi inc/Categoria.php.
Emme\Categoria::init();

// I nostri aspetti aggiuntivi sui blocchi di WordPress: vedi inc/BlockStyles.php.
Emme\BlockStyles::init();

// La libreria di pattern: vedi inc/Patterns.php.
Emme\Patterns::init();

// Il modulo di contatto: dove finiscono i messaggi, come si ricevono, e come
// si trattano i dati personali di chi scrive. Vedi inc/Moduli/.
Emme\Moduli\Invii::init();
Emme\Moduli\Ricezione::init();
Emme\Moduli\Privacy::init();

// Spegnendo il plugin si toglie anche l'appuntamento quotidiano che cancella
// i messaggi scaduti: un appuntamento che chiama una funzione che non c'e'
// piu' resta in calendario per sempre.
register_deactivation_hook( __FILE__, array( Emme\Moduli\Privacy::class, 'ferma' ) );

/**
 * Registra tutti i blocchi compilati dentro build/.
 *
 * Dalla 6.8 WordPress sa leggere un solo file riepilogativo (il "manifest")
 * invece di aprire un block.json per ogni blocco: costa meno. Sulle versioni
 * precedenti si registra cartella per cartella.
 */
function emme_blocks_register_blocks(): void {
	// La compilazione mette ogni blocco in build/blocks/<nome>/ e il riepilogo in build/.
	$blocks_path = EMME_BLOCKS_PATH . 'build/blocks/';
	$manifest    = EMME_BLOCKS_PATH . 'build/blocks-manifest.php';

	if ( ! is_dir( $blocks_path ) ) {
		return;
	}

	if ( file_exists( $manifest ) && function_exists( 'wp_register_block_types_from_metadata_collection' ) ) {
		wp_register_block_types_from_metadata_collection( $blocks_path, $manifest );
		return;
	}

	foreach ( (array) glob( $blocks_path . '*/block.json' ) as $block_json ) {
		register_block_type( dirname( (string) $block_json ) );
	}
}
add_action( 'init', 'emme_blocks_register_blocks' );

/**
 * Avvisa nella bacheca se manca la compilazione.
 *
 * Senza la cartella build/ il plugin non ha blocchi da offrire: meglio dirlo
 * chiaro invece di lasciare l'editor vuoto senza spiegazioni.
 */
function emme_blocks_build_missing_notice(): void {
	if ( is_dir( EMME_BLOCKS_PATH . 'build/blocks' ) || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	printf(
		'<div class="notice notice-error"><p>%s</p></div>',
		esc_html__( 'quattroemme Blocks: the build folder is missing. The blocks must be compiled with "npm run build" before using the plugin.', 'emme-blocks' )
	);
}
add_action( 'admin_notices', 'emme_blocks_build_missing_notice' );
